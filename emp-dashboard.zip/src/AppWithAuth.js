import React from 'react';
import App from '@app/App';
import AuthContainer from '@app/containers/AuthContainer';
import { UserContextProvider } from '@app/providers/UserContext';
import { SessionContextProvider } from '@app/providers/SessionContext';

const AppWithAuth = () => {
  return (
    <UserContextProvider>
      <SessionContextProvider>
        <AuthContainer>
          <App />
        </AuthContainer>
      </SessionContextProvider>
    </UserContextProvider>
  );
};

export default AppWithAuth;
