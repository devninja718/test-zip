import React from 'react';
import { Switch, withRouter, Redirect } from 'react-router-dom';
import { DashboardLayout } from '@app/layouts';
import PublicRoute from './PublicRoute';
import PrivateRoute from './PrivateRoute';
import GoogleClassContainer from '@app/containers/Google';
import MaterialContainer from '@app/containers/Lesson';
import GalleryContainer from '@app/containers/Gallery';
import UserContainer from '@app/containers/User';
import TutorialContainer from '@app/containers/Tutorial';
import TopologyContainer from '@app/containers/Topology';
import LibraryContainer from '@app/containers/Library';
import MessageContainer from '@app/containers/SystemMessage';
import ArchivesContainer from '@app/containers/Archives';
import ResourcesContainer from '@app/containers/Resources';
import ClearContainer from '@app/containers/Clear';
import { Auth } from 'aws-amplify';
import { useIdleTimer } from 'react-idle-timer';

const AppRoutes = () => {
  const idleTimeout = 1000 * 60 * 30;
  const handleOnIdle = async (e) => {
    window.localStorage.clear();
    window.sessionStorage.setItem('last_path', window.location.pathname);
    try {
      console.log('#25');
      if ((await Auth.currentSession()).isValid()) {
        console.log('$27');
        await Auth.signOut();
      }
    } catch (e) {}
    window.location.reload();
  };

  const handleOnAction = async (e) => {
    const lastActionTime = localStorage.getItem('lastActionTime');
    localStorage.setItem('lastActionTime', new Date().getTime());

    if (
      lastActionTime &&
      new Date().getTime() - parseInt(lastActionTime) > idleTimeout
    ) {
      window.localStorage.clear();
      window.sessionStorage.setItem('last_path', window.location.pathname);

      try {
        console.log('#45');
        if ((await Auth.currentSession()).isValid()) {
          console.log('$48');
          await Auth.signOut();
        }
      } catch (e) {}

      window.location.reload();
    }
  };

  useIdleTimer({
    timeout: idleTimeout,
    onIdle: handleOnIdle,
    onAction: handleOnAction,
    debounce: 500
  });

  return (
    <Switch>
      <PublicRoute path="/dashboard" layout={DashboardLayout} />
      <PrivateRoute
        path="/classes/google/:classId?"
        component={GoogleClassContainer}
        layout={DashboardLayout}
      />
      <PrivateRoute
        path="/libraries/:libraryId?"
        component={LibraryContainer}
        layout={DashboardLayout}
      />
      <PrivateRoute
        path="/materials/:materialId?"
        component={MaterialContainer}
        layout={DashboardLayout}
      />
      <PrivateRoute
        path="/galleries"
        component={GalleryContainer}
        layout={DashboardLayout}
      />
      <PrivateRoute
        path="/tutorials"
        component={TutorialContainer}
        layout={DashboardLayout}
      />
      <PrivateRoute
        path="/users/:userId?"
        component={UserContainer}
        layout={DashboardLayout}
      />
      <PrivateRoute
        path="/topology"
        component={TopologyContainer}
        layout={DashboardLayout}
      />
      <PrivateRoute
        path="/message"
        component={MessageContainer}
        layout={DashboardLayout}
      />
      <PrivateRoute
        path="/archives"
        component={ArchivesContainer}
        layout={DashboardLayout}
      />
      <PrivateRoute
        path="/resources"
        component={ResourcesContainer}
        layout={DashboardLayout}
      />
      <PrivateRoute
        path="/clear"
        component={ClearContainer}
        layout={DashboardLayout}
      />
      <Redirect from="/emp-studentapp" to="/emp-studentapp/index.html" />
      <Redirect from="*" to="/topology" />
    </Switch>
  );
};

export default withRouter(AppRoutes);
