export default {
  success: {},
  info: {},
  warning: {},
  error: {}
};
