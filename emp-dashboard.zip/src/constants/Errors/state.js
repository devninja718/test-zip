import { en } from '@app/language';

export default {
  create: {
    duplicate: en['Current state already created!']
  }
};
