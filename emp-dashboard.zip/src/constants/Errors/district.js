import { en } from '@app/language';

export default {
  create: {
    duplicate: en['Current school district already created!']
  }
};
