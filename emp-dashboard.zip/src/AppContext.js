import React from 'react';

const AppContext = React.createContext(null);

export default AppContext;
