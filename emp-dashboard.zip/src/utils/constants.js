/** Auth user token key */
export const AUTH_USER_TOKEN_KEY = 'ReactAmplify.TokenKey';
export const XAPIKEY = 'HqWC3eZC2q1d6jF7dE7JL4Bw210mrmcBaANYNjxB';
