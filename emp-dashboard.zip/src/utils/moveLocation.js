import { useMutation } from '@apollo/client';
import graphql from '@app/graphql';
import { useStateContext } from '@app/providers/StateContext';
import { useUserContext } from '@app/providers/UserContext';
export const MoveLocation = async (item, targetParent) => {
  const [stateContext, setStateContext] = useStateContext();
  const [currentUser] = useUserContext();
  const [updateGrouping] = useMutation(graphql.mutations.updateGrouping, {
    onCompleted(data) {}
  });

  // Update currently moved item
  await updateGrouping({
    variables: {
      version: item.version,
      id: item._id,
      schemaType: 'material',
      trackingAuthorName: currentUser?.name,
      parentId: targetParent._id,
      topology: targetParent.topology,
      parentIdList: [...targetParent.parentIdList, targetParent._id]
    }
  });

  let childrenIds = targetParent?.childrenIdList;
  if (childrenIds) {
    childrenIds = [...childrenIds, item._id];
  } else {
    childrenIds = [item._id];
  }
  // Add moved item to new parent child list
  if (childrenIds?.length) {
    let varaibleData = {
      id: targetParent._id,
      schemaType: targetParent.schemaType,
      version: targetParent.version,
      trackingAuthorName: currentUser?.name,
      childrenIdList: childrenIds
    };
    await updateGrouping({
      variables: varaibleData
    });
  }

  // All chiled list update if selected I tem is collection
  const { material } = stateContext;
  const childs = material.filter((value) => value.parentId === item._id);
  if (childs && childs.length > 0) {
    for (const child of childs) {
      await updateGrouping({
        variables: {
          version: child.version,
          id: child._id,
          schemaType: 'material',
          trackingAuthorName: currentUser?.name,
          topology: targetParent.topology,
          parentIdList: [
            ...targetParent.parentIdList,
            targetParent._id,
            item._id
          ]
        }
      });
    }
  }
};

export const Reorder = async (item, before, after) => {
  const [currentUser] = useUserContext();
  const [updateGrouping] = useMutation(graphql.mutations.updateGrouping);
  let rank = (before.rank + after.rank) / 2;

  console.log('Reorder - selected', item._id);
  console.log('Reorder - moving', ` between ${before._id} and ${after._id}`);
  await updateGrouping({
    variables: {
      version: item.version,
      id: item._id,
      schemaType: 'material',
      trackingAuthorName: currentUser?.name,
      rank
    }
  });
};
