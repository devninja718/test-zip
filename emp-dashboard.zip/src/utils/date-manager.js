import { zonedTimeToUtc, format } from 'date-fns-tz';
import moment from 'moment';

const formatDate = (date) => format(date, 'yyyy-MM-dd HH:mm:ss.SSS');

const getClientTimeZone = () =>
  Intl.DateTimeFormat().resolvedOptions().timeZone;

export const getCurrentUTCTime = () => {
  const currDate = formatDate(new Date());
  const timeZone = getClientTimeZone();
  const utcDate = zonedTimeToUtc(currDate, timeZone);
  return utcDate.toISOString();
};

export const getFormattedDate = (date) => {
  const newDate = moment(date);
  return newDate.format('MM/DD/YYYY HH:mm:ss');
};
