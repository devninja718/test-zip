export function update(cache, { data: { updateGrouping } }) {
  cache.modify({
    fields: {
      grouping(allGrouping = []) {
        const updatedGrouping = allGrouping.map((group) => {
          if (group._id === updateGrouping._id) {
            let tmp = updateGrouping;
            return tmp;
          }
          return group;
        });
        return updatedGrouping;
      }
    }
  });
}

export function remove(cache, { data: { deleteDocument } }, id) {
  cache.modify({
    fields: {
      grouping(allGrouping = []) {
        const updatedGrouping = allGrouping.filter((el) => el._id !== id);
        return updatedGrouping;
      }
    }
  });
}

export function create(cache, { data: { createGrouping } }) {
  cache.modify({
    fields: {
      grouping(allGrouping = [], details) {
        console.log(details);
        const schemaType = JSON.parse(
          details.storeFieldName.replace('grouping(', '').replace(')', '')
        )?.schemaType;
        if (createGrouping.schemaType === schemaType) {
          return [createGrouping, ...allGrouping];
        } else {
          return allGrouping;
        }
      }
    }
  });
}

export function upsertMMA(cache, { data: { upsertMMA } }) {
  cache.modify({
    fields: {
      grouping(allGrouping = []) {
        const updatedGrouping = allGrouping.map((group) => {
          if (group._id === upsertMMA._id) {
            let tmp = upsertMMA;
            return tmp;
          }
          return group;
        });
        return updatedGrouping;
      }
    }
  });
}

export function deleteMMA(cache, { data: { deleteMMA } }) {
  cache.modify({
    fields: {
      grouping(allGrouping = []) {
        const updatedGrouping = allGrouping.map((group) => {
          if (group._id === deleteMMA._id) {
            let tmp = deleteMMA;
            return tmp;
          }
          return group;
        });
        return updatedGrouping;
      }
    }
  });
}
