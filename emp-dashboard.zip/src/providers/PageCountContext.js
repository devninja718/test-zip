import React, { useState, useContext } from 'react';

const PageCountContext = React.createContext(null);
PageCountContext.displayName = 'PageCountContext';

const PageCountContextProvider = ({ ...props }) => {
  const [pageCount, setPageCount] = useState(200);
  const [viewMethod, setViewMethod] = useState('list');

  const value = {
    pageCount,
    setPageCount,
    viewMethod,
    setViewMethod
  };

  return <PageCountContext.Provider value={value} {...props} />;
};

const usePageCountContext = () => {
  return useContext(PageCountContext);
};

export { PageCountContextProvider, usePageCountContext };
