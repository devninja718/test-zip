import React, { useContext, useState } from 'react';

const SelectionContext = React.createContext(null);
SelectionContext.displayName = 'SelectionContext';

const SelectionContextProvider = ({ ...props }) => {
  const [nextSelected, setNextSelected] = useState();
  const [showRoot, setShowRoot] = useState(false);
  const [documentCreateError, setDocumentCreateError] = useState();

  const value = {
    nextSelected,
    setNextSelected,
    showRoot,
    setShowRoot,
    documentCreateError,
    setDocumentCreateError,
  };

  return <SelectionContext.Provider value={value} {...props} />;
};

const useSelectionContext = () => {
  return useContext(SelectionContext);
};

export { SelectionContextProvider, useSelectionContext };
