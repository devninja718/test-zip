import React, { useState, useContext } from 'react';
const UserContext = React.createContext(null);
UserContext.displayName = 'ErrorContext';

const UserContextProvider = ({ ...props }) => {
  const [state, setState] = useState();
  const [status, setStatus] = useState(true);
  const [currentPage, setCurrentPage] = useState();

  const value = [
    state,
    setState,
    status,
    setStatus,
    currentPage,
    setCurrentPage
  ];

  return <UserContext.Provider value={value} {...props} />;
};

const useUserContext = () => {
  return useContext(UserContext);
};

export { UserContextProvider, useUserContext, UserContext };
