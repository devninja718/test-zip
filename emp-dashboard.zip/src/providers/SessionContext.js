import React, { useState, useContext, useEffect, createContext } from 'react';
import { Auth, Hub, Logger } from 'aws-amplify';
import { AUTH_USER_TOKEN_KEY } from '@app/utils/constants';

const SessionContext = createContext(null);
const useSessionContext = () => {
  return useContext(SessionContext);
};

const SessionContextProvider = ({ ...props }) => {
  const [authStatus, setAuthStatus] = useState('');

  const logger = new Logger('My-Logger');

  const listener = async (data) => {
    switch (data.payload.event) {
      case 'signIn':
        logger.info('user signed in');
        console.log('user signed in');
        setAuthStatus('signIn');
        console.log(data);
        const user = await Auth.currentUserInfo();
        console.log('user', user);
        const user1 = await Auth.currentAuthenticatedUser({
          bypassCache: true
        });
        console.log('current auth user', user1);
        if (user?.attributes) {
          console.log(user);
        } else {
          window.localStorage.setItem(
            AUTH_USER_TOKEN_KEY,
            user1.signInUserSession?.getIdToken()?.getJwtToken()
          );
          window.location.href = '/';
        }
        break;
      case 'signUp':
        logger.info('user signed up');
        console.log('user signed up');
        setAuthStatus('signUp');
        console.log(data);
        break;
      case 'signOut':
        logger.info('user signed out');
        console.log('user signed out');
        setAuthStatus('signOut');
        console.log(data);
        break;
      case 'signIn_failure':
        logger.error('user sign in failed');
        console.log('user sign in failed');
        setAuthStatus('signIn_failure');
        console.log(data);
        break;
      case 'tokenRefresh':
        logger.info('token refresh succeeded');
        console.log('token refresh succeeded');
        console.log('#44');
        const session = await Auth.currentSession();
        const token = session.getIdToken().getJwtToken();
        // console.log('refreshed token', token);
        localStorage.setItem(AUTH_USER_TOKEN_KEY, token);
        setAuthStatus('tokenRefresh');
        break;
      case 'tokenRefresh_failure':
        logger.error('token refresh failed');
        console.log('token refresh failed');
        setAuthStatus('tokenRefresh_failure');
        break;
      case 'configured':
        logger.info('the Auth module is configured');
        console.log('the Auth module is configured');
        setAuthStatus('configured');
        console.log(data);
        break;
      default:
    }
  };

  function getUser() {
    return Auth.currentAuthenticatedUser()
      .then((userData) => userData)
      .catch(() => console.log('Not signed in'));
  }

  useEffect(() => {
    Hub.listen('auth', listener);
  }, []);

  const value = { authStatus };

  return <SessionContext.Provider value={value} {...props} />;
};

export { useSessionContext, SessionContextProvider };
