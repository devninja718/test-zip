import React, { useState, useContext } from 'react';

const LessonViewModeContext = React.createContext(null);
LessonViewModeContext.displayName = 'LessonViewModeContext';

const LessonViewModeContextProvider = ({ ...props }) => {
  const [lessonViewMode, setLessonViewMode] = useState('List View');
  const [selectedClassItem, setSelectedClassItem] = useState([]);

  const value = {
    lessonViewMode,
    setLessonViewMode,
    selectedClassItem,
    setSelectedClassItem
  };

  return <LessonViewModeContext.Provider value={value} {...props} />;
};

const useLessonViewModeContext = () => {
  return useContext(LessonViewModeContext);
};

export { LessonViewModeContextProvider, useLessonViewModeContext };
