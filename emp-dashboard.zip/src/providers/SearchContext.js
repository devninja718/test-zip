import React, { useState, useContext } from 'react';

const SearchContext = React.createContext(null);
SearchContext.displayName = 'SearchContext';

const SearchContextProvider = ({ ...props }) => {
  const [openSearch, setOpenSearch] = useState(false);
  const [openLessonSearch, setOpenLessonSearch] = useState(false);
  const [searchChildren, setSearchChildren] = useState(false);

  const value = {
    openSearch,
    setOpenSearch,
    openLessonSearch,
    setOpenLessonSearch,
    searchChildren,
    setSearchChildren
  };

  return <SearchContext.Provider value={value} {...props} />;
};

const useSearchContext = () => {
  return useContext(SearchContext);
};

export { SearchContextProvider, useSearchContext };
