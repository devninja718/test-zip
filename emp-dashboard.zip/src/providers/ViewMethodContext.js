import React, { useState, useContext } from 'react';
import { Cookies } from 'react-cookie';
const ViewMethodContext = React.createContext(null);
ViewMethodContext.displayName = 'ViewMethodContext';

const ViewMethodContextProvider = ({ ...props }) => {
  const cookies = new Cookies();
  const [viewMethod, setViewMethod] = useState(
    cookies.get('viewMode') || 'list'
  );

  const value = { viewMethod, setViewMethod };

  return <ViewMethodContext.Provider value={value} {...props} />;
};

const useViewMethodContext = () => {
  return useContext(ViewMethodContext);
};

export { ViewMethodContextProvider, useViewMethodContext, ViewMethodContext };
