/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, useRef } from 'react';
import { EditorState, convertToRaw, AtomicBlockUtils } from 'draft-js';
import useStyles from './style';
import './style.css';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';
import draftToHtml from 'draftjs-to-html';
import { Editor } from '@tinymce/tinymce-react';

const toHtml = (value) => {
  return draftToHtml(convertToRaw(value));
};

const TextEditor = ({
  disable,
  detailData,
  onChange,
  docId,
  resources,
  cardViewList,
  isAvatar
}) => {
  const classes = useStyles();
  const editorRef = useRef(null);
  const [editorState, setEditorState] = useState();
  const [editorUpdatedState, setEditorUpdatedState] = useState();

  useEffect(() => {
    let showContext;
    if (detailData?.length > 0) {
      setEditorState(detailData);
      showContext = detailData;
      if (detailData !== editorUpdatedState) {
      }
    } else {
      setEditorState('<p></p>');
      showContext = '<p></p>';
    }
    if (editorRef?.current) {
      editorRef?.current?.setContent(showContext);
    }
  }, [detailData, docId]);

  var height = cardViewList
    ? isAvatar
      ? resources?.data?.processDate?.publishedDate
        ? 430
        : 460
      : 463
    : 300;
  if (document.getElementsByClassName('tox-tinymce')[0]) {
    document.getElementsByClassName('tox-tinymce')[0].style.height =
      height + 'px';
  }

  const handleEditorStateChange = (value) => {
    if (editorRef.current) {
      console.log(editorRef.current.getContent());
      setEditorUpdatedState(editorRef.current.getContent());
      const currentContent = editorRef.current.getContent();

      onChange(currentContent);
    }
  };

  const handleDrop = (selection, dataTransfer, isInternal) => {
    if (
      isInternal === 'external' &&
      dataTransfer.data.getData('type') === 'IMAGE'
    ) {
      const src = dataTransfer.data.getData('src');
    }
  };

  const insertImage = (editorState, source, insertKey) => {
    const contentState = editorState.getCurrentContent();
    const contentStateWithEntity = contentState.createEntity(
      'IMAGE',
      'IMMUTABLE',
      { src: source, width: '200px' }
    );
    let entityKey =
      insertKey || contentStateWithEntity.getLastCreatedEntityKey();
    if (entityKey === null) return; // bug-fix
    console.log({ entityKey });
    try {
      contentStateWithEntity.getEntity(entityKey);
    } catch (_) {
      entityKey = contentStateWithEntity.getLastCreatedEntityKey();
    }
    const newEditorState = EditorState.set(editorState, {
      currentContent: contentStateWithEntity
    });
    return AtomicBlockUtils.insertAtomicBlock(newEditorState, entityKey, ' ');
  };

  return (
    <React.Fragment>
      <Editor
        onInit={(evt, editor) => {
          console.log('=====', editor);
          editorRef.current = editor;
          var height = cardViewList
            ? isAvatar
              ? resources?.data?.processDate?.publishedDate
                ? 430
                : 460
              : 419
            : 300;
          var id = editor.id;
          document.getElementById(id + '_ifr').style.height = height + 'px';
        }}
        initialValue={editorState}
        outputFormat="text"
        apiKey="crjb9x5md7zatipz04e0sdd9helhucrsz3o32n7go9bxsroi"
        init={{
          height: cardViewList
            ? isAvatar
              ? resources?.data?.processDate?.publishedDate
                ? 430
                : 460
              : 419
            : 300,
          menubar: false,
          readonly: disable ? 1 : 0,
          plugins: [
            // 'link',
            // 'advlist autolink lists link image',
            'charmap print preview anchor help',
            'searchreplace visualblocks code',
            'insertdatetime media table paste wordcount',
            // 'advlist autolink lists link image charmap print preview anchor',
            'searchreplace visualblocks code fullscreen',
            'insertdatetime media table paste code help wordcount'
          ],
          toolbar:
            'undo redo | formatselect | fontselect | fontsizeselect | \
              bold italic underline strikethrough monospace superscript subscript forecolor backcolor | \
            alignleft aligncenter alignright alignjustify| \
            bullist numlist outdent indent | removeformat | help',
          content_style:
            'body { font-family:Helvetica,Arial,sans-serif; font-size:14px }'
        }}
        onChange={handleEditorStateChange}
      />
    </React.Fragment>
  );
};

export default TextEditor;
