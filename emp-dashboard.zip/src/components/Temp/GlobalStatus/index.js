import React, { useState } from 'react';
import { Box, Divider } from '@material-ui/core';
import { getCurrentUTCTime } from '@app/utils/date-manager';
import useStyles from './style';
import { getVersionString } from '@app/utils/functions';

const GlobalStatus = ({ width, open }) => {
  const classes = useStyles();
  const [version, setVersion] = useState('');

  if (!version) {
    getVersionString().then((data) => {
      setVersion(data);
    });
  }

  return (
    <Box
      className={classes.root}
      style={{
        width: open ? 'calc(100% - 180px)' : 'calc(100% - 20px)',
        zIndex: 1000
      }}
    >
      <Divider />
      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        pl={3}
        pr={3}
        height={40}
      >
        <p className={classes.p}>
          © Copyright 2021 Signal Infrastructure Group PBC. All rights reserved.
        </p>
        <p className={classes.p}>
          {/* {getCurrentUTCTime().substr(0, 10)} Version: {versionData.version}{' '}
          Branch: {versionData.branch} */}
          {version}
        </p>
      </Box>
    </Box>
  );
};

export default GlobalStatus;
