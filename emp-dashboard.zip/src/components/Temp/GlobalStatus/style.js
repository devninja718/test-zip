import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
  root: {
    flex: 1,
    position: 'fixed',
    bottom: 0,
    padding: `0 ${theme.spacing(1)}px`,
    marginTop: 5,
    background: theme.palette.blueGrey['50']
  },
  p: {
    margin: theme.spacing(1),
    paddingRight: theme.spacing(3),
    fontSize: 14,
    color: theme.palette.blueGrey['600'],
    fontWeight: 500
  }
}));

export default useStyles;
