import React from 'react';
import { KeyboardDateTimePicker } from '@material-ui/pickers';
import './styles.scss';

const CustomDateTimePicker = ({
  filterDate,
  setFilterDate,
  label,
  secondDate
}) => {
  const handleDateChange = (value) => {
    setFilterDate(value);
  };

  const handleKeypress = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
    }
  };

  return (
    <form noValidate>
      <KeyboardDateTimePicker
        autoOk
        ampm={true}
        style={{ padding: 2, marginTop: 8 }}
        value={filterDate}
        onChange={handleDateChange}
        label={label}
        format="MM/DD/YY hh:mm:ss a"
        onKeyPress={(e) => handleKeypress(e)}
        className="datepicker"
      />
    </form>
  );
};

export default CustomDateTimePicker;
