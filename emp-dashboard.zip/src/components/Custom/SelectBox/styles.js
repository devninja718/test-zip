import { makeStyles } from '@material-ui/core';

const useStyles = makeStyles((theme) => ({
  root: {
    flex: 1,
    // alignItems: 'center',
    padding: 5
  },
  fullWidth: {
    width: '100%'
  },
  noPadding: {
    padding: 0
  },
  label: {
    paddingLeft: theme.spacing(1),
    paddingRight: theme.spacing(1),
    background: theme.palette.common.white,
    fontSize: 14
  },
  stateSelect: {
    fontSize: '14px !important',
    background: theme.palette.common.white,
    '& .MuiSelect-select:focus': {
      backgroundColor: theme.palette.common.white
    },
    '& .MuiSelect-select:hover': {
      backgroundColor: theme.palette.common.white
    }
  },
  menuList: {
    paddingTop: 0,
    paddingBottom: 0
  },
  menuItem: {
    fontSize: 14
  }
}));

export default useStyles;
