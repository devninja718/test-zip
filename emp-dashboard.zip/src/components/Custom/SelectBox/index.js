import React, { useState } from 'react';
import clsx from 'clsx';
import {
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  FormHelperText
} from '@material-ui/core';
import useStyles from './styles';

const CustomSelectBox = ({
  id,
  label,
  variant,
  style,
  customStyle,
  defaultValue,
  helperText,
  resources,
  error,
  onChange,
  size,
  addMarginTop,
  labelClass,
  disabled,
  noPadding,
  ...rest
}) => {
  const classes = useStyles();

  const handleChange = (event) => {
    const selData = resources.find((el) =>
      typeof el === 'string'
        ? el === event.target.value
        : el.value === event.target.value
    );
    onChange(selData);
  };

  return (
    <FormControl
      variant={variant}
      className={clsx(classes.root, {
        [classes.fullWidth]: style,
        [classes.noPadding]: noPadding
      })}
      size={size}
      error={error}
      focused={false}
      autoComplete="off"
    >
      <InputLabel
        id={`label-${id}`}
        className={labelClass ? labelClass : classes.label}
        style={{ marginTop: 5 }}
      >
        {label}
      </InputLabel>
      <Select
        id={id}
        placeholder={'asfasd'}
        labelId={`label-${id}`}
        className={clsx(style, classes.stateSelect)}
        onChange={handleChange}
        style={customStyle}
        error={error}
        {...rest}
        MenuProps={{ classes: { list: classes.menuList } }}
        disabled={disabled}
        inputProps={{
          form: {
            autocomplete: 'off'
          },
          // autocomplete: 'select',
          autoFocus: false
        }}
      >
        {resources.map((el, index) => (
          <MenuItem
            key={index}
            value={typeof el === 'string' ? el : el.value}
            className={classes.menuItem}
          >
            {typeof el === 'string' ? el : el.label}
          </MenuItem>
        ))}
      </Select>
      {helperText && <FormHelperText>{helperText}</FormHelperText>}
    </FormControl>
  );
};

export default CustomSelectBox;
