import React from 'react';
import clsx from 'clsx';
import {
  Box,
  Button,
  Dialog,
  Typography,
  DialogTitle,
  CircularProgress,
  DialogActions,
  DialogContent
} from '@material-ui/core';
import useStyles from './style';

const CustomDialog = ({
  open,
  title,
  style,
  dismissBtnName,
  mainBtnName,
  buttonDisable,
  secondaryBtnName,
  onChange,
  children,
  customStyle,
  customClass,
  info,
  ...rest
}) => {
  const classes = useStyles();

  return (
    <Dialog
      className={clsx(classes.root, {
        [classes.root]: !style,
        [style]: style
      })}
      classes={title === 'Information' && { paper: classes.paper }}
      open={open}
      disableBackdropClick
      disableEscapeKeyDown
      onClose={() => onChange('btnClick', false)}
    >
      <DialogTitle className={classes.title}>
        <Box>
          <Typography variant="h6">{title}</Typography>
        </Box>
      </DialogTitle>
      <DialogContent className={customClass ? customClass : classes.content}>
        {children}
      </DialogContent>
      <DialogActions>
        {dismissBtnName ? (
          <Button
            color="default"
            onClick={() => onChange('dismiss', false)}
            className={classes.button}
          >
            {dismissBtnName || 'Cancel'}
          </Button>
        ) : (
          []
        )}
        <Button
          color="default"
          onClick={() => onChange('btnClick', false)}
          variant="contained"
          className={classes.button}
        >
          {secondaryBtnName || 'Cancel'}
        </Button>
        {mainBtnName && (
          <Button
            color="primary"
            onClick={() => onChange('btnClick', true)}
            disabled={buttonDisable}
            variant="contained"
            className={classes.button}
          >
            {buttonDisable ? (
              <CircularProgress size={30} my={5} />
            ) : (
              mainBtnName
            )}
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
};

export default CustomDialog;
