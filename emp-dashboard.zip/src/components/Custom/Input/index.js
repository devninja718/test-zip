import React, { useEffect, useState, forwardRef } from 'react';
import clsx from 'clsx';
import { Box, TextField } from '@material-ui/core';
import useStyles from './style';

const CustomInput = ({
  label,
  type,
  style,
  resources,
  error,
  autoFocus,
  helperText,
  onChange,
  station,
  ...rest
}) => {
  const classes = useStyles();
  const [defaultValue, setDefaultValue] = useState();

  useEffect(() => {
    setDefaultValue(resources);
  }, [resources]);

  const handleChange = (e) => {
    if (label === 'SMS') {
      if (!isNaN(e.target.value)) onChange(e.target.value);
    } else {
      onChange(e.target.value);
    }
  };
  return (
    <>
      {station ? (
        <>
          <Box className={classes.station}>
            {label}: {resources}
          </Box>
        </>
      ) : (
        <Box
          className={clsx(classes.root, {
            [style]: style
          })}
          component={TextField}
          value={resources}
          defaultValue={defaultValue}
          // inputRef={(input) => input && input.focus()}
          type={type}
          label={label}
          autoFocus={autoFocus}
          onChange={handleChange}
          {...rest}
          error={error}
          helperText={error && helperText ? helperText : ''}
          InputProps={{
            style: { fontSize: 14 }
          }}
          InputLabelProps={{ style: { fontSize: 14 } }}
        />
      )}
    </>
  );
};

export default forwardRef(CustomInput);
