/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect } from 'react';
import { Box, Grid, Typography } from '@material-ui/core';
import { CustomSelectBox } from '@app/components/Custom';
import StatesList from '@app/constants/states.json';
import graphql from '@app/graphql';
import { useQuery, useLazyQuery } from '@apollo/client';
import { useFilterContext } from '@app/providers/FilterContext';
import { useUserContext } from '@app/providers/UserContext';
import useStyles from './style';
import { usePaginationContext } from '@app/providers/Pagination';
import SystemNotifcation from '../SystemNotification';
import { useHistory } from 'react-router-dom';
import { useViewMethodContext } from '@app/providers/ViewMethodContext';
import ToggleButton from '@material-ui/lab/ToggleButton';
import ToggleButtonGroup from '@material-ui/lab/ToggleButtonGroup';
import { Cookies } from 'react-cookie';
import { en } from '@app/language';
import { useMenuContext } from '@app/providers/MenuContext';

const CustomFilterBar = () => {
  const classes = useStyles();
  const pathName = window.location.pathname;
  const [currentUser] = useUserContext();
  const {
    filterStateValue,
    setFilterStateValue,
    filteredStationList,
    setFilteredStationList,
    filteredStationId,
    setFilteredStationId,
    filteredDistrictId,
    setFilteredDistrictId,
    filteredDistrictList,
    setFilteredDistrictList,
    districts,
    setDistricts,
    setCurrentSelectedType,
    currentSelectedType,
    stations,
    userDataforStations,
    userDataforDistricts
  } = useFilterContext();
  const [stationLoadedData, setStationLoadedData] = useState([]);
  const [systemMessages, setSystemMessages] = useState([]);
  const [updateStationWithAllState, setUpdateStationWithAllState] =
    useState(false);
  const [isShowingSystemNotification, setShowingSystemNotification] = useState(
    true //!localStorage.getItem('hideSystemNotification')
  );
  const [messageWidth, setMessageWidth] = useState('100%');
  const [, , , , isLeftMenuOpen, setIsLeftMenuOpen] = useMenuContext();
  const [
    classVariables,
    setClassVariables,
    classWithoutAuthorVariables,
    setClassWithoutAuthorVariables
  ] = usePaginationContext();
  const history = useHistory();
  const { viewMethod, setViewMethod } = useViewMethodContext();

  const handleViewModeChange = (event, newViewMode) => {
    const cookies = new Cookies();
    cookies.set('viewMode', newViewMode);

    setViewMethod(newViewMode);
  };

  const userInfo = currentUser || null;
  const [fetchTimer, setFetchTimer] = useState();

  const districtVariables = {
    id: userInfo?.parentId,
    schemaType: 'district',
    offset: null,
    name: null
  };

  const {
    loading: districtLoading,
    error: districtError,
    data: districtData
  } = useQuery(graphql.queries.DistrictGrouping, {
    variables: districtVariables,
    fetchPolicy: 'cache-and-network',
    nextFetchPolicy: 'cache-first'
  });

  const [
    getSystemMessages,
    {
      loading: systemNotificationsLoading,
      data: systemNotificationsData,
      error: systemNotificationsError
    }
  ] = useLazyQuery(graphql.queries.grouping, {
    fetchPolicy: 'cache-and-network',
    nextFetchPolicy: 'cache-first'
  });

  const fetchSystemMessages = async () => {
    await getSystemMessages({
      variables: {
        schemaType: 'sysMessage'
      }
    });
  };

  useEffect(() => {
    if (stations) {
      setStationLoadedData(stations);
    }
  }, [stations]);

  useEffect(() => {
    fetchSystemMessages();
    fetchMessagesEvery10mins();
  }, []);

  useEffect(() => {
    if (
      !systemNotificationsLoading &&
      !systemNotificationsError &&
      systemNotificationsData
    ) {
      let currentDate = new Date();
      setSystemMessages(
        systemNotificationsData?.grouping?.filter(
          (item) =>
            currentDate > new Date(item.schedule?.startAt) &&
            currentDate < new Date(item.schedule?.endAt)
        )
      );
    }
  }, [
    systemNotificationsLoading,
    systemNotificationsData,
    systemNotificationsError
  ]);

  useEffect(() => {
    if (!history?.location?.pathname.includes('topology/')) {
      setFilteredStationId('all');
      setFilteredDistrictId('all');
    }
    setMessageWidth(
      userInfo?.schemaType !== 'superAdmin' &&
        userInfo?.schemaType !== 'sysAdmin' &&
        (history?.location?.pathname.includes('/materials') ||
          history?.location?.pathname.includes('/topology'))
        ? history?.location?.pathname.includes('/materials')
          ? !isLeftMenuOpen
            ? 'calc(100% - 228px)'
            : 'calc(100% - 380px)'
          : !isLeftMenuOpen
          ? 'calc(100% - 178px)'
          : userInfo?.schemaType === 'stationAdmin'
          ? 'calc(100% - 330px)'
          : 'calc(100% - 200px)'
        : history?.location?.pathname.includes('/topology')
        ? !isLeftMenuOpen
          ? 'calc(100% - 438px)'
          : 'calc(100% - 590px)'
        : history?.location?.pathname.includes('/materials')
        ? !isLeftMenuOpen
          ? 'calc(100% - 618px)'
          : 'calc(100% - 770px)'
        : !isLeftMenuOpen
        ? 'calc(100% - 48px)'
        : 'calc(100% - 200px)'
    );
  }, [history?.location?.pathname, isLeftMenuOpen]);

  useEffect(() => {
    if (!districtLoading && !districtError && districtData) {
      const { grouping } = districtData;
      const districtList = [];
      grouping.map((item) =>
        districtList.push({ ...item, label: item['name'], value: item['_id'] })
      );
      setDistricts(districtList);
      setFilteredDistrictList(
        districtList.map((item) => ({
          label: item['name'],
          value: item['_id']
        }))
      );
    }
  }, [districtLoading, districtError, districtData]);

  const stateListFromTopology = stationLoadedData
    ?.map((item) => item?.topology?.state)
    ?.filter((item) => item !== null && item?.length > 0);

  const filteredStateList = StatesList.filter((item) =>
    stateListFromTopology.includes(item?.value)
  );

  const fetchMessagesEvery10mins = () => {
    if (fetchTimer) clearInterval(fetchTimer);
    const interval = setInterval(function () {
      fetchSystemMessages();
      console.log('refetch multiassets');
    }, 600000);
    setFetchTimer(interval);
    console.log('timer triggered');
  };

  const handleStateChange = (data) => {
    console.log(data);
    setCurrentSelectedType('state');
    setFilterStateValue(data?.value);
    if (data?.value === 'all') {
      setFilteredDistrictId('all');
      setFilteredStationId('all');
    }
  };

  const handleStationChange = (data) => {
    setCurrentSelectedType('station');
    setFilteredStationId(data?.value);
    if (data?.value === 'all') {
      setFilteredDistrictId('all');
    }
  };

  const handleDistrictChange = (data) => {
    setCurrentSelectedType('district');
    setFilteredDistrictId(data?.value);
  };

  useEffect(() => {
    if (
      userInfo?.schemaType === 'superAdmin' ||
      userInfo?.schemaType === 'sysAdmin'
    ) {
      if (filterStateValue === 'all') {
        setClassVariables({
          ...classVariables,
          topology: null,
          stationId: null,
          state: null
        });
        setClassWithoutAuthorVariables({
          ...classWithoutAuthorVariables,
          topology: null,
          stationId: null,
          state: null
        });
      } else {
        if (!updateStationWithAllState) {
          setClassVariables({
            ...classVariables,
            topology: { state: filterStateValue },
            state: filterStateValue,
            stationId: null
          });
          setClassWithoutAuthorVariables({
            ...classWithoutAuthorVariables,
            topology: { state: filterStateValue },
            state: filterStateValue,
            stationId: null
          });
        } else {
          setClassVariables({
            ...classVariables,
            topology: { state: filterStateValue },
            state: filterStateValue
          });
          setClassWithoutAuthorVariables({
            ...classWithoutAuthorVariables,
            topology: { state: filterStateValue },
            state: filterStateValue
          });
        }
        setUpdateStationWithAllState(false);
      }
    }
  }, [filterStateValue]);

  useEffect(() => {
    if (
      userInfo?.schemaType === 'superAdmin' ||
      userInfo?.schemaType === 'sysAdmin'
    ) {
      if (filteredStationId === 'all') {
        if (filterStateValue === 'all') {
          setClassVariables({
            ...classVariables,
            topology: null,
            stationId: null,
            state: null
          });
          setClassWithoutAuthorVariables({
            ...classWithoutAuthorVariables,
            topology: null,
            stationId: null,
            state: null
          });
        } else {
          setClassVariables({
            ...classVariables,
            stationId: null,
            topology: {
              ...classVariables?.topology,
              station: null
            }
          });
          setClassWithoutAuthorVariables({
            ...classWithoutAuthorVariables,
            stationId: null,
            topology: {
              ...classWithoutAuthorVariables?.topology,
              station: null
            }
          });
        }
      } else {
        setClassVariables({
          ...classVariables,
          stationId: filteredStationId,
          topology: {
            ...classVariables.topology,
            station: filteredStationId
          }
        });
        setClassWithoutAuthorVariables({
          ...classWithoutAuthorVariables,
          stationId: filteredStationId,
          topology: {
            ...classWithoutAuthorVariables.topology,
            station: filteredStationId
          }
        });
      }
    }
  }, [filteredStationId]);

  useEffect(() => {
    if (filteredDistrictId && filteredDistrictId !== 'all') {
      const dist = districts.find((item) => item._id === filteredDistrictId);
      if (dist && filteredStationId !== dist.parentId) {
        setFilteredStationId(dist.parentId);
        setFilterStateValue(dist?.topology?.state);
      }
    }

    if (
      userInfo?.schemaType === 'superAdmin' ||
      userInfo?.schemaType === 'sysAdmin'
    ) {
      if (filteredDistrictId === 'all') {
        if (filteredStationId === 'all') {
          if (filterStateValue === 'all') {
            setClassVariables({
              ...classVariables,
              topology: null,
              stationId: null,
              districtId: null,
              state: null
            });
            setClassWithoutAuthorVariables({
              ...classWithoutAuthorVariables,
              topology: null,
              districtId: null,
              stationId: null,
              state: null
            });
          } else {
            setClassVariables({
              ...classVariables,
              districtId: null,
              stationId: null,
              topology: {
                ...classVariables?.topology,
                station: null
              }
            });
            setClassWithoutAuthorVariables({
              ...classWithoutAuthorVariables,
              districtId: null,
              stationId: null,
              topology: {
                ...classWithoutAuthorVariables?.topology,
                station: null
              }
            });
          }
        } else {
          setClassVariables({
            ...classVariables,
            districtId: null,
            stationId: filteredStationId,
            topology: {
              ...classVariables.topology,
              station: filteredStationId
            }
          });
          setClassWithoutAuthorVariables({
            ...classWithoutAuthorVariables,
            districtId: null,
            stationId: filteredStationId,
            topology: {
              ...classWithoutAuthorVariables.topology,
              station: filteredStationId
            }
          });
        }
      } else {
        setClassVariables({
          ...classVariables,
          districtId: filteredDistrictId,
          topology: {
            ...classVariables.topology,
            district: filteredDistrictId
          }
        });
        setClassWithoutAuthorVariables({
          ...classWithoutAuthorVariables,
          districtId: filteredDistrictId,
          topology: {
            ...classWithoutAuthorVariables.topology,
            district: filteredDistrictId
          }
        });
      }
    }
  }, [filteredDistrictId]);

  useEffect(() => {
    const filteredStion = stationLoadedData
      ?.filter((item) => {
        return filterStateValue === 'all'
          ? true
          : item.topology?.state === filterStateValue;
      })
      .map((item) => {
        return {
          label: item.name,
          value: item._id
        };
      });

    if (
      history.location.pathname.includes('users') &&
      userDataforStations.length > 0
    ) {
      const filterdStation = filteredStion.filter((el) => {
        let aaaa = false;
        for (let i = 0; i < userDataforStations.length; i++) {
          if (el.value === userDataforStations[i]?.topology?.station) {
            aaaa = true;
          }
        }
        return aaaa ? true : false;
      });

      setFilteredStationList(filterdStation);
    } else {
      if (
        history.location.pathname.includes('users') &&
        (userDataforStations == null || userDataforStations.length === 0)
      ) {
        setFilteredStationList([]);
      } else {
        setFilteredStationList(filteredStion);
      }
    }

    // setFilteredStationList(filteredStion);
    if (
      userInfo?.schemaType === 'educator' ||
      userInfo?.schemaType === 'schoolAdmin'
    ) {
      if (stationLoadedData) {
        let userStationID =
          userInfo.topology && userInfo.topology?.station
            ? userInfo.topology?.station
            : null;
        if (userStationID) {
          const station = stationLoadedData.find(
            (item) => item._id === userStationID
          );
          setFilterStateValue(station?.topology?.state);
          setFilteredStationId(station?._id);
        } else {
          if (userInfo?.schemaType === 'districtAdmin' && districts) {
            let userDistrictId =
              userInfo.topology && userInfo.topology?.district
                ? userInfo.topology?.district
                : userInfo.parentId;
            if (userDistrictId) {
              const userDistrict = districts.find(
                (el) => el._id === userDistrictId
              );
              if (userDistrict) {
                const station = stationLoadedData.find(
                  (item) => item._id === userDistrict.topology?.station
                );
                setFilterStateValue(station?.topology?.state);
                setFilteredStationId(station?._id);
              }
            }
          }
        }

        let userDistrictId =
          userInfo.topology && userInfo.topology?.district
            ? userInfo.topology?.district
            : userInfo.parentId;
        if (userDistrictId) {
          setFilteredDistrictId(userDistrictId);
        }
      }
    } else {
      const station = filteredStion.find(
        (item) => item.value === filteredStationId
      );
      if (!station) {
        setFilteredStationId('all');
      }
    }
  }, [
    userInfo,
    filterStateValue,
    stationLoadedData,
    districts,
    userDataforStations,
    userDataforDistricts
  ]);

  useEffect(() => {
    if (districts) {
      let ftDistricts = [];
      if (filteredStationId === 'all') {
        ftDistricts = districts
          .filter((item) =>
            filteredStationList
              .map((item) => item.value)
              .includes(item.parentId)
          )
          .map((item) => ({ label: item['name'], value: item['_id'] }));
      } else {
        ftDistricts = districts
          .filter((item) => item.topology?.station === filteredStationId)
          .map((item) => ({ label: item['name'], value: item['_id'] }));
      }

      if (
        history.location.pathname.includes('users') &&
        userDataforDistricts.length > 0
      ) {
        const filterdStation = ftDistricts.filter((el) => {
          let aaaa = false;
          for (let i = 0; i < userDataforDistricts.length; i++) {
            if (el.value === userDataforDistricts[i]?.topology?.district) {
              aaaa = true;
            }
          }
          return aaaa ? true : false;
        });

        setFilteredDistrictList(filterdStation);
      } else {
        setFilteredDistrictList(ftDistricts);
      }
    }

    if (filterStateValue === 'all' && filteredStationId !== 'all') {
      if (currentSelectedType === 'station') {
        const station = stationLoadedData.find(
          (item) => item._id === filteredStationId
        );
        if (station) {
          setFilterStateValue(station.topology?.state);
          setUpdateStationWithAllState(true);
        }
      }
    }
  }, [
    filteredStationId,
    filteredStationList,
    userDataforStations,
    userDataforDistricts
  ]);

  useEffect(() => {
    if (filteredDistrictList) {
      const distIds = filteredDistrictList.map((item) => item.value);
      if (!distIds.includes(filteredDistrictId)) {
        setFilteredDistrictId('all');
      }
    }
  }, [filteredDistrictList]);

  const handleClickCloseButton = () => {
    setShowingSystemNotification(false);
    localStorage.setItem('hideSystemNotification', true);
  };

  const handleViewMethodChange = (data) => {
    setViewMethod(data?.value);
  };

  return (
    <Box
      className={classes.root}
      width="100%"
      display="flex"
      // alignItems="center"
    >
      {pathName.includes('/topology') && (
        <div className={classes.topologyContainer}>
          {!(
            userInfo?.schemaType === 'stationAdmin' ||
            userInfo?.schemaType === 'districtAdmin' ||
            userInfo?.schemaType === 'educator' ||
            userInfo?.schemaType === 'schoolAdmin'
          ) && (
            <>
              <CustomSelectBox
                variant="outlined"
                addMarginTop={true}
                style={classes.selectFilter}
                value={filterStateValue ? filterStateValue : 'all'}
                resources={[
                  { label: 'All States', value: 'all' },
                  ...filteredStateList
                ]}
                onChange={handleStateChange}
                size="small"
                disabled={
                  userInfo?.schemaType === 'stationAdmin' ||
                  userInfo?.schemaType === 'districtAdmin' ||
                  userInfo?.schemaType === 'educator' ||
                  userInfo?.schemaType === 'schoolAdmin'
                    ? true
                    : false
                }
              />
              <CustomSelectBox
                variant="outlined"
                addMarginTop={true}
                style={classes.selectFilter}
                value={filteredStationId ? filteredStationId : 'all'}
                resources={[
                  { label: en['All Stations'], value: 'all' },
                  ...filteredStationList
                ]}
                onChange={handleStationChange}
                size="small"
                disabled={
                  userInfo?.schemaType === 'stationAdmin' ||
                  userInfo?.schemaType === 'districtAdmin' ||
                  userInfo?.schemaType === 'educator' ||
                  userInfo?.schemaType === 'schoolAdmin'
                    ? true
                    : false
                }
              />
            </>
          )}
          {!(
            userInfo?.schemaType === 'districtAdmin' ||
            userInfo?.schemaType === 'educator' ||
            userInfo?.schemaType === 'schoolAdmin'
          ) && (
            <CustomSelectBox
              variant="outlined"
              addMarginTop={true}
              style={classes.selectFilter}
              value={
                filteredDistrictId?.length > 0 ? filteredDistrictId : 'all'
              }
              resources={[
                { label: 'All Districts', value: 'all' },
                ...filteredDistrictList
              ]}
              onChange={handleDistrictChange}
              size="small"
              disabled={
                userInfo?.schemaType === 'stationAdmin' ||
                userInfo?.schemaType === 'districtAdmin' ||
                userInfo?.schemaType === 'educator' ||
                userInfo?.schemaType === 'schoolAdmin'
                  ? true
                  : false
              }
            />
          )}
        </div>
      )}

      {pathName.includes('/materials') && (
        <div style={{ display: 'flex' }}>
          {(userInfo?.schemaType === 'sysAdmin' ||
            userInfo.schemaType === 'superAdmin') && (
            <div className={classes.topologyContainer}>
              <CustomSelectBox
                variant="outlined"
                addMarginTop={true}
                style={classes.selectFilter}
                value={filterStateValue?.length > 0 ? filterStateValue : 'all'}
                resources={[
                  { label: 'All States', value: 'all' },
                  ...filteredStateList
                ]}
                onChange={handleStateChange}
                size="small"
                disabled={
                  userInfo?.schemaType === 'districtAdmin' ||
                  userInfo?.schemaType === 'schoolAdmin'
                    ? true
                    : false
                }
              />
              <CustomSelectBox
                variant="outlined"
                addMarginTop={true}
                style={classes.selectFilter}
                value={filteredStationId ? filteredStationId : 'all'}
                resources={[
                  { label: en['All Stations'], value: 'all' },
                  ...filteredStationList
                ]}
                onChange={handleStationChange}
                size="small"
                disabled={
                  userInfo?.schemaType === 'stationAdmin' ||
                  userInfo?.schemaType === 'districtAdmin' ||
                  userInfo?.schemaType === 'educator' ||
                  userInfo?.schemaType === 'schoolAdmin'
                    ? true
                    : false
                }
              />
              <CustomSelectBox
                variant="outlined"
                addMarginTop={true}
                style={classes.selectFilter}
                value={
                  filteredDistrictId?.length > 0 ? filteredDistrictId : 'all'
                }
                resources={[
                  { label: 'All Districts', value: 'all' },
                  ...filteredDistrictList
                ]}
                onChange={handleDistrictChange}
                size="small"
                disabled={
                  userInfo?.schemaType === 'districtAdmin' ||
                  userInfo?.schemaType === 'educator' ||
                  userInfo?.schemaType === 'schoolAdmin'
                    ? true
                    : false
                }
              />
            </div>
          )}
        </div>
      )}

      {
        <div
          style={{
            height: '48px',
            width: messageWidth,
            border: '1px solid #dddddd',
            borderRadius: '3px',
            display: 'flex',
            justifyContent: 'center'
          }}
        >
          {isShowingSystemNotification && (
            <div
              style={{
                width: '100%'
              }}
            >
              <SystemNotifcation // systemNotificationsData
                list={systemMessages}
                onClose={handleClickCloseButton}
              />
            </div>
          )}
          {pathName.includes('/materials') && (
            <Grid
              className={classes.root}
              style={{ display: 'flex', right: 5 }}
            >
              <ToggleButtonGroup
                value={viewMethod}
                exclusive
                onChange={handleViewModeChange}
                aria-label="view-mode"
                style={{ paddingBottom: '1px' }}
              >
                <ToggleButton
                  value="list"
                  aria-label="left aligned"
                  classes={{ label: classes.toggleButton }}
                >
                  List View
                </ToggleButton>
                <ToggleButton
                  value="card"
                  aria-label="centered"
                  classes={{ label: classes.toggleButton }}
                >
                  Card View
                </ToggleButton>
              </ToggleButtonGroup>
              {/* <Typography variant="body2" style={{ margin: 'auto' }}>
                <Box>View Mode :</Box>
              </Typography>
              <CustomSelectBox
                variant="outlined"
                addMarginTop={true}
                style={classes.selectFilter}
                value={viewMethod}
                resources={[
                  { label: 'List View', value: 'list' },
                  { label: 'Card View', value: 'card' }
                ]}
                onChange={handleViewMethodChange}
                size="small"
              /> */}
            </Grid>
          )}
        </div>
      }
    </Box>
  );
};

export default CustomFilterBar;
