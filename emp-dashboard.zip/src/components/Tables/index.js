export { default as StudentTable } from './Student';
export { default as EducatorTable } from './Educator';
export { default as UserTable } from './User';
export { default as AdminUserTable } from './Admin';
export { default as GalleryTable } from './Gallery';
export { default as LibraryTable } from './Library';
