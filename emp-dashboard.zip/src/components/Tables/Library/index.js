/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import clsx from 'clsx';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Paper from '@material-ui/core/Paper';
import Pagination from '@material-ui/lab/Pagination';
import { useLazyQuery, useMutation } from '@apollo/client';
import graphql from '@app/graphql';
import JSONEditor from '@app/components/JSONEditor';
import { getNotificationOpt } from '@app/constants/Notifications';
import { useNotifyContext } from '@app/providers/NotifyContext';
import { faCopy, faInfo } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Box, IconButton, Grid, Button, FormControl } from '@material-ui/core';
import { CustomSelectBox } from '@app/components/Custom';
import { Close } from '@material-ui/icons';
import useStyles, { useToolbarStyles } from './style';
import { CustomDialog } from '@app/components/Custom';
import { usePageCountContext } from '@app/providers/PageCountContext';
import { Card, CardContent } from '@material-ui/core';
import { useUserContext } from '@app/providers/UserContext';
import AttachmentPreview from '@app/components/Forms/Attachment/Preview';
import { faArrowLeft } from '@fortawesome/free-solid-svg-icons';
import { en } from '@app/language';

function LibraryTableHead(props) {
  const { classes, order, orderBy, onRequestSort } = props;
  const headCells = [
    { id: 'extId', numeric: false, disablePadding: false, label: 'ExtId' },
    { id: 'name', numeric: false, disablePadding: false, label: 'Name' },
    { id: 'title', numeric: false, disablePadding: false, label: 'Title' },
    { id: 'short', numeric: false, disablePadding: false, label: 'Short' },
    { id: 'long', numeric: false, disablePadding: false, label: 'Long' },
    {
      id: 'createdAt',
      numeric: false,
      disablePadding: false,
      label: 'CreatedAt'
    },
    { id: 'action', numeric: true, disablePadding: false, label: 'Actions' }
  ];

  const createSortHandler = (property) => (event) => {
    onRequestSort(event, property);
  };

  return (
    <TableHead>
      <TableRow>
        {headCells.map((headCell) => (
          <TableCell
            key={headCell.id}
            align={headCell.numeric ? 'center' : 'center'}
            padding={headCell.disablePadding ? 'none' : 'default'}
            sortDirection={orderBy === headCell.id ? order : false}
          >
            {headCell.id === 'name' ? (
              <TableSortLabel
                active={orderBy === headCell.id}
                direction={orderBy === headCell.id ? order : 'asc'}
                onClick={createSortHandler(headCell.id)}
              >
                {headCell.label}
                {orderBy === headCell.id ? (
                  <span className={classes.visuallyHidden}>
                    {order === 'desc'
                      ? 'sorted descending'
                      : 'sorted ascending'}
                  </span>
                ) : null}
              </TableSortLabel>
            ) : (
              <>{headCell.label}</>
            )}
          </TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
}

LibraryTableHead.propTypes = {
  classes: PropTypes.object.isRequired,
  numSelected: PropTypes.number.isRequired,
  onRequestSort: PropTypes.func.isRequired,
  onSelectAllClick: PropTypes.func.isRequired,
  order: PropTypes.oneOf(['asc', 'desc']).isRequired,
  orderBy: PropTypes.string.isRequired,
  rowCount: PropTypes.number.isRequired
};

const LibraryTableToolbar = (props) => {
  const classes = useToolbarStyles();
  const { library } = props;

  return (
    <Toolbar className={clsx(classes.root)}>
      <Typography
        className={classes.title}
        variant="h6"
        id="tableTitle"
        component="div"
      >
        {library.name}
      </Typography>
    </Toolbar>
  );
};

LibraryTableToolbar.propTypes = {
  numSelected: PropTypes.number.isRequired,
  library: PropTypes.string.isRequired
};

export default function LibraryTable({
  library,
  pageMenu,
  sourceType,
  searchAction,
  setSearchAction
}) {
  const [contentData, setContentData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const classes = useStyles();
  const [order, setOrder] = React.useState('asc');
  const [orderBy, setOrderBy] = React.useState('calories');
  const [selected, setSelected] = React.useState([]);
  const [page, setPage] = React.useState(1);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);
  const { pageCount, setPageCount } = usePageCountContext();
  const [totalPage, setTotalPage] = useState(0);
  const [openInfo, setOpenInfo] = useState(false);
  const [selectedInfo, setSelectedInfo] = useState(null);
  const { notify } = useNotifyContext();
  const [showingMoreItem, setShowingMoreItem] = useState(null);
  const [currentUser] = useUserContext();
  const [openCopy, setOpenCopy] = useState(false);
  const [classLoadedData, setClassLoadedData] = useState([]);
  const [lastCopiedClass, setLastCopiedClass] = useState();
  const [selectedResourceCopy, setSelectedResourceCopy] = useState();

  const [copyResourceToMaterial] = useMutation(
    graphql.mutations.copyResourceToMaterial
  );
  //filter options
  const variables = library?.type
    ? {
        id: null,
        schemaType: library.schemaType,
        type: library.type,
        offset: null,
        name: null
      }
    : {
        id: null,
        schemaType: library.schemaType,
        offset: null,
        name: null
      };

  const classVariable = {
    id: null,
    schemaType: 'class',
    offset: null,
    name: null
  };

  const [getData, { loading, data, error }] = useLazyQuery(
    graphql.queries.LibraryGrouping
  );

  const [
    getClasses,
    { loading: loadingClasses, data: classData, error: errorClassLoading }
  ] = useLazyQuery(graphql.queries.ClassGrouping);

  useEffect(() => {
    if (pageMenu === 'Resources') {
      if (searchAction) {
        fetchData();
        fetchClasses();
      }
    } else {
      fetchData();
    }
    fetchClasses();
  }, []);

  useEffect(() => {
    setShowingMoreItem(null);
    setPage(1);
  }, [library]);

  useEffect(() => {
    if (searchAction) {
      if (contentData && contentData.length > 0) {
        filterLibraries(contentData);
      }
      fetchData();
      setShowingMoreItem(null);
      setPage(1);
      setSearchAction(false);
    }
  }, [searchAction]);

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleSelectAllClick = (event) => {
    if (event.target.checked) {
      const newSelecteds = contentData.map((n) => n._id);
      setSelected(newSelecteds);
      return;
    }
    setSelected([]);
  };

  const handleClick = (event, name) => {
    const selectedIndex = selected.indexOf(name);
    let newSelected = [];

    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, name);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1)
      );
    }

    setSelected(newSelected);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const emptyRows =
    pageCount - Math.min(pageCount, contentData.length - page * pageCount);

  const fetchData = async () => {
    await getData({
      variables: variables,
      fetchPolicy: 'cache-and-network',
      nextFetchPolicy: 'cache-first'
    });
  };

  const fetchClasses = async () => {
    await getClasses({
      variables: classVariable,
      fetchPolicy: 'cache-and-network',
      nextFetchPolicy: 'cache-first'
    });
  };

  useEffect(() => {
    // setTotalPage(Math.ceil(contentData.length / pageCount));
    if (contentData && contentData.length > 0) {
      filterLibraries(contentData);
    }
    if (pageMenu === 'Resources') {
      if (searchAction) {
        fetchData();
      }
    } else {
      fetchData();
    }
  }, [library, pageCount]);

  const filterLibraries = (totalData) => {
    let filteredLibriries = [];
    if (pageMenu === 'Resources' && sourceType !== 'all') {
      filteredLibriries = totalData
        .slice()
        .filter((item) => item.type === sourceType);
    } else {
      filteredLibriries = totalData.slice();
    }
    let newData = [];
    for (const library of filteredLibriries) {
      newData.push({
        ...library,
        isVideoPlay: false
      });
    }
    setFilteredData(newData);
    setTotalPage(Math.ceil(filteredLibriries.length / pageCount));
  };

  useEffect(() => {
    if (!error && !loading && data) {
      const { grouping } = data;
      if (grouping) {
        setContentData(grouping);
        filterLibraries(grouping);
      }
    }
  }, [error, loading, data]);

  useEffect(() => {
    if (!errorClassLoading && !loadingClasses && classData) {
      const { grouping } = classData;
      if (grouping) {
        const formatedClasses = grouping.map((item) => ({
          label: item.name,
          value: item._id
        }));
        if (currentUser.schemaType === 'stationAdmin') {
          let stationClasses = grouping
            .filter((item) => item.topology?.station === currentUser.parentId)
            .map((item) => ({
              label: item.name,
              value: item._id
            }));
          setClassLoadedData(stationClasses);
          setLastCopiedClass(
            stationClasses?.length > 0 ? formatedClasses[0].value : null
          );
        } else if (currentUser.schemaType === 'districtAdmin') {
          let districtClasses = grouping
            .filter((item) => item.topology?.district === currentUser.parentId)
            .map((item) => ({
              label: item.name,
              value: item._id
            }));
          setClassLoadedData(districtClasses);
          setLastCopiedClass(
            districtClasses?.length > 0 ? formatedClasses[0].value : null
          );
        } else if (currentUser.schemaType === 'schoolAdmin') {
          let schoolClasses = grouping
            .filter((item) => item.parentId === currentUser.parentId)
            .map((item) => ({
              label: item.name,
              value: item._id
            }));
          setClassLoadedData(schoolClasses);
          setLastCopiedClass(
            schoolClasses?.length > 0 ? formatedClasses[0].value : null
          );
        } else if (currentUser.schemaType === 'educator') {
          let educatorClasses = grouping
            .filter((item) => item.authorIdList?.includes(currentUser._id))
            .map((item) => ({
              label: item.name,
              value: item._id
            }));
          setClassLoadedData(educatorClasses);
          setLastCopiedClass(
            educatorClasses?.length > 0 ? formatedClasses[0].value : null
          );
        } else {
          setClassLoadedData(formatedClasses);
          setLastCopiedClass(
            formatedClasses?.length > 0 ? formatedClasses[0].value : null
          );
        }
      }
    }
  }, [errorClassLoading, loadingClasses, classData]);

  const copyResourceToClass = async (resourceId) => {
    if (
      lastCopiedClass == null ||
      classLoadedData == null ||
      classLoadedData?.length === 0
    ) {
      const notiOps = getNotificationOpt('resource', 'warning', 'needClass');
      notify(notiOps.message, notiOps.options);
      return;
    }
    const variables = {
      classId: lastCopiedClass,
      resourceId: resourceId
    };
    console.log(variables);
    await copyResourceToMaterial({
      variables
    });
    const notiOps = getNotificationOpt('resource', 'success', 'copy');
    notify(notiOps.message, notiOps.options);
  };

  const handleTableChange = async (method, value) => {
    try {
      if (method === 'info') {
        setSelectedInfo(value);
        setOpenInfo(true);
      }

      if (method === 'copy') {
        // setOpenCopy(true);
        setSelectedResourceCopy(value._id);
        await copyResourceToClass(value._id);
      }
    } catch (error) {
      console.log(error);
      console.log(error.messsage);
      const notiOps = getNotificationOpt('backend', 'error', 'wrong');
      notify(notiOps.message, notiOps.options);
    }
  };

  const handleInfoDialogChange = async (type, value) => {
    setOpenInfo(false);
  };

  const handleCopyDialogChange = async (type, value) => {
    try {
      if (value) {
        await copyResourceToClass(selectedResourceCopy);
      }
      setOpenCopy(false);
    } catch (err) {
      // const notiOps = getNotificationOpt('resource', 'error', 'update');
      // notify(notiOps.message, notiOps.options);
      console.log('copy resource', err);
    }
  };

  const handleClassCopySelect = (event) => {
    setLastCopiedClass(event.value);
  };

  const handleClickShowMore = (item) => (e) => {
    setShowingMoreItem(item);
  };

  const handleClickShowMoreCloseButton = () => {
    setShowingMoreItem(null);
  };

  const handleVidePlayState = (resId) => {
    let updatedData = [];
    for (const vidData of filteredData) {
      updatedData.push({
        ...vidData,
        isVideoPlay: vidData._id === resId
      });
    }
    setFilteredData(updatedData);
  };

  const handleVidePlayMoreView = () => {};

  const getPrimaryVideo = (data) => {
    if (!data) return {};

    let asset = data?.multimediaAssets?.find(
      (asset) =>
        asset.status === 'ready' &&
        (asset.type?.includes('video') ||
          asset.fileName?.toLowerCase().includes('.mp4'))
    );

    if (!asset) return {};

    return {
      url: `${asset.baseUrl}${asset.fileDir}${asset.fileName}`,
      type: asset.mimeType ? asset.mimeType : 'video/mp4'
    };
  };

  return (
    <div className={classes.root}>
      <Paper
        className={classes.paper}
        style={{ marginBottom: pageMenu === 'Resources' ? 32 : 0 }}
      >
        {/* <LibraryTableToolbar numSelected={selected.length} library /> */}
        {!!showingMoreItem && (
          <div>
            <Button
              onClick={handleClickShowMoreCloseButton}
              className={classes.showmoreCloseButton}
              startIcon={
                <FontAwesomeIcon
                  icon={faArrowLeft}
                  size="sm"
                  style={{
                    animationDirection: 'alternate-reverse',
                    cursor: 'pointer'
                  }}
                />
              }
              variant="contained"
              color="primary"
            >
              Back to Search
            </Button>
            <div className={classes.showmoreContainer}>
              <div
                className={classes.showmoreTitle}
                dangerouslySetInnerHTML={{
                  __html: showingMoreItem.desc?.title
                }}
              ></div>
              <div
                className={classes.showmoreShort}
                dangerouslySetInnerHTML={{
                  __html: showingMoreItem.desc?.short
                }}
              ></div>
              <div
                className={classes.showmoreLong}
                dangerouslySetInnerHTML={{ __html: showingMoreItem.desc?.long }}
              ></div>
              <CardContent style={{ marginBottom: '40px' }}>
                <AttachmentPreview
                  resources={getPrimaryVideo(showingMoreItem)}
                  autoPlay={false}
                  setPlay={handleVidePlayMoreView}
                />
              </CardContent>
              <div className={classes.showmoreCreatedAt}>
                Created At {showingMoreItem.createdAt?.substring(0, 10)}
              </div>
            </div>
          </div>
        )}
        {!showingMoreItem && (
          <TableContainer>
            <Grid container>
              {filteredData
                .slice(
                  (page - 1) * pageCount,
                  (page - 1) * pageCount + pageCount
                )
                .map((row, index) => (
                  <Card className={classes.cardRoot} key={`pbs-item-${index}`}>
                    <CardContent
                      className={classes.cardContent}
                      classes={{ root: classes.cardNameContainer }}
                    >
                      <Typography
                        variant="h6"
                        // className={clsx(classes.cardNameStyle)}
                      >
                        <div
                          className={classes.textOverflowLines}
                          dangerouslySetInnerHTML={{ __html: row.desc?.title }}
                        ></div>
                      </Typography>
                    </CardContent>
                    <CardContent
                      style={{
                        margin: '24px 0px 10px 0px',
                        paddingTop: 0,
                        paddingBottom: 0
                      }}
                    >
                      <div
                        style={{
                          marginBottom: 0,
                          marginTop: 0,
                          paddingTop: 0,
                          paddingBottom: 0
                        }}
                        dangerouslySetInnerHTML={{ __html: row.desc?.short }}
                      ></div>
                    </CardContent>
                    <CardContent style={{ paddingTop: 0, paddingBottom: 0 }}>
                      <div
                        style={{
                          wordBreak: 'break-word',
                          textOverflow: 'ellipsis',
                          overflow: 'hidden',
                          display: '-webkit-box',
                          lineHeight: '20px',
                          maxHeight: '260px',
                          WebkitLineClamp: '12',
                          WebkitBoxOrient: 'vertical',
                          paddingTop: 0,
                          paddingBottom: 0,
                          marginTop: 0
                        }}
                        dangerouslySetInnerHTML={{ __html: row.desc?.long }}
                      ></div>
                    </CardContent>

                    <CardContent style={{ marginBottom: '40px' }}>
                      <AttachmentPreview
                        resources={getPrimaryVideo(row)}
                        resId={row._id}
                        autoPlay={false}
                        isPlay={row.isVideoPlay}
                        setPlay={handleVidePlayState}
                      />
                      <div style={{ height: 20 }} />
                    </CardContent>

                    <div className={clsx(classes.cardBottom)}>
                      <div
                        style={{
                          cursor: 'pointer',
                          color: '#3f51b5',
                          marginTop: 12
                        }}
                        onClick={handleClickShowMore(row)}
                      >
                        {'More ->'}
                      </div>
                      {(currentUser.schemaType === 'superAdmin' ||
                        currentUser.schemaType === 'sysAdmin' ||
                        currentUser.schemaType === 'stationAdmin' ||
                        currentUser.schemaType === 'districtAdmin' ||
                        currentUser.schemaType === 'schoolAdmin' ||
                        currentUser.schemaType === 'educator') && (
                        <Box textAlign="center" style={{ display: 'flex' }}>
                          <CustomSelectBox
                            variant="outlined"
                            addMarginTop={true}
                            disabled={
                              classLoadedData == null ||
                              classLoadedData?.length === 0
                            }
                            style={classes.selectFilter}
                            value={lastCopiedClass}
                            resources={classLoadedData}
                            onChange={handleClassCopySelect}
                            size="small"
                          />
                          <IconButton
                            size="medium"
                            disabled={
                              classLoadedData == null ||
                              classLoadedData?.length === 0
                            }
                          >
                            <FontAwesomeIcon
                              icon={faCopy}
                              size="md"
                              style={{ cursor: 'pointer', marginRight: 5 }}
                              onClick={() => handleTableChange('copy', row)}
                            />
                            {/* {en['Copy']} */}
                          </IconButton>
                          {(currentUser.schemaType === 'superAdmin' ||
                            currentUser.schemaType === 'sysAdmin') && (
                            <IconButton size="small">
                              <FontAwesomeIcon
                                icon={faInfo}
                                size="md"
                                style={{ cursor: 'pointer' }}
                                onClick={() => handleTableChange('info', row)}
                              />
                            </IconButton>
                          )}
                        </Box>
                      )}
                    </div>
                  </Card>
                ))}
            </Grid>

            {filteredData?.length > 0 && (
              <Pagination
                count={totalPage}
                size="small"
                page={page}
                siblingCount={0}
                showFirstButton
                showLastButton
                onChange={handleChangePage}
                className={classes.pagination}
              />
            )}
          </TableContainer>
        )}

        <CustomDialog
          open={openInfo}
          title="Information"
          maxWidth="sm"
          fullWidth={true}
          onChange={handleInfoDialogChange}
        >
          <Grid item xs={12} sm={12} md={12} lg={12}>
            <JSONEditor disable={false} resources={selectedInfo} />
          </Grid>
        </CustomDialog>
        <CustomDialog
          open={openCopy}
          title="Copy Library to Class"
          mainBtnName="Copy"
          maxWidth="sm"
          fullWidth={true}
          onChange={handleCopyDialogChange}
        >
          <Grid item xs={12} sm={12} md={12} lg={12}>
            <FormControl style={{ width: '100%' }}>
              <CustomSelectBox
                variant="outlined"
                addMarginTop={true}
                style={classes.selectFilter}
                value={lastCopiedClass}
                resources={classLoadedData}
                onChange={handleClassCopySelect}
                size="small"
              />
            </FormControl>
          </Grid>
        </CustomDialog>
      </Paper>
    </div>
  );
}
