import React, { useState, useEffect } from 'react';
import { Paper, Box, Grid } from '@material-ui/core';
import { useQuery } from '@apollo/client';
import graphql from '@app/graphql';
import useStyles from './style';
import { GalleryData, CreateMode } from '@app/components/Gallery';
import { CustomDialog } from '@app/components/Custom';
import JSONEditor from '@app/components/JSONEditor';
import { usePageCountContext } from '@app/providers/PageCountContext';
import TableContainer from '@material-ui/core/TableContainer';
import Pagination from '@material-ui/lab/Pagination';
import { en } from '@app/language';

const UserTable = ({
  schemaType,
  createNew,
  setCreateNew,
  contentType,
  searchValue
}) => {
  const classes = useStyles();
  const [rows, setRows] = useState([]);
  const [totalRows, setTotalRows] = useState([]);
  const [openInfo, setOpenInfo] = useState(false);
  const [selectedInfo, setSelectedInfo] = useState(null);
  const [searchKey, setSearchKey] = useState();
  const [rawData, setRawData] = useState();

  const [page, setPage] = React.useState(1);
  const { pageCount } = usePageCountContext();
  const [totalPage, setTotalPage] = useState(0);

  const { loading, error, data, refetch } = useQuery(
    graphql.queries.GalleryGrouping,
    {
      variables: {
        id: null,
        schemaType: schemaType,
        offset: null,
        name: null
      }
    }
  );

  useEffect(() => {
    refetch();
  }, []);

  useEffect(() => {
    setTotalPage(Math.ceil(totalRows.length / pageCount));
    refetch();
  }, [schemaType, pageCount]);

  useEffect(() => {
    setPage(1);
  }, [schemaType]);

  useEffect(() => {
    if (!loading && !error) {
      const { grouping } = data;
      let sortedRows = [];
      if (grouping?.length > 1) {
        try {
          sortedRows = grouping.slice()?.sort((item1, item2) => {
            let time1 = new Date(item1.createdAt).getTime();
            let time2 = new Date(item2.createdAt).getTime();
            return time2 - time1;
          });
        } catch (error) {
          console.log(error.message);
        }
      } else {
        sortedRows = grouping;
      }

      setRawData(grouping);

      const tmp = sortedRows.map((el) => ({
        id: el['_id'],
        name: el.name,
        type: el.avatar?.type,
        icon: el.avatar?.baseUrl + el.avatar?.fileDir + el.avatar?.fileName,
        altText: el.avatar?.altText,
        tagList: el.tagList,
        avatarURL:
          el.avatar?.baseUrl + el.avatar?.fileDir + el.avatar?.fileName,
        thumbnailURL: el.avatar?.thumbnail,
        mimeType: el.avatar?.mimeType,
        schemaType: el.schemaType,
        version: el.version,
        avatar: el.avatar
      }));

      setTotalRows(tmp);
      filterRows(tmp, searchKey);
    }
  }, [loading, error, data]);

  useEffect(() => {
    if (searchValue !== null) handleSearch(searchValue);
  }, [searchValue]);

  const filterRows = (totalData, key) => {
    if (totalData?.length) {
      let copyRows = totalData.slice();
      let filteredRows = [];
      if (key == null || key === '') {
        filteredRows = totalData;
      } else {
        filteredRows = copyRows.filter((item) => {
          if (
            item.name.toLowerCase().includes(key.toLowerCase()) ||
            item.type.toLowerCase().includes(key.toLowerCase()) ||
            item.altText.toLowerCase().includes(key.toLowerCase())
          ) {
            return true;
          }
          if (item.tagList?.length) {
            let isValid = false;
            for (let tag of item.tagList) {
              if (tag.toLowerCase().includes(key.toLowerCase())) {
                isValid = true;
                break;
              }
            }
            if (isValid) {
              return true;
            } else {
              return false;
            }
          } else {
            return false;
          }
        });
      }
      setRows(filteredRows);
      setTotalPage(Math.ceil(filteredRows.length / pageCount));
    } else {
      setRows([]);
      setTotalPage(0);
    }
  };

  const onCancel = () => {
    setCreateNew(false);
  };

  const onInfo = (id) => {
    setSelectedInfo(rawData?.find((item) => item._id === id));
    setOpenInfo(true);
  };

  const handleInfoDialogChange = async (type, value) => {
    setOpenInfo(false);
  };

  const handleSearch = (value) => {
    setSearchKey(value);
    filterRows(totalRows, value);
    setPage(1);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  return (
    <Paper className={classes.root}>
      <Box>
        <Grid container justify="center" style={{ marginBottom: 10 }}>
          {createNew ? (
            <CreateMode
              schemaType={schemaType}
              onCancel={onCancel}
              onFinish={() => refetch()}
            />
          ) : (
            []
          )}
        </Grid>
        <TableContainer>
          <Grid container justify="space-evenly">
            {rows
              .slice((page - 1) * pageCount, (page - 1) * pageCount + pageCount)
              .map((item, index) => (
                <GalleryData
                  key={index}
                  {...item}
                  onFinish={() => refetch()}
                  onInfo={(value) => onInfo(value)}
                />
              ))}
          </Grid>
          <Pagination
            count={totalPage}
            size="small"
            page={page}
            siblingCount={0}
            showFirstButton
            showLastButton
            onChange={handleChangePage}
            className={classes.pagination}
          />
        </TableContainer>
        <CustomDialog
          open={openInfo}
          title={en['Information']}
          maxWidth="sm"
          fullWidth={true}
          onChange={handleInfoDialogChange}
        >
          <Grid item xs={12} sm={12} md={12} lg={12}>
            <JSONEditor disable={false} resources={selectedInfo} />
          </Grid>
        </CustomDialog>
      </Box>
    </Paper>
  );
};

export default UserTable;
