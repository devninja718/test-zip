/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { getNotificationOpt } from '@app/constants/Notifications';
import { Box, Typography, TextField } from '@material-ui/core';
import Autocomplete from '@material-ui/lab/Autocomplete';
import graphql from '@app/graphql';
import ListStudent from './List';
import useStyles from './style';
import { useNotifyContext } from '@app/providers/NotifyContext';
import { update } from '@app/utils/ApolloCacheManager';
import { useUserContext } from '@app/providers/UserContext';

const FilterStudent = ({
  resources,
  setResources,
  docId,
  onChange,
  schoolLoadedData,
  classLoadedData
}) => {
  const classes = useStyles();
  const [loadedData, setLoadedData] = useState([]);
  const { notify } = useNotifyContext();
  const [email, setEmail] = useState('');
  const [studentResources, setStudentResources] = useState([]);
  const [currentUser] = useUserContext();

  const validateEmail = (value) => {
    return new RegExp(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,15}/g).test(
      value
    );
  };

  const { loading, error, data } = useQuery(graphql.queries.userGrouping, {
    variables: {
      name: email, //validateEmail(email) ? email : 'TEMP_STRING',
      schemaType: 'student'
    }
  });

  const studentVariables = {
    schemaType: 'student',
    parentId: resources?.topology.district
  };

  const {
    loading: studentLoading,
    error: studentError,
    data: studentData
  } = useQuery(graphql.queries.userGrouping, {
    variables: studentVariables,
    fetchPolicy: 'cache-and-network',
    nextFetchPolicy: 'cache-first'
  });

  const [updateGrouping] = useMutation(graphql.mutations.updateGrouping, {
    update(cache, { data: { updateGrouping } }) {
      cache.modify({
        fields: {
          grouping(allGrouping = []) {
            const updatedGrouping = allGrouping.map((group) => {
              if (group._id === updateGrouping._id) {
                return updateGrouping;
              }
              return group;
            });
            return updatedGrouping;
          }
        }
      });
    }
  });

  useEffect(() => {
    if (!loading && !error) {
      const { grouping } = data;
      console.log(schoolLoadedData);
      console.log(grouping);
      const school = schoolLoadedData?.find(
        (item) => item?._id === resources?.parentId
      );
      console.log(school);
      let tmp = grouping.find((item) => item?.parentId === school?.parentId);
      if (tmp) {
        setLoadedData(grouping);
      }
    }
  }, [loading, error, data]);

  useEffect(() => {
    if (!studentLoading && !studentError) {
      const school = schoolLoadedData?.find(
        (item) => item?._id === resources?.parentId
      );
      const { grouping } = studentData;
      setStudentResources(
        school
          ? grouping.filter((item) => item?.parentId === school?.parentId)
          : grouping
      );
    }
  }, [studentLoading, studentError, studentData]);

  const handleListChange = async (value) => {
    function GetSortOrder(prop) {
      return function (a, b) {
        if (a[prop] > b[prop]) {
          return 1;
        } else if (a[prop] < b[prop]) {
          return -1;
        }
        return 0;
      };
    }

    try {
      let childrenIdList;
      if (value.childrenIdList) {
        if (value.childrenIdList.includes(docId)) {
          childrenIdList = [...value.childrenIdList];
        } else {
          let tmp = classLoadedData.filter(
            (el) => value.childrenIdList.includes(el._id) || el._id === docId
          );
          tmp.sort(GetSortOrder('name'));
          childrenIdList = tmp.map((el) => {
            return el._id;
          });
        }
      } else {
        childrenIdList = [docId];
      }

      // const childrenIdList = value.childrenIdList
      //   ? value.childrenIdList.includes(docId)
      //     ? [...value.childrenIdList]
      //     : [...value.childrenIdList, docId]
      //   : [docId];

      const assignList = resources.assigneeIdList
        ? resources.assigneeIdList.includes(value['_id'])
          ? [...resources.assigneeIdList]
          : [...resources.assigneeIdList, value['_id']]
        : [value['_id']];

      let statusVal = resources?.topology?.state;
      if (statusVal == null) {
        if (value.topology?.state != null && value.topology?.state !== '') {
          statusVal = value.topology?.state;
        } else {
          if (schoolLoadedData?.length > 0) {
            statusVal = schoolLoadedData[0]?.topology?.state;
          }
        }
      }

      let studentTopologyData = {
        state: statusVal,
        station: resources?.topology?.station,
        district: resources?.topology?.district,
        school: null,
        class: null
      };

      let resTopologyData = {
        state: statusVal,
        station: resources?.topology?.station,
        district: resources?.topology?.district,
        school: resources?.topology?.school,
        class: resources?._id
      };

      const variables = {
        id: value['_id'],
        schemaType: 'student',
        version: value.version,
        trackingAuthorName: currentUser?.name,
        contact: value.contact,
        topology: studentTopologyData,
        childrenIdList: childrenIdList
        // status: resources?.status
      };

      await updateGrouping({
        variables
      });

      await updateGrouping({
        variables: {
          id: resources['_id'],
          schemaType: resources.schemaType,
          version: resources.version,
          trackingAuthorName: currentUser?.name,
          assigneeIdList: assignList,
          topology: resTopologyData
        }
      });

      const notiOps = getNotificationOpt('student', 'success', 'create');
      notify(notiOps.message, notiOps.options);
      onChange('added', assignList);
    } catch (error) {
      console.log(error.message);
      const notiOps = getNotificationOpt('backend', 'error', 'create');
      notify(notiOps.message, notiOps.options);
    }
  };

  return (
    <Box>
      <Typography className={classes.title} variant="h6">
        Search Student
      </Typography>
      <Autocomplete
        freeSolo
        id="free-solo-2-demo"
        disableClearable
        options={
          studentResources && studentResources.map((option) => option.name)
        }
        onChange={(event, newValue) => {
          setEmail(newValue);
        }}
        renderInput={(params) => (
          <TextField
            {...params}
            label="Student email"
            margin="normal"
            variant="outlined"
            autoFocus={true}
            type="email"
            InputProps={{ ...params.InputProps, type: 'search' }}
          />
        )}
      />
      <ListStudent
        canShow={email.length > 0}
        loading={email.length > 0 ? loading : false}
        resources={loadedData}
        onChange={handleListChange}
      />
    </Box>
  );
};

export default FilterStudent;
