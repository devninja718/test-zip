/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { withStyles } from '@material-ui/core/styles';
import { useLazyQuery, useMutation } from '@apollo/client';
import { getNotificationOpt } from '@app/constants/Notifications';
import { useNotifyContext } from '@app/providers/NotifyContext';
import graphql from '@app/graphql';
import {
  faUser,
  faSignOutAlt,
  faCog,
  faFileImport
} from '@fortawesome/free-solid-svg-icons';
import { useTheme } from '@material-ui/core/styles';
import { useHistory } from 'react-router-dom';
import { useUserContext } from '@app/providers/UserContext';
import { useStateContext } from '@app/providers/StateContext';
import { getCurrentUTCTime } from '@app/utils/date-manager';
import ArrowDropDownIcon from '@material-ui/icons/ArrowDropDown';
import {
  Grid,
  Button,
  ListItemText,
  Menu,
  Typography,
  Box,
  MenuItem,
  IconButton
} from '@material-ui/core';
import useStyles from './style';
import { Auth } from 'aws-amplify';
import CustomModal from '@app/components/Modal';
import SettingForm from './setting';
import { getAssetUrlFromS3 } from '@app/utils/aws_s3_bucket';
import EULAModal from '@app/components/Forms/EULAModal/EULAModal';
import { en } from '@app/language';

const StyledMenu = withStyles({
  paper: {
    border: '1px solid #d3d4d5'
  },
  list: {
    padding: '0'
  }
})((props) => (
  <Menu
    elevation={0}
    getContentAnchorEl={null}
    anchorOrigin={{
      vertical: 'right',
      horizontal: 'center'
    }}
    transformOrigin={{
      vertical: 'right',
      horizontal: 'center'
    }}
    {...props}
  />
));

const StyledMenuItem = withStyles((theme) => ({
  root: {
    backgroundColor: '#37474f',
    color: '#fff',
    '&:hover': {
      color: '#000'
    },
    '&:focus': {
      backgroundColor: '#37474f',
      color: '#fff',
      '& .MuiListItemIcon-root, & .MuiListItemText-primary': {
        color: theme.palette.common.white
      }
    }
  }
}))(MenuItem);

const types = {
  sysAdmin: 'stationAdmin',
  stationAdmin: 'districtAdmin',
  districtAdmin: 'schoolAdmin',
  schoolAdmin: 'educator'
};

const UserProfile = () => {
  const classes = useStyles();
  const history = useHistory();
  const theme = useTheme();

  const [currentUser, setCurrentUser, status, setStatus] = useUserContext();
  const [isLastVersion] = useStateContext();
  const [user, setUser] = useState();
  const { notify } = useNotifyContext();
  const [schemaType, setSchemaType] = useState('sysAdmin');
  const [other, setOther] = useState();
  const [anchorEl, setAnchorEl] = useState(null);
  const [openSettings, setOpenSettings] = useState(false);
  const [assetUrl, setAssetUrl] = useState(null);
  const [openSettingModal, setOpenSettingMoal] = useState(false);
  const [openEULAModal, setOpenEULAModal] = useState(false);
  const [currentDistrict, setCurrentDistrict] = useState();
  const [currentStation, setCurrentStation] = useState();
  const [districtAssetUrl, setDistrictAssetUrl] = useState(null);

  const [updateGrouping] = useMutation(graphql.mutations.updateGrouping);
  const [upsertTracking] = useMutation(graphql.mutations.upsertTracking);
  const [getData, { loading, data, error }] = useLazyQuery(
    graphql.queries.userGrouping
  );
  const [ingestGoogle] = useMutation(graphql.mutations.ingestGoogle);

  const [
    getDistrictData,
    { loading: districtLoading, data: districtData, error: districtError }
  ] = useLazyQuery(graphql.queries.DistrictGrouping);

  const [
    getStationData,
    { loading: stationLoading, data: stationData, error: stationError }
  ] = useLazyQuery(graphql.queries.StationGrouping);

  useEffect(() => {
    if (!loading && !error && data) {
      const { grouping } = data;
      if (grouping.length) {
        setOther(grouping[0]);
        setCurrentUser(grouping[0]);
      } else {
        if (schemaType !== 'educator') {
          const nextSchemaType = types[schemaType];
          getData({
            variables: {
              name: user?.email,
              schemaType: nextSchemaType
            }
          });
          setSchemaType(nextSchemaType);
        }
      }
    }
  }, [loading, data, error]);

  useEffect(() => {
    if (!districtLoading && !districtError && districtData) {
      const { grouping } = districtData;
      if (grouping.length) {
        setCurrentDistrict(grouping[0]);
      } else {
        setCurrentDistrict();
      }
    }
  }, [districtLoading, districtData, districtError]);

  useEffect(() => {
    if (!stationLoading && !stationError && stationData) {
      const { grouping } = stationData;
      if (grouping.length) {
        setCurrentStation(grouping[0]);
      } else {
        setCurrentStation();
      }
    }
  }, [stationLoading, stationData, stationError]);

  useEffect(() => {
    if (!currentUser?.loginInfo?.EULAsignedAt) return;
    const setLoggedTime = async () => {
      try {
        const timestamp = getCurrentUTCTime();
        const result = await updateGrouping({
          variables: {
            id: currentUser['_id'],
            schemaType: currentUser.schemaType,
            version: currentUser.version,
            trackingAuthorName: currentUser?.name,
            status: 'active',
            loginInfo: {
              EULAsignedAt: currentUser?.loginInfo?.EULAsignedAt,
              lastSeenAt: timestamp,
              count: currentUser?.loginInfo?.count
                ? parseInt(currentUser?.loginInfo?.count) + 1 + ''
                : '1'
            }
          }
        });

        if (
          currentUser.schemaType === 'educator' ||
          currentUser.schemaType === 'districtAdmin'
        ) {
          /*
          await upsertTracking({
            variables: {
              schemaType: 'tracking',
              name: 'signed_in',
              parent: {
                schemaType: 'station',
                _id: currentUser?.topology?.station
              }
            }
          });
          */
          getDistrictData({
            variables: {
              id: currentUser.parentId,
              schemaType: 'district'
            }
          });
          getStationData({
            variables: {
              id: currentUser?.topology?.station,
              schemaType: 'station'
            }
          });
        } else {
          /*
          await upsertTracking({
            variables: {
              schemaType: 'tracking',
              name: 'signed_in',
              parent: {
                schemaType: currentUser?.schemaType,
                _id: currentUser?._id
              }
            }
          });
          */
        }

        localStorage?.setItem('saveLoginInfo', true);
        setStatus(false);

        if (result?.data?.updateGrouping) {
          setCurrentUser(result?.data?.updateGrouping);
        }
      } catch (err) {
        console.log(err);
      }
    };
    if (
      status &&
      currentUser &&
      currentUser.schemaType !== 'superAdmin' &&
      !localStorage?.getItem('saveLoginInfo', '')
    ) {
      setLoggedTime();
    }
    if (
      currentUser?.schemaType === 'educator' ||
      currentUser?.schemaType === 'districtAdmin'
    ) {
      getDistrictData({
        variables: {
          id: currentUser.parentId,
          schemaType: 'district'
        }
      });
      getStationData({
        variables: {
          id: currentUser?.topology?.station,
          schemaType: 'station'
        }
      });
    }
  }, [currentUser]);

  useEffect(() => {
    const loadUser = () => {
      console.log('$260');
      return Auth.currentUserInfo({ bypassCache: true });
    };

    const loadFederatedUser = () => {
      console.log('loadFederatedUser');
      return Auth.currentAuthenticatedUser({ bypassCache: true });
    };

    const onLoad = async () => {
      try {
        let currentUser = await loadUser();
        if (!currentUser?.attributes) {
          const federatedInfo = await loadFederatedUser();
          currentUser = {
            attributes: federatedInfo?.signInUserSession?.idToken?.payload
          };
        }
        setUser(currentUser?.attributes);
        console.log('currentUser', currentUser);
        if (
          currentUser?.attributes['custom:userrole']?.toLowerCase() !==
          'superadmin'
        ) {
          getData({
            variables: {
              name: currentUser?.attributes?.email,
              schemaType
            }
          });
        } else {
          setCurrentUser({
            schemaType: 'superAdmin',
            name: currentUser?.attributes?.email
          });
        }
      } catch (err) {
        console.log(err);
      }
    };
    onLoad();
  }, []);

  useEffect(async () => {
    if (String(other?.avatar?.baseUrl).includes('http')) {
      const url =
        other?.avatar?.baseUrl +
        other?.avatar?.fileDir +
        other?.avatar?.fileName;
      const assetUrl = await getAssetUrlFromS3(url, 0);
      setAssetUrl(assetUrl);
    } else {
      setAssetUrl(other?.avatar?.baseUrl);
    }
  }, [other?.avatar?.baseUrl]);

  useEffect(async () => {
    if (String(currentDistrict?.avatar?.baseUrl).includes('http')) {
      const url =
        currentDistrict?.avatar?.baseUrl +
        currentDistrict?.avatar?.fileDir +
        currentDistrict?.avatar?.fileName;
      const assetUrl = await getAssetUrlFromS3(url, 0);
      setDistrictAssetUrl(assetUrl);
    } else {
      setDistrictAssetUrl(currentDistrict?.avatar?.baseUrl);
    }
  }, [currentDistrict]);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const ingestGoogleClasses = async (type) => {
    if (currentUser?.data == null || currentUser?.data?.expiry_date == null) {
      const notiOps = getNotificationOpt(
        'googleClass',
        'warning',
        'impossibleAdmin'
      );
      notify(notiOps.message, notiOps.options);
      return;
    }
    const expireDate = new Date(currentUser.data?.expiry_date);
    const isExpired = expireDate < new Date();
    // if (isExpired) {
    //   const notiOps = getNotificationOpt(
    //     'googleClass',
    //     'warning',
    //     'expiredAdmin'
    //   );
    //   notify(notiOps.message, notiOps.options);
    //   return;
    // }
    const response = await ingestGoogle({
      variables: {
        userId: currentUser._id
      }
    });
    const notiOps = getNotificationOpt('googleClass', 'success', 'import');
    notify(notiOps.message, notiOps.options);
  };

  const handleClickSettings = (event) => {
    setOpenSettings(!openSettings);
  };

  const handleClose = () => {
    setAnchorEl(null);
    setOpenSettings(false);
  };

  const onSignOut = async () => {
    setStatus(true);
    console.log('$332');
    await Auth.signOut();
    window.localStorage.clear();
    localStorage.removeItem('ConfigParams');
    window.sessionStorage.setItem('last_path', window.location.pathname);
    history.push('/');
  };

  let firstName = !user
    ? ''
    : user['custom:firstName']
    ? user['custom:firstName']
    : other?.contact?.firstName
    ? other?.contact?.firstName
    : '';
  let lastName = !user
    ? ''
    : user['custom:lastName']
    ? user['custom:lastName']
    : other?.contact?.lastName
    ? other?.contact?.lastName
    : '';
  let userRole = !user
    ? ''
    : user['custom:userrole']
    ? user['custom:userrole']
    : other?.schemaType
    ? other?.schemaType
    : '';

  return (
    <>
      {currentUser?.schemaType === 'educator' && (
        <Grid
          className={classes.root}
          style={{ position: 'absolute', display: 'flex' }}
        >
          {districtAssetUrl && (
            <Grid
              item
              container
              justify="center"
              style={{ marginRight: '20px' }}
            >
              <img
                src={districtAssetUrl}
                style={{ width: 35, height: 35, borderRadius: '50%' }}
                alt=""
              />
            </Grid>
          )}
          <Grid item container justify="center" style={{ margin: 'auto' }}>
            {currentDistrict?.name}
          </Grid>
        </Grid>
      )}
      {/* {currentUser?.schemaType === 'districtAdmin' &&
        currentStation &&
        currentDistrict && (
          <Grid
            className={classes.root}
            style={{ position: 'absolute', display: 'flex' }}
          >
            <Typography variant="body2" style={{ marginRight: 15 }}>
              <Box>{'Station: ' + currentStation?.name}</Box>
            </Typography>
            <Typography variant="body2" style={{ marginTop: 0 }}>
              <Box>{'District: ' + currentDistrict?.name}</Box>
            </Typography>
          </Grid>
        )} */}

      <Grid className={classes.root}>
        <Grid
          container
          direction="row"
          alignItems="center"
          style={{ flexWrap: 'nowrap' }}
        >
          {currentUser?.schemaType === 'schoolAdmin' && (
            <Grid style={{ marginRight: 30 }}>
              <Button
                onClick={() => ingestGoogleClasses('ingest')}
                className={classes.actionButton}
                disabled={false}
                startIcon={
                  <FontAwesomeIcon
                    icon={faFileImport}
                    size="sm"
                    style={{ cursor: 'pointer' }}
                  />
                }
                variant="contained"
                color="primary"
              >
                {en['Ingest']}
              </Button>
            </Grid>
          )}
          <Grid item container justify="center">
            {assetUrl ? (
              <img
                title={user?.email}
                src={assetUrl}
                style={{ width: 35, height: 35, borderRadius: '50%' }}
                alt=""
              />
            ) : (
              <FontAwesomeIcon
                icon={faUser}
                size="lg"
                color={theme.palette.primary.contrastText}
                title={user?.email}
                style={{
                  background: '#b0bec5',
                  borderRadius: '100%',
                  padding: 10,
                  width: 35,
                  height: 35,
                  marginLeft: 10
                }}
              />
            )}
          </Grid>
          {user ? (
            <Grid style={{ display: 'flex', alignItems: 'center' }}>
              <Grid style={{ paddingLeft: 5, paddingRight: 4 }}>
                <ListItemText
                  primary={`${firstName} ${lastName}`}
                  classes={{ primary: classes.userNameText }}
                />
                <ListItemText
                  primary={userRole}
                  classes={{ primary: classes.roleText }}
                />
              </Grid>
            </Grid>
          ) : (
            []
          )}
          <Grid>
            <IconButton onClick={handleClick}>
              <ArrowDropDownIcon />
            </IconButton>
            <StyledMenu
              id="customized-menu"
              anchorEl={anchorEl}
              keepMounted
              open={Boolean(anchorEl)}
              onClose={handleClose}
            >
              <StyledMenuItem>
                <div onClick={handleClickSettings}>
                  <FontAwesomeIcon
                    icon={faCog}
                    size="xs"
                    style={{ marginRight: 7 }}
                  />
                  {en['Settings']}
                </div>
              </StyledMenuItem>
              {openSettings && (
                <StyledMenuItem
                  onClick={() => {
                    handleClose();
                    setOpenSettingMoal(true);
                  }}
                  classes={{ root: classes.subMenuItem }}
                >
                  {en['Config']}
                </StyledMenuItem>
              )}
              {openSettings && (
                <StyledMenuItem
                  classes={{ root: classes.subMenuItem }}
                  onClick={() => {
                    handleClose();
                    setOpenEULAModal(true);
                  }}
                >
                  EULA
                </StyledMenuItem>
              )}
              <StyledMenuItem onClick={onSignOut}>
                <FontAwesomeIcon
                  icon={faSignOutAlt}
                  size="xs"
                  style={{ marginRight: 7 }}
                />
                {en['Logout']}
              </StyledMenuItem>
            </StyledMenu>
          </Grid>
        </Grid>
      </Grid>
      <CustomModal
        icon={
          <FontAwesomeIcon icon={faCog} size="xs" style={{ marginRight: 7 }} />
        }
        title="Setting"
        Children={SettingForm}
        openModal={openSettingModal}
        setOpenModal={setOpenSettingMoal}
      />
      <EULAModal openModal={openEULAModal} setOpenModal={setOpenEULAModal} />
    </>
  );
};

export default React.memo(UserProfile);
