import { DriveEta } from '@material-ui/icons';
import React, { useEffect, useState } from 'react';
import { useStyles } from './style';
import Slider from 'react-slick';
import Tooltip from '@material-ui/core/Tooltip';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { Close } from '@material-ui/icons';
import { getAssetUrlFromS3 } from '@app/utils/aws_s3_bucket';
import { en } from '@app/language';

var sliderSettings = {
  dots: false,
  infinite: true,
  autoplaySpeed: 10000,
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: false,
  autoplay: true
};

const ConvertImage = ({ avatar, style }) => {
  const [signedURL, setSignedURL] = useState(null);

  useEffect(() => {
    if (avatar?.baseUrl && avatar?.fileName) {
      const { baseUrl, fileDir, fileName } = avatar;
      getAssetUrlFromS3(`${baseUrl}${fileDir}${fileName}`).then((res) => {
        setSignedURL(res);
      });
    }
  }, [avatar]);

  return (
    <>
      {signedURL && (
        <img className={style} src={signedURL} alt={avatar?.altText || ''} />
      )}
    </>
  );
};

const SystemNotifcation = ({ list, onClose }) => {
  const classes = useStyles();

  return (
    <Slider {...sliderSettings}>
      {list.map((item, index) => (
        <div key={`slide-${index}`}>
          <div
            className={classes.container}
            style={{ background: item?.data?.styles?.bg }}
          >
            <div className={classes.closeButton} onClick={onClose}>
              <Close style={{ fontSize: '0.8rem' }} />
            </div>
            <div className={classes.subContainer}>
              <ConvertImage avatar={item.avatar} style={classes.image} />
              <span
                className={classes.title}
                style={{ color: item?.data?.styles?.fg }}
              >
                {item.desc?.title || en['Notification with no title']}
              </span>
              <Tooltip title={item.desc?.long || ''} arrow>
                <span
                  className={classes.short}
                  style={{ color: item?.data?.styles?.fg }}
                >
                  {item.desc?.short ? `- ${item.desc?.short}` : ''}
                </span>
              </Tooltip>
            </div>
          </div>
        </div>
      ))}
    </Slider>
  );
};

export default SystemNotifcation;
