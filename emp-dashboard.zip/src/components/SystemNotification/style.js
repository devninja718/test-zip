import { makeStyles } from '@material-ui/core/styles';

export const useStyles = makeStyles((theme) => ({
  container: {
    display: 'flex',
    justifyContent: 'center',
    borderRadius: '5px',
    height: '48px',
    width: '100%',
    position: 'relative'
  },

  subContainer: {
    display: 'inline-flex',
    alignItems: 'center',
    height: '100%',
    overflow: 'hidden',
    whiteSpace: 'nowrap',
    textOverflow: 'ellipsis',
    maxWidth: '80%',
    [theme.breakpoints.up('xl')]: {
      maxWidth: '90%'
    },
    [theme.breakpoints.between('lg', 'xl')]: {
      maxWidth: '85%'
    }
  },

  image: {
    display: 'unset !important',
    width: 'auto',
    marginTop: '3px',
    marginBottom: '3px',
    maxHeight: '42px',
    borderRadius: '2px'
  },
  title: {
    marginLeft: '10px',
    fontSize: '20px',
    fontWeight: 600
  },
  short: {
    marginLeft: '10px',
    fontSize: '20px',
    textOverflow: 'ellipsis',
    overflow: 'hidden',
    whiteSpace: 'nowrap'
  },
  long: {
    fontSize: '16px'
  },
  closeButton: {
    fontSize: '18px',
    color: 'black',
    top: '0px',
    right: '5px',
    position: 'absolute',
    '&:hover': {
      cursor: 'pointer',
      fontWeight: 'bold'
    }
  }
}));
