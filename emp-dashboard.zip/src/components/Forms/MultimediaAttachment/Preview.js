import React, { useEffect, useState } from 'react';
import { Box } from '@material-ui/core';
import PDFReader from '@app/components/PDFReader';
import { getAssetUrlFromS3 } from '@app/utils/aws_s3_bucket';

const MultimediaAttachmentPreview = ({ resources }) => {
  const { mimeType: type, baseUrl, fileDir, fileName } = resources;
  const [assetUrl, setAssetUrl] = useState(null);

  useEffect(() => {
    const url = `${baseUrl}${fileDir}${fileName}`;
    getAssetUrlFromS3(url).then((res) => {
      setAssetUrl(res);
    });
  }, [baseUrl, fileDir, fileName]);

  const makeDownload = () => {
    const link = document.createElement('a');
    link.href = assetUrl;
    document.body.appendChild(link);
    link.setAttribute('download', `FileName`);
    link.click();
    link.parentNode.removeChild(link);
  };

  return (
    <React.Fragment>
      {type.includes('video') && (
        <Box
          mt="2"
          borderRadius="2px"
          component="video"
          controls
          autoPlay
          width="100%"
          src={assetUrl}
        />
      )}

      {type.includes('image') && (
        <Box
          mt="2"
          borderRadius="2px"
          component="img"
          controls
          autoPlay
          width="100%"
          src={assetUrl}
        />
      )}
    </React.Fragment>
  );
};

export default MultimediaAttachmentPreview;
