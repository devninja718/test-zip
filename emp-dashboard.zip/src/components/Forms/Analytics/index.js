/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, useRef } from 'react';
import {
  Grid,
  InputBase,
  FormControl,
  FormControlLabel,
  RadioGroup,
  Radio,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Paper,
  TablePagination
} from '@material-ui/core';
import Pagination from '@material-ui/lab/Pagination';
import * as globalStyles from '@app/constants/globalStyles';
import graphql from '@app/graphql';
import { useQuery, useLazyQuery } from '@apollo/client';
import { usePageCountContext } from '@app/providers/PageCountContext';
import useStyles from './style';
import moment from 'moment';
import { en } from '@app/language';
import { Page } from 'react-pdf';

const AnalyticForm = ({
  stationId,
  districtId,
  classId,
  isRoot,
  schemaType,
  resources,
  districtLoadedData,
  stationLoadedData,
  allDistrictResources,
  allSchoolResources,
  schoolLoadedData
}) => {
  const classes = useStyles();
  const mainTable = React.createRef();
  const [value, setValue] = useState(
    isRoot
      ? 'station'
      : schemaType === 'district'
      ? 'school'
      : schemaType === 'school'
      ? 'class'
      : schemaType === undefined
      ? 'station'
      : schemaType === 'class'
      ? 'educator'
      : 'district'
  );

  const [studentCount, setStudentCount] = useState();
  const [educatorCount, setEducatorCount] = useState();
  const [materialCount, setMaterialCount] = useState(0);
  const [items, setItems] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [page, setPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(25);
  const { pageCount, setPageCount } = usePageCountContext();
  const [totalPage, setTotalPage] = useState(1);
  const [totalStudents, setTotalStudents] = useState();
  const [totalEducators, setTotalEducators] = useState();
  const [stationList, setStationList] = useState([]);

  const stationValue = isRoot
    ? null
    : stationId != null
    ? stationId
    : resources?.schemaType === 'station'
    ? resources?._id
    : null;
  const districtValue = isRoot ? null : districtId;
  const classValue = isRoot ? null : classId;

  const [
    getTotalCount,
    { loading: totalCountLoading, error: totalCountError, data: totalCountData }
  ] = useLazyQuery(graphql.queries.totalCount, {
    fetchPolicy: 'no-cache'
  });

  const [
    getStudents,
    { loading: studentsLoading, error: studentsError, data: studentsData }
  ] = useLazyQuery(graphql.queries.userGrouping);

  const [
    getEducators,
    { loading: educatorsLoading, error: educatorsError, data: educatorsData }
  ] = useLazyQuery(graphql.queries.userGrouping);

  const [
    getMaterialCount,
    {
      loading: materialCountLoading,
      error: materialCountError,
      data: materialCountData
    }
  ] = useLazyQuery(graphql.queries.totalCount, {
    fetchPolicy: 'no-cache'
  });

  useEffect(() => {
    setPage(1);
    setValue(
      isRoot
        ? 'station'
        : schemaType === 'district'
        ? 'school'
        : schemaType === 'school'
        ? 'class'
        : schemaType === undefined
        ? 'station'
        : schemaType === 'class'
        ? 'educator'
        : 'district'
    );
  }, [schemaType]);

  useEffect(() => {
    setPage(1);
    fetchTotalCount(value);
  }, [value]);

  useEffect(() => {
    setPage(1);

    fetchTotalCount(value);
  }, [classId]);

  const handleRadioChange = (event) => {
    setValue(event.target.value);
    // fetchTotalCount(event.target.value);
    setPage(1);
  };

  const variables = {
    schemaType: value,
    stationId: stationValue,
    districtId: districtValue,
    schoolId: resources?.schemaType === 'school' ? resources?._id : null,
    offset: pageCount * (page - 1),
    limit: pageCount
  };
  const { loading, error, data, fetchMore } = useQuery(
    graphql.queries.analyticsGrouping,
    {
      variables: variables,
      fetchPolicy: 'no-cache'
    }
  );

  const {
    loading: loadingStationList,
    error: errorStationList,
    data: dataStationList
  } = useQuery(graphql.queries.analyticsGrouping, {
    variables: { schemaType: 'station' },
    fetchPolicy: 'no-cache'
  });

  const convertTime = (value) => {
    const convert_date = moment(new Date(value)).format('MM/DD/YY hh:mm:ss');
    return convert_date;
  };

  const fetchTotalCount = async (fetchVal) => {
    if (schemaType === 'class' || schemaType === 'googleClass') {
      const studentVariables = {
        schemaType: 'student',
        parentId: districtId
      };

      const educatorVariables = {
        schemaType: 'educator',
        parentId: districtId
      };

      if (
        totalStudents?.length > 0 &&
        totalStudents[0].parentId === districtId
      ) {
        const students = totalStudents.filter((item) =>
          resources?.assigneeIdList?.includes(item._id)
        );
        setStudentCount(students.length);
        if (value === 'student') {
          setTotalCount(students.length);
          setItems(students);
        }
      } else {
        await getStudents({
          variables: studentVariables,
          fetchPolicy: 'cache-and-network',
          nextFetchPolicy: 'cache-first'
        });
      }

      if (
        totalEducators?.length > 0 &&
        totalEducators[0].parentId === districtId
      ) {
        const educators = totalEducators.filter((item) =>
          resources?.authorIdList?.includes(item._id)
        );
        setEducatorCount(educators.length);
        if (value === 'educator') {
          setTotalCount(educators.length);
          setItems(educators);
        }
      } else {
        await getEducators({
          variables: educatorVariables,
          fetchPolicy: 'cache-and-network',
          nextFetchPolicy: 'cache-first'
        });
      }

      const lessonVariables1 = {
        schemaType: 'material', //schemaType === 'class' ? 'material' : 'googleMaterial',
        topology: {
          class: classId == null ? resources?._id : classId
        }
      };

      await getMaterialCount({ variables: lessonVariables1 });

      return;
    }

    const lessonVariables = {
      schemaType: 'material', //schemaType === 'class' ? 'material' : 'googleMaterial',
      topology:
        schemaType === 'class'
          ? {
              class: classId == null ? resources?._id : classId
            }
          : schemaType === 'school'
          ? {
              school: resources?._id
            }
          : schemaType === 'district'
          ? {
              district: resources?._id
            }
          : schemaType === 'station'
          ? {
              station: resources?._id
            }
          : null
    };

    await getMaterialCount({
      variables: lessonVariables
    });

    const schemaTypeVal = fetchVal == null ? value : fetchVal;

    const variables = {
      schemaType: schemaTypeVal,
      topology: {
        station: stationValue,
        district: districtValue,
        schoolId: resources?.schemaType === 'school' ? resources?._id : null
      }
    };
    await getTotalCount({
      variables: variables
    });
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
    console.log(newPage);
    fetchMore({
      variables: {
        schemaType: value,
        stationId: stationValue,
        districtId: districtValue,
        schoolId: resources?.schemaType === 'school' ? resources?._id : null,
        offset: pageCount * (newPage - 1),
        limit: pageCount
      }
    });
  };

  useEffect(() => {
    let typeVale = isRoot
      ? 'station'
      : schemaType === 'district'
      ? 'school'
      : schemaType === 'school'
      ? 'class'
      : schemaType === undefined
      ? 'station'
      : schemaType === 'class'
      ? 'educator'
      : 'district';
    setValue(typeVale);
    setPage(1);
  }, [resources]);

  useEffect(() => {
    if (mainTable && mainTable?.current) {
      mainTable.current.parentNode.scrollTop = 0;
    }
  }, [page]);

  useEffect(() => {
    if (value !== 'material') setTotalPage(Math.ceil(totalCount / pageCount));
    else setTotalPage(1);
    console.log('value=====', value);
  }, [pageCount, totalCount, value]);

  useEffect(() => {
    if (!totalCountError && !totalCountLoading && totalCountData) {
      const { totalCount } = totalCountData;
      console.log(totalCountData);
      setTotalCount(totalCount);
    }
  }, [totalCountData, totalCountError, totalCountLoading]);

  useEffect(() => {
    if (!studentsError && !studentsLoading && studentsData) {
      setTotalStudents(studentsData.grouping);
      const students = studentsData.grouping.filter((item) =>
        resources?.assigneeIdList?.includes(item._id)
      );
      console.log('stuent count', students.length);
      setStudentCount(students.length);
      setTotalCount(students.length);
    }
  }, [studentsData, studentsError, studentsLoading]);

  useEffect(() => {
    if (!educatorsError && !educatorsLoading && educatorsData) {
      setTotalEducators(educatorsData.grouping);
      const educators = educatorsData.grouping.filter((item) =>
        resources?.authorIdList?.includes(item._id)
      );
      setEducatorCount(educators.length);
      setTotalCount(educators.length);
    }
  }, [educatorsData, educatorsError, educatorsLoading]);

  useEffect(() => {
    if (!materialCountError && !materialCountLoading && materialCountData) {
      const { totalCount } = materialCountData;
      console.log('material count', totalCount);
      setMaterialCount(totalCount);
    }
  }, [materialCountData, materialCountError, materialCountLoading]);

  useEffect(() => {
    if (!loadingStationList && !errorStationList) {
      const { grouping } = dataStationList;

      setStationList(grouping);
    }
  }, [loadingStationList, errorStationList, dataStationList]);

  useEffect(() => {
    if (!loading && !error) {
      let { grouping } = data;
      if (schemaType === 'class' && value === 'student') {
        const studentsItems = grouping.filter((item) =>
          resources?.assigneeIdList?.includes(item._id)
        );

        setItems(studentsItems);
      } else if (schemaType === 'class' && value === 'educator') {
        const educatorItems = grouping.filter((item) =>
          resources?.authorIdList?.includes(item._id)
        );
        setItems(educatorItems);
      } else {
        setItems(grouping);
      }
    }
  }, [loading, error, data]);

  const getRows = () => {
    if (value !== 'material') {
      return items || [];
    } else {
      return [];
    }
  };

  return (
    <React.Fragment>
      <Grid
        spacing={2}
        container
        direction="row"
        justify="center"
        alignItems="center"
        style={{ padding: 16 }}
      >
        {schemaType !== 'googleClass' && (
          <FormControl component="fieldset">
            <RadioGroup
              row
              aria-label="position"
              name="position"
              value={value}
              onChange={handleRadioChange}
            >
              {isRoot && (
                <FormControlLabel
                  value="station"
                  control={<Radio color="primary" />}
                  label="Stations"
                  labelPlacement="top"
                />
              )}
              {schemaType !== 'district' &&
                schemaType !== 'school' &&
                schemaType !== 'class' && (
                  <FormControlLabel
                    value="district"
                    control={<Radio color="primary" />}
                    label="Districts"
                    labelPlacement="top"
                  />
                )}
              {schemaType !== 'school' && schemaType !== 'class' && (
                <FormControlLabel
                  value="school"
                  control={<Radio color="primary" />}
                  label="Schools"
                  labelPlacement="top"
                />
              )}

              {schemaType !== 'class' && (
                <FormControlLabel
                  value="class"
                  control={<Radio color="primary" />}
                  label="Classes"
                  labelPlacement="top"
                />
              )}
              {schemaType !== 'school' && (
                <FormControlLabel
                  value="educator"
                  control={<Radio color="primary" />}
                  label="Educators"
                  labelPlacement="top"
                />
              )}
              {schemaType !== 'school' && (
                <FormControlLabel
                  value="student"
                  control={<Radio color="primary" />}
                  label="Students"
                  labelPlacement="top"
                />
              )}

              {schemaType === undefined && (
                <FormControlLabel
                  value="material"
                  control={<Radio color="primary" />}
                  label="Keywords"
                  labelPlacement="top"
                />
              )}

              {!isRoot && (
                <InputBase
                  className={classes.margin}
                  style={{ paddingLeft: '40px', marginTop: '0px' }}
                  value={`Lessons/Collections: ${materialCount}`}
                  inputProps={{
                    'aria-label': 'stations',
                    style: { textAlign: 'center' }
                  }}
                />
              )}
            </RadioGroup>
          </FormControl>
        )}
      </Grid>
      <Grid
        spacing={2}
        container
        direction="row"
        justify="flex-start"
        alignItems="flex-start"
        style={{
          paddingLeft: 16,
          paddingRight: 16,
          marginTop: 16,
          display: 'block'
        }}
      >
        {schemaType !== 'googleClass' && (
          <>
            <TableContainer component={Paper} className={classes.table}>
              <Table
                stickyHeader
                aria-label="sticky table"
                className="AnalyticsTable"
                ref={mainTable}
              >
                <TableHead>
                  <TableRow>
                    <TableCell align="center">No</TableCell>
                    <TableCell align="center">Name</TableCell>
                    {isRoot && <TableCell align="center">State</TableCell>}
                    {isRoot ||
                      (schemaType === 'station' && (
                        <>
                          {[
                            'district',
                            'school',
                            'class',
                            'educator',
                            'student'
                          ].includes(value) &&
                            isRoot && (
                              <TableCell align="center">Station</TableCell>
                            )}
                          {['school', 'class', 'educator', 'student'].includes(
                            value
                          ) && <TableCell align="center">District</TableCell>}
                        </>
                      ))}
                    {value === 'class' &&
                      schemaType !== 'class' &&
                      schemaType !== 'school' && (
                        <TableCell align="center">School</TableCell>
                      )}
                    {value === 'educator' && (
                      <TableCell align="center">Last Seen At</TableCell>
                    )}
                    <TableCell align="center">
                      {value !== 'material' ? 'Status' : 'Ref Count'}
                    </TableCell>
                    {value === 'material' && (
                      <TableCell align="center">Search Count</TableCell>
                    )}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {value !== 'material'
                    ? getRows().map((row, index) => (
                        <TableRow key={`${index}-${row.name}`} hover>
                          <TableCell align="center">
                            {(page - 1) * pageCount + index + 1}
                          </TableCell>
                          <TableCell align="center">{row.name}</TableCell>

                          {isRoot && (
                            <TableCell align="center">
                              {row.topology?.state}
                            </TableCell>
                          )}
                          {isRoot ||
                            (schemaType === 'station' && (
                              <>
                                {[
                                  'district',
                                  'school',
                                  'class',
                                  'educator',
                                  'student'
                                ].includes(value) &&
                                  isRoot && (
                                    <TableCell align="center">
                                      {row.topology?.station == null
                                        ? ''
                                        : stationLoadedData?.find(
                                            (item) =>
                                              item._id === row.topology?.station
                                          )?.name}
                                    </TableCell>
                                  )}
                                {[
                                  'school',
                                  'class',
                                  'educator',
                                  'student'
                                ].includes(value) && (
                                  <TableCell align="center">
                                    {row.topology?.district == null
                                      ? ''
                                      : allDistrictResources?.find(
                                          (item) =>
                                            item._id === row.topology?.district
                                        )?.name}
                                  </TableCell>
                                )}
                              </>
                            ))}
                          {value === 'class' &&
                            schemaType !== 'class' &&
                            schemaType !== 'school' && (
                              <TableCell align="center">
                                {row.topology?.school == null
                                  ? ''
                                  : allSchoolResources?.find(
                                      (item) =>
                                        item._id === row.topology?.school
                                    )?.name}
                              </TableCell>
                            )}
                          {/* {schemaType === undefined && value === 'district' && (
                            <TableCell align="center">
                              {getStationNameById(row.topology?.station)}
                            </TableCell>
                          )} */}
                          {value === 'educator' && (
                            <TableCell align="center">
                              {row?.loginInfo?.lastSeenAt
                                ? convertTime(row?.loginInfo?.lastSeenAt)
                                : ''}
                            </TableCell>
                          )}
                          <TableCell align="center">
                            {(row.status || '').capitalizeFirstLetter()}
                          </TableCell>
                        </TableRow>
                      ))
                    : getRows().map((row, index) => (
                        <TableRow key={`${index}-${row.name}`} hover>
                          <TableCell align="center">
                            {(page - 1) * pageCount + index + 1}
                          </TableCell>
                          <TableCell align="center">{row.name}</TableCell>
                          <TableCell align="center">{row.refCount}</TableCell>
                          <TableCell align="center">
                            {row.searchCount}
                          </TableCell>
                        </TableRow>
                      ))}
                </TableBody>
              </Table>
            </TableContainer>
            <Pagination
              count={totalPage}
              size="small"
              page={page}
              siblingCount={0}
              showFirstButton
              showLastButton
              onChange={handleChangePage}
              className={classes.pagination}
            />
          </>
        )}
      </Grid>
    </React.Fragment>
  );
};

export default AnalyticForm;
