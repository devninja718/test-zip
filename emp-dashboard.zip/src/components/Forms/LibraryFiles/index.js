/* eslint-disable max-len */
import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import {
  Box,
  Paper,
  Table,
  TableHead,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
  TextField,
  IconButton,
  Grid
} from '@material-ui/core';
import Pagination from '@material-ui/lab/Pagination';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  Save as SaveIcon,
  Edit as EditIcon,
  GetApp as GetAppIcon,
  Publish as PublishIcon
} from '@material-ui/icons';
import { faInfo } from '@fortawesome/free-solid-svg-icons';
import { CustomDialog, CustomCheckBox } from '@app/components/Custom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { useQuery, useMutation, useLazyQuery } from '@apollo/client';
import { getNotificationOpt } from '@app/constants/Notifications';
import { LoadingCard } from '@app/components/Cards';
import { useFetchDataByVariables } from '@app/utils/hooks/form';
import graphql from '@app/graphql';
import CreateUserDialog from './Dialog';
import useStyles from './style';
import { getDisplayName } from '@app/utils/functions';
import { getFormattedDate } from '@app/utils/date-manager';
import JSONEditor from '@app/components/JSONEditor';
import { getAssetUrlFromS3 } from '@app/utils/aws_s3_bucket';

import moment from 'moment';
import { useNotifyContext } from '@app/providers/NotifyContext';
import { usePageCountContext } from '@app/providers/PageCountContext';
import { en } from '@app/language';

const LibraryFilesForm = ({
  docId,
  type,
  filterValue,
  disable,
  hasTypeField,
  userTypeData,
  isRefresh,
  isCreated,
  setIsCreated
}) => {
  const classes = useStyles();
  const mainTable = useRef();
  const { notify } = useNotifyContext();
  const [loadedData, setLoadedData] = useState([]);
  const [loadedDataCopy, setLoadedDataCopy] = useState([]);
  const [loadingPanel, setLoadingPanel] = useState(false);
  const [percentage, setPercentage] = useState(0);
  const [currentRowId, setCurrentRowId] = useState();
  const [checkbox, setCheckbox] = useState(false);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [openCreate, setOpenCreate] = useState(false);
  const [totalRow, setTotalRow] = useState(0);
  const [page, setPage] = useState(1);
  const [offset, setOffset] = useState(0);
  const { pageCount, setPageCount } = usePageCountContext();
  const [totalPage, setTotalPage] = useState(0);
  const [rowData, setRowData] = useState({
    name: null
  });
  const [openInfo, setOpenInfo] = useState(false);
  const [selectedInfo, setSelectedInfo] = useState(null);

  const [deleteDocument] = useMutation(graphql.mutations.deleteDocument);

  const [getData, { loading, data, error }] = useLazyQuery(
    graphql.queries.BulkFilesGrouping,
    {
      fetchPolicy: 'no-cache'
    }
  );

  const {
    loading: totalLoading,
    error: totalError,
    data: totalData,
    refetch: totalRefetch
  } = useQuery(graphql.queries.BulkFilesGrouping, {
    variables: {
      schemaType: 'bulkFile',
      type: type
    },
    fetchPolicy: 'no-cache'
  });

  const fetchData = () => {
    getData({
      variables: {
        schemaType: 'bulkFile',
        type: type,
        offset: pageCount * (page - 1),
        limit: pageCount
      }
    });
  };

  useEffect(() => {
    setTotalPage(Math.ceil(totalRow / pageCount));
    if (page > Math.ceil(totalRow / pageCount)) {
      if (Math.ceil(totalRow / pageCount) === 0) {
        setPage(1);
      } else {
        setPage(Math.ceil(totalRow / pageCount));
      }
    }
    fetchData();
  }, [docId, isRefresh, offset, pageCount, totalRow]);

  useEffect(() => {
    if (mainTable && mainTable?.current) {
      mainTable.current.parentNode.scrollTop = 0;
    }
  }, [page]);

  useEffect(() => {
    if (!totalError && !totalLoading) {
      setTotalRow(totalData.grouping.length);
    }

    if (isCreated) {
      setTimeout(() => {
        totalRefetch();
        fetchData();
        setIsCreated(false);
      }, 3000); // after 3 seconds, refresh list
    }
  }, [totalLoading, totalError, totalData, isCreated]);

  useEffect(() => {
    if (!loading && !error && data) {
      console.log('okay');
      const { grouping } = data;
      const loadData = grouping.map((item) => ({ ...item, disable: true }));
      setLoadedData(loadData);
      setLoadedDataCopy(loadData);
    }
  }, [loading, data, error, filterValue]);

  const deleteData = async (changeType, decision) => {
    if (changeType && decision && !checkbox) {
      const notiOps = getNotificationOpt('material', 'warning', 'delete');
      notify(notiOps.message, notiOps.options);
      return;
    }

    if (changeType && decision && checkbox) {
      const response = await deleteDocument({
        variables: {
          schemaType: 'bulkFile',
          id: currentRowId
        }
      });
      const tmp = loadedData.filter((el) => el._id !== currentRowId);
      setLoadedData(tmp);
      setLoadedDataCopy(tmp);

      const notiOps = getNotificationOpt('package', 'success', 'delete');
      notify(notiOps.message, notiOps.options);
      setCheckbox(false);
    }
    setOpenDeleteDialog(false);
    setCurrentRowId();
  };

  const handleTableChange = async (method, value) => {
    try {
      if (method === 'edit') {
        let tmp = loadedData.slice();
        const idx = tmp.findIndex((el) => el._id === value);
        tmp[idx] = {
          ...tmp[idx],
          disable: false
        };

        setLoadedData(tmp);
        setLoadedDataCopy(tmp);
      }

      if (method === 'download') {
        let elDom = document.createElement('a');
        getAssetUrlFromS3(value, 1).then((res) => {
          elDom.setAttribute('href', res);
          elDom.setAttribute('download', '');
          elDom.setAttribute('rel', 'noopener noreferrer');
          elDom.click();
        });
      }

      if (method === 'delete') {
        setCurrentRowId(value);
        setOpenDeleteDialog(true);
        totalRefetch();
      }

      if (method === 'info') {
        setSelectedInfo(value);
        setOpenInfo(true);
      }
    } catch (error) {
      const notiOps = getNotificationOpt('backend', 'error', 'wrong');
      notify(notiOps.message, notiOps.options);
    }
  };

  const handleInputChange = (method, value, id) => {
    const findedData = loadedData.find((el) => el._id === id);
    if (rowData?._id !== id) {
      setRowData({
        [method]: value,
        id: id
      });
    } else {
      setRowData({
        ...rowData,
        [method]: value,
        id: id
      });
    }
  };

  const handleChangePage = (event, newPage) => {
    setOffset(newPage * pageCount);
    setPage(newPage);
  };

  const handleInfoDialogChange = async (type, value) => {
    setOpenInfo(false);
  };

  return (
    <LoadingCard
      loading={loadingPanel}
      percentage={percentage}
      isProgress={true}
    >
      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        marginBottom={2}
      >
        {/* <Typography variant="h6">Packages</Typography> */}
      </Box>
      <div style={{ position: 'relative' }}>
        <TableContainer
          component={Paper}
          className={classes.table}
          style={{ position: 'absolute' }}
        >
          <Table
            className={classes.table}
            aria-label="custom pagination table"
            ref={mainTable}
          >
            <TableHead>
              <TableRow>
                <TableCell align="center"># ID</TableCell>
                <TableCell align="left">{en['Status']}</TableCell>
                <TableCell align="left">{en['Identifier']}</TableCell>
                <TableCell align="left">{en['Name']}</TableCell>
                <TableCell align="left">{en['Type']}</TableCell>
                <TableCell align="left">{en['Size']}(KB)</TableCell>
                <TableCell align="left">{en['Updated At']}</TableCell>
                {!disable ? (
                  <TableCell align="center"># {en['Action']}</TableCell>
                ) : (
                  []
                )}
              </TableRow>
            </TableHead>
            <TableBody>
              {loadedData.length > 0 &&
                loadedData.map((row, index) => (
                  <TableRow key={row._id}>
                    <TableCell component="th" scope="row" align="center">
                      {page === 1
                        ? index + 1
                        : index + 1 + (page - 1) * pageCount}
                    </TableCell>
                    <TableCell component="th" align="left">
                      {(row.status || '').capitalizeFirstLetter()}
                    </TableCell>
                    <TableCell component="th" align="left">
                      {row.disable ? (
                        row.name
                      ) : (
                        <TextField
                          defaultValue={row.name}
                          onChange={(e) =>
                            handleInputChange('name', e.target.value, row._id)
                          }
                        />
                      )}
                    </TableCell>
                    <TableCell component="th" align="left">
                      {getDisplayName(row.desc?.title)}
                    </TableCell>
                    <TableCell component="th" align="left">
                      {row.desc?.short}
                    </TableCell>
                    <TableCell component="th" align="left">
                      {row.multimediaAssets?.length > 0 &&
                        row.multimediaAssets[0].data?.size}
                    </TableCell>
                    <TableCell component="th" align="left">
                      {getFormattedDate(row.updatedAt)}
                    </TableCell>
                    {!disable ? (
                      <TableCell component="th" align="center">
                        <Box textAlign="center">
                          {row.status === 'uploaded' ? (
                            <IconButton
                              size="small"
                              onClick={() =>
                                handleTableChange(
                                  'download',
                                  row.avatar?.baseUrl
                                )
                              }
                            >
                              <GetAppIcon />
                            </IconButton>
                          ) : (
                            <IconButton
                              size="small"
                              disabled="true"
                              onClick={() => handleTableChange('', null)}
                            >
                              <GetAppIcon />
                            </IconButton>
                          )}
                          <IconButton
                            size="small"
                            onClick={() => handleTableChange('info', row)}
                          >
                            <FontAwesomeIcon
                              icon={faInfo}
                              size="sm"
                              style={{ cursor: 'pointer' }}
                            />
                            {/* {row.disable ? (
                            <EditIcon
                              onClick={() => handleTableChange('edit', row._id)}
                            />
                          ) : (
                            <SaveIcon
                              onClick={() => handleTableChange('save', row._id)}
                            />
                          )} */}
                          </IconButton>
                          <IconButton
                            size="small"
                            onClick={() => handleTableChange('delete', row._id)}
                          >
                            <DeleteIcon />
                          </IconButton>
                          <IconButton
                            size="small"
                            onClick={() =>
                              handleTableChange('publish', row._id)
                            }
                          >
                            <PublishIcon />
                          </IconButton>
                        </Box>
                      </TableCell>
                    ) : (
                      []
                    )}
                  </TableRow>
                ))}
            </TableBody>
          </Table>
          <Pagination
            count={totalPage}
            size="small"
            page={page}
            siblingCount={0}
            showFirstButton
            showLastButton
            onChange={handleChangePage}
            className={classes.pagination}
          />
        </TableContainer>
      </div>
      <CustomDialog
        open={openInfo}
        title={en['Information']}
        maxWidth="sm"
        fullWidth={true}
        onChange={handleInfoDialogChange}
      >
        <Grid item xs={12} sm={12} md={12} lg={12}>
          <JSONEditor disable={false} resources={selectedInfo} />
        </Grid>
      </CustomDialog>
      <CustomDialog
        open={openDeleteDialog}
        title={en[`Delete Package?`]}
        mainBtnName={en['Delete']}
        onChange={deleteData}
      >
        {en['Are you sure want to delete this package?']}
        <br />
        <CustomCheckBox
          color="primary"
          value={checkbox}
          label={en['I agree with this action.']}
          onChange={(value) => setCheckbox(!value)}
        />
      </CustomDialog>
    </LoadingCard>
  );
};

export default LibraryFilesForm;
