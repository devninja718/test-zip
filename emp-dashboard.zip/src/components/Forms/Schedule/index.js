import React, { useState, useEffect, useRef } from 'react';
import clsx from 'clsx';
import { Grid, TextField } from '@material-ui/core';
import { CustomInput, CustomSelectBox } from '@app/components/Custom';
import { Edit, Save } from '@material-ui/icons';
import { DefaultCard, DescriptionCard } from '@app/components/Cards';
import {
  TitleText,
  ShortText,
  LongText,
  EditHelperText,
  SaveHelperText
} from '@app/components/Text';
import * as globalStyles from '@app/constants/globalStyles';
import { useNotifyContext } from '@app/providers/NotifyContext';
import useStyles from './style';

const MessageStatus = [
  { label: 'Set the start to now', value: 'active' },
  { label: 'Set the start to the future', value: 'inactive' },
  { label: 'Set the end to past', value: 'expired' }
];

const convertUTCDateToLocalDate = (date) => {
  var newDate = new Date(date);
  newDate.setMinutes(date.getMinutes() - date.getTimezoneOffset());
  return newDate.toISOString().slice(0, 16);
};

const ScheduleForm = ({
  disable,
  resources,
  onChange,
  helperText,
  disableGray,
  type,
  customStyle,
  messageStatus
}) => {
  const classes = globalStyles.DescCardStyle();
  const classes1 = useStyles();
  const { notify } = useNotifyContext();
  const [loadedData, setLoadedData] = useState({
    startAt: resources.startAt,
    endAt: resources.endAt
  });
  const [status, setStatus] = useState('');

  useEffect(() => {
    setLoadedData({
      ...loadedData,
      ...resources
    });
  }, [resources]);

  const handleInputChange = (type, value) => {
    let tmp = loadedData;
    if (type === 'startAt') {
      let startAt = new Date(value).getTime();
      let endAt = new Date(loadedData.endAt).getTime();
      if (endAt < startAt + 5 * 60000) {
        notify('EndAt must not be before StartAt', {
          autoHideDuration: 5000,
          variant: 'error'
        });
        return;
      }
    }
    if (type === 'endAt') {
      let startAt = new Date(loadedData.startAt).getTime();
      let endAt = new Date(value).getTime();
      if (endAt < startAt + 5 * 60000) {
        notify('EndAt must not be before StartAt', {
          autoHideDuration: 5000,
          variant: 'error'
        });
        return;
      }
    }
    if (type === 'status') {
      if (value === 'active') {
        var startAtTimeStamp = new Date();
        let endAtTimeStamp = new Date().getTime() + 24 * 3600 * 1000;
        var endAt = new Date(endAtTimeStamp);
        var startAt = convertUTCDateToLocalDate(startAtTimeStamp);
        endAt = convertUTCDateToLocalDate(endAt);
        tmp = { ...tmp, startAt: startAt, endAt: endAt };
      } else if (value === 'inactive') {
        let startAtTimeStamp = new Date(
          new Date().getTime() + 24 * 3600 * 1000
        );
        let endAtTimeStamp = new Date(new Date().getTime() + 48 * 3600 * 1000);
        let startAt = convertUTCDateToLocalDate(startAtTimeStamp);
        let endAt = convertUTCDateToLocalDate(endAtTimeStamp);
        tmp = { ...tmp, startAt: startAt, endAt: endAt };
      } else if (value === 'expired') {
        let startAtTimeStamp = new Date(
          new Date().getTime() - 24 * 3600 * 1000
        );
        let endAtTimeStamp = new Date(new Date().getTime() - 60 * 1000);
        let startAt = convertUTCDateToLocalDate(startAtTimeStamp);
        let endAt = convertUTCDateToLocalDate(endAtTimeStamp);
        tmp = { ...tmp, startAt: startAt, endAt: endAt };
      }
      setStatus(value);
    }

    setLoadedData({
      ...tmp,
      [type]: value
    });
    onChange({
      ...tmp,
      [type]: value
    });
  };

  return (
    <React.Fragment>
      <Grid
        spacing={4}
        container
        direction="row"
        justify="flex-start"
        alignItems="flex-start"
        // style={{ padding: 24, paddingBottom: 0 }}
      >
        <Grid
          item
          xs={12}
          sm={12}
          md={12}
          lg={6}
          xl={6}
          style={{ paddingRight: 6 }}
        >
          <TextField
            id="time"
            label="&nbsp;&nbsp;StartAt"
            type="datetime-local"
            value={loadedData.startAt}
            className={classes1.scheduleTextField}
            InputProps={{ disableUnderline: true }}
            InputLabelProps={{
              shrink: true
            }}
            inputProps={{
              step: 300 // 5 min
            }}
            onChange={(event) =>
              handleInputChange('startAt', event.target.value)
            }
          />
        </Grid>
        <Grid
          item
          xs={12}
          sm={12}
          md={12}
          lg={6}
          xl={6}
          style={{ paddingLeft: 6 }}
        >
          <TextField
            id="time"
            label="&nbsp;&nbsp;EndAt"
            type="datetime-local"
            value={loadedData.endAt}
            className={classes1.scheduleTextField}
            InputProps={{ disableUnderline: true }}
            InputLabelProps={{
              shrink: true
            }}
            inputProps={{
              step: 300 // 5 min
            }}
            onChange={(event) => handleInputChange('endAt', event.target.value)}
          />
        </Grid>
      </Grid>
      <Grid
        spacing={4}
        container
        direction="row"
        justify="flex-start"
        alignItems="flex-start"
      >
        <Grid
          item
          xs={12}
          sm={12}
          md={12}
          lg={6}
          xl={6}
          style={{ paddingRight: 6 }}
        >
          <CustomSelectBox
            variant="outlined"
            label="Reset the time to:"
            style={classes1.selectFilter}
            noPadding={true}
            value={status}
            resources={MessageStatus}
            onChange={(event) => handleInputChange('status', event.value)}
            size="small"
          />
        </Grid>
        <Grid
          item
          xs={12}
          sm={12}
          md={12}
          lg={6}
          xl={6}
          style={{ paddingLeft: 6 }}
        >
          <CustomInput
            multiline
            rows={1}
            label={'Status'}
            type="text"
            name="title"
            value={messageStatus ?? 'Null'}
            onChange={() => {}}
          />
        </Grid>
      </Grid>
    </React.Fragment>
  );
};

export default ScheduleForm;
