/* eslint-disable max-len */
import React, { useState, useEffect, useRef } from 'react';
import {
  Box,
  Table,
  TableHead,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
  IconButton,
  Grid
} from '@material-ui/core';
import Pagination from '@material-ui/lab/Pagination';
import { Delete as DeleteIcon, GetApp as GetAppIcon } from '@material-ui/icons';
import { faInfo, faUndo } from '@fortawesome/free-solid-svg-icons';
import AutorenewIcon from '@material-ui/icons/Autorenew';
import { CustomDialog, CustomCheckBox } from '@app/components/Custom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { useMutation, useLazyQuery } from '@apollo/client';
import { getNotificationOpt } from '@app/constants/Notifications';
import { LoadingCard } from '@app/components/Cards';
import { useFetchDataByVariables } from '@app/utils/hooks/form';
import graphql from '@app/graphql';
import useStyles from './style';
import { getDisplayName } from '@app/utils/functions';
import { getFormattedDate } from '@app/utils/date-manager';
import JSONEditor from '@app/components/JSONEditor';
import { getAssetUrlFromS3 } from '@app/utils/aws_s3_bucket';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import { useNotifyContext } from '@app/providers/NotifyContext';
import { usePageCountContext } from '@app/providers/PageCountContext';
import { en } from '@app/language';
import { useUserContext } from '@app/providers/UserContext';

const PackageListForm = ({
  docId,
  type,
  updateValue,
  filterValue,
  disable,
  hasTypeField,
  userTypeData,
  onChange,
  isRefresh,
  triggedPackage,
  triggerPackage,
  setTriggerPackage,
  packageDownload,
  setPackageDownload
}) => {
  const classes = useStyles();
  const mainTable = useRef();
  const { notify } = useNotifyContext();
  const [loadedData, setLoadedData] = useState([]);
  const [loadingPanel, setLoadingPanel] = useState(false);
  const [percentage, setPercentage] = useState(0);
  const [currentRowId, setCurrentRowId] = useState();
  const [checkbox, setCheckbox] = useState(false);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [nameRegExp, setNameRegExp] = useState(null);
  const [totalRow, setTotalRow] = useState(0);
  const [totalPackages, setTotalPackages] = useState([]);
  const [page, setPage] = useState(1);
  const [offset, setOffset] = useState(0);
  const { pageCount } = usePageCountContext();
  const [totalPage, setTotalPage] = useState(0);
  const [openInfo, setOpenInfo] = useState(false);
  const [isCreated, setCreated] = useState(false);
  const [sortKey, setSortKey] = useState();
  const [typeSortDirection, setTypeSortDirection] = useState('asc');
  const [updatedAtSortDirection, setUpdatedAtSortDirection] = useState('asc');

  const [selectedInfo, setSelectedInfo] = useState(null);
  const [currentUser] = useUserContext();

  const [updateGrouping] = useMutation(graphql.mutations.updateGrouping);
  const [deleteDocument] = useMutation(graphql.mutations.deleteDocument);
  const [packageStation] = useMutation(graphql.mutations.packageStation);

  const [getData, { loading, data, error }] = useLazyQuery(
    graphql.queries.PackageGrouping,
    {
      fetchPolicy: 'network-only'
    }
  );

  const [variables, setVariables] = useState({
    id: null,
    schemaType: 'package',
    parentId: docId,
    nameRegExp: nameRegExp,
    offset: null,
    limit: null
  });

  const fetchData = async () => {
    await getData({
      variables,
      fetchPolicy: 'cache-and-network',
      nextFetchPolicy: 'cache-first'
    });
  };

  const {
    loading: totalLoading,
    error: totalError,
    data: totalData,
    refetch: totalRefetch
  } = useFetchDataByVariables({
    schemaType: 'package',
    parentId: docId,
    nameRegExp: nameRegExp
  });

  useEffect(() => {
    totalRefetch();
    setSortKey();
    setTypeSortDirection('asc');
    setUpdatedAtSortDirection('asc');
  }, [docId]);

  useEffect(() => {
    const onLoad = async () => {
      try {
        // setLoadedData([]);
        // setTotalPackages([]);
        // setSortKey();
        // setTypeSortDirection('asc');
        // setUpdatedAtSortDirection('asc');
        setTotalPage(Math.ceil(totalRow / pageCount));
        sortPackages(sortKey);
        setTimeout(() => {
          totalRefetch();
        }, 1000);
      } catch (err) {
        console.log(err);
      }
    };
    onLoad();
  }, [isRefresh]);

  useEffect(() => {
    setTotalPage(Math.ceil(totalRow / pageCount));
    sortPackages(sortKey);
  }, [
    docId,
    offset,
    pageCount,
    totalRow,
    sortKey,
    typeSortDirection,
    updatedAtSortDirection
  ]);

  useEffect(() => {
    if (!totalError && !totalLoading) {
      setTotalRow(totalData.grouping.length);
      setTotalPackages(totalData.grouping);
    }
  }, [totalLoading, totalError, totalData]);

  useEffect(() => {
    if (!isCreated) {
      setCreated(true);
    } else {
      handleTableChange('add');
    }
  }, [triggedPackage]);

  const sortPackages = (key) => {
    if (totalPackages == null || totalPackages?.length === 0) {
      return;
    }
    let sortedPackages = totalPackages.slice();
    const sortDirection =
      key === 'type' ? typeSortDirection : updatedAtSortDirection;
    if (key === 'type') {
      sortedPackages = sortedPackages?.sort((item1, item2) => {
        let str1 = item1.desc?.short ? item1.desc?.short : '';
        let str2 = item2.desc?.short ? item2.desc?.short : '';
        if (sortDirection === 'asc') {
          if (str1 < str2) return -1;
          return str1 > str2 ? 1 : 0;
        } else {
          if (str1 > str2) return -1;
          return str1 < str2 ? 1 : 0;
        }
      });
    } else {
      sortedPackages = sortedPackages?.sort((item1, item2) => {
        let time1 = new Date(item1.updatedAt).getTime();
        let time2 = new Date(item2.updatedAt).getTime();
        return sortDirection === 'asc' ? time1 - time2 : time2 - time1;
      });
    }
    setLoadedData(
      sortedPackages.slice(pageCount * (page - 1), pageCount * page)
    );
  };

  useEffect(() => {
    if (triggerPackage) {
      handleTableChange('add');
      setTriggerPackage(false);
    }
  }, [triggerPackage]);

  useEffect(() => {
    setTotalPage(Math.ceil(totalRow / pageCount));
    sortPackages(sortKey);
  }, [totalPackages]);

  useEffect(() => {
    if (mainTable && mainTable?.current) {
      mainTable.current.parentNode.scrollTop = 0;
    }
  }, [page]);

  useEffect(() => {
    let wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    const onDownload = async () => {
      try {
        for (let el of loadedData) {
          if (checkDownloadButton(el)) {
            await wait(500);
            let value =
              el.multimediaAssets[0]?.baseUrl +
              el.multimediaAssets[0]?.fileDir +
              el.multimediaAssets[0]?.fileName;
            let elDom = document.createElement('a');
            await getAssetUrlFromS3(value, 2).then((res) => {
              elDom.setAttribute('href', res);
              elDom.setAttribute('download', '');
              elDom.setAttribute('rel', 'noopener noreferrer');
              elDom.click();
            });
          }
        }
        setPackageDownload(false);
      } catch (err) {
        console.log(err);
      }
    };
    if (packageDownload) {
      onDownload();
    }
  }, [packageDownload]);

  const deleteData = async (changeType, decision) => {
    if (changeType && decision && !checkbox) {
      const notiOps = getNotificationOpt('material', 'warning', 'delete');
      notify(notiOps.message, notiOps.options);
      return;
    }

    if (changeType && decision && checkbox) {
      const response = await deleteDocument({
        variables: {
          schemaType: 'package',
          id: currentRowId
        }
      });
      const tmp = loadedData.filter((el) => el._id !== currentRowId);
      const copyTotalData = totalPackages.filter(
        (el) => el._id !== currentRowId
      );
      setLoadedData(tmp);
      setTotalPackages(copyTotalData);

      const notiOps = getNotificationOpt('package', 'success', 'delete');
      notify(notiOps.message, notiOps.options);
      setCheckbox(false);
    }
    setOpenDeleteDialog(false);
    setCurrentRowId();
  };

  const handleTableChange = async (method, value) => {
    try {
      if (method === 'download') {
        let elDom = document.createElement('a');
        getAssetUrlFromS3(value, 2).then((res) => {
          elDom.setAttribute('href', res);
          elDom.setAttribute('download', '');
          elDom.setAttribute('rel', 'noopener noreferrer');
          elDom.click();
        });
      }

      if (method === 'delete') {
        setCurrentRowId(value);
        setOpenDeleteDialog(true);
        totalRefetch();
      }

      if (method === 'add') {
        packageStation({
          variables: {
            parentId: docId
          }
        });
        const notiOps = getNotificationOpt('package', 'success', 'packaged');
        notify(notiOps.message, notiOps.options);
      }

      if (method === 'info') {
        setSelectedInfo(value);
        setOpenInfo(true);
      }

      if (method === 'refresh') {
        await updateGrouping({
          variables: {
            id: value?._id,
            schemaType: 'package',
            version: value?.version,
            trackingAuthorName: currentUser?.name,
            status: 'repackage'
          }
        });
        totalRefetch();
      }
    } catch (error) {
      const notiOps = getNotificationOpt('backend', 'error', 'wrong');
      notify(notiOps.message, notiOps.options);
    }
  };

  const handleChangePage = (event, newPage) => {
    setOffset(newPage * pageCount);
    setPage(newPage);
  };

  const handleInfoDialogChange = async (type, value) => {
    setOpenInfo(false);
  };

  const handleTypeSort = () => {
    setTypeSortDirection(typeSortDirection !== 'desc' ? 'desc' : 'asc');
    setSortKey('type');
  };

  const handleUpdatedAtSort = () => {
    setUpdatedAtSortDirection(
      updatedAtSortDirection !== 'desc' ? 'desc' : 'asc'
    );
    setSortKey('updatedAt');
  };

  const checkDownloadButton = (row) => {
    const assets = row?.multimediaAssets ? row.multimediaAssets[0] : null;
    if (!assets) return false;

    if (!assets.baseUrl || !assets.fileName) return false;

    return (
      assets.data?.size &&
      (row.status === 'ready' || row.status === 'repackage')
    );
  };

  return (
    <LoadingCard
      loading={loadingPanel}
      percentage={percentage}
      isProgress={true}
    >
      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        marginBottom={2}
      ></Box>
      <div style={{ position: 'relative' }}>
        <TableContainer className={classes.table}>
          <Table stickyHeader aria-label="sticky table" ref={mainTable}>
            <TableHead>
              <TableRow>
                <TableCell align="center"># ID</TableCell>
                <TableCell align="left">{en['Status']}</TableCell>
                <TableCell align="left">{en['Identifier']}</TableCell>
                <TableCell align="left">{en['Name']}</TableCell>
                <TableCell align="left">
                  <TableSortLabel
                    active={true}
                    direction={typeSortDirection}
                    onClick={handleTypeSort}
                  >
                    {en['Type']}
                  </TableSortLabel>
                </TableCell>
                <TableCell align="left">{en['Size']}(KB)</TableCell>
                <TableCell align="left">
                  <TableSortLabel
                    active={true}
                    direction={updatedAtSortDirection}
                    onClick={handleUpdatedAtSort}
                  >
                    {en['Updated At']}
                  </TableSortLabel>
                </TableCell>
                {!disable ? (
                  <TableCell align="center"># {en['Action']}</TableCell>
                ) : (
                  []
                )}
              </TableRow>
            </TableHead>
            <TableBody>
              {loadedData.length > 0 &&
                loadedData.map((row, index) => (
                  <TableRow hover key={row._id}>
                    <TableCell component="th" scope="row" align="center">
                      {page === 1
                        ? index + 1
                        : index + 1 + (page - 1) * pageCount}
                    </TableCell>
                    <TableCell component="th" align="left">
                      {(row.status || '').capitalizeFirstLetter()}
                    </TableCell>
                    <TableCell component="th" align="left">
                      {row.name === 'app' ? row.desc?.short : row.name}
                    </TableCell>
                    <TableCell component="th" align="left">
                      {getDisplayName(row.desc?.title)}
                    </TableCell>
                    <TableCell component="th" align="left">
                      {row.name === 'app' ? row.name : row.desc?.short}
                    </TableCell>
                    <TableCell component="th" align="left">
                      {row.multimediaAssets?.length > 0 &&
                        row.multimediaAssets[0].data?.size}
                    </TableCell>
                    <TableCell component="th" align="left">
                      {getFormattedDate(row.updatedAt)}
                    </TableCell>
                    {!disable ? (
                      <TableCell component="th" align="center">
                        <Box textAlign="center">
                          {checkDownloadButton(row) ? (
                            <IconButton
                              size="small"
                              onClick={() =>
                                handleTableChange(
                                  'download',
                                  row.multimediaAssets[0]?.baseUrl +
                                    row.multimediaAssets[0]?.fileDir +
                                    row.multimediaAssets[0]?.fileName
                                )
                              }
                            >
                              <GetAppIcon />
                            </IconButton>
                          ) : (
                            <IconButton
                              size="small"
                              disabled="true"
                              onClick={() => handleTableChange('', null)}
                            >
                              <GetAppIcon />
                            </IconButton>
                          )}
                          <IconButton
                            size="small"
                            onClick={() => handleTableChange('info', row)}
                          >
                            <FontAwesomeIcon
                              icon={faInfo}
                              size="sm"
                              style={{ cursor: 'pointer' }}
                            />
                          </IconButton>
                          {/* <IconButton
                            size="small"
                            onClick={() => handleTableChange('delete', row._id)}
                          >
                            <DeleteIcon />
                          </IconButton> */}
                          <IconButton
                            size="small"
                            onClick={() => handleTableChange('refresh', row)}
                          >
                            {' '}
                            <AutorenewIcon />
                            {/* <FontAwesomeIcon
                              icon={faUndo}
                              size="sm"
                              style={{ cursor: 'pointer' }}
                            /> */}
                          </IconButton>
                        </Box>
                      </TableCell>
                    ) : (
                      []
                    )}
                  </TableRow>
                ))}
            </TableBody>
          </Table>
        </TableContainer>
        <Pagination
          count={totalPage || 1}
          size="small"
          page={page}
          siblingCount={0}
          showFirstButton
          showLastButton
          onChange={handleChangePage}
          className={classes.pagination}
        />
      </div>
      <CustomDialog
        open={openInfo}
        title={en['Information']}
        maxWidth="sm"
        fullWidth={true}
        onChange={handleInfoDialogChange}
      >
        <Grid item xs={12} sm={12} md={12} lg={12}>
          <JSONEditor disable={false} resources={selectedInfo} />
        </Grid>
      </CustomDialog>
      <CustomDialog
        open={openDeleteDialog}
        title={en[`Delete Package?`]}
        mainBtnName={en['Delete']}
        onChange={deleteData}
      >
        {en['Are you sure want to delete this package?']}
        <br />
        <CustomCheckBox
          color="primary"
          value={checkbox}
          label={en['I agree with this action.']}
          onChange={(value) => setCheckbox(!value)}
        />
      </CustomDialog>
    </LoadingCard>
  );
};

export default PackageListForm;
