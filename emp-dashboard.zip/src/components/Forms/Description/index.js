import React, { useState, useEffect, useRef } from 'react';
import clsx from 'clsx';
import { Grid, Typography } from '@material-ui/core';
import { CustomInput, CustomSelectBox } from '@app/components/Custom';
import { Edit, Save } from '@material-ui/icons';
import { DefaultCard, DescriptionCard } from '@app/components/Cards';
import {
  TitleText,
  ShortText,
  LongText,
  EditHelperText,
  SaveHelperText
} from '@app/components/Text';
import * as globalStyles from '@app/constants/globalStyles';
import { en } from '@app/language';

const DescriptionForm = ({
  disable,
  resources,
  onChange,
  helperText,
  disableGray,
  type,
  hideName,
  hideDescription,
  hideHelpText
}) => {
  const classes = globalStyles.DescCardStyle();
  const [loadedData, setLoadedData] = useState({
    title: '',
    short: '',
    long: ''
  });
  const [state, setState] = useState('');

  const titleRef = useRef();
  const shortRef = useRef();
  const longRef = useRef();

  useEffect(() => {
    setLoadedData({
      ...loadedData,
      ...resources
    });
  }, [resources]);

  const handleInputChange = (type, value) => {
    setLoadedData({
      ...loadedData,
      [type]: value
    });
    onChange({
      ...loadedData,
      [type]: value
    });
  };

  const handleKeyDown = (e, change) => {
    if (e.keyCode === 13 && !e.shiftKey) {
      if (e.target.name === 'title') {
        shortRef.current.focus();
      }
      if (e.target.name === 'short') {
        longRef.current.focus();
      }
      if (e.target.name === 'long') {
        titleRef.current.focus();
      }
      e.preventDefault();
    }
  };

  return (
    <React.Fragment>
      {disable ? (
        <React.Fragment>
          <DescriptionCard title={loadedData.title}>
            <TitleText
              heading="title"
              value={loadedData.title ? loadedData.title : ''}
            />
            <ShortText
              heading="short"
              value={loadedData.short ? loadedData.short : ''}
            />
            <LongText
              heading="long"
              value={loadedData.long ? loadedData.long : ''}
            />
          </DescriptionCard>
          {helperText && <EditHelperText />}
        </React.Fragment>
      ) : disableGray ? (
        <Grid className={classes.descSpacing1}>
          {!hideName && (
            <CustomInput
              multiline
              rows={1}
              label={type !== 'station' ? en['Title'] : en['Display Name']}
              variant="outlined"
              size="small"
              type="text"
              name="title"
              disabled={disable}
              inputRef={titleRef}
              style={clsx({
                [classes.inputArea]: true,
                [classes.descInput1]: true
              })}
              resources={loadedData.title}
              onKeyDown={handleKeyDown}
              onChange={(value) => handleInputChange('title', value)}
            />
          )}
          {!hideDescription && (
            <CustomInput
              multiline
              rows={2}
              label={
                type !== 'station' ? en['Short Description'] : en['Description']
              }
              variant="outlined"
              size="small"
              type="text"
              name="short"
              disabled={disable}
              inputRef={shortRef}
              style={clsx({
                [classes.inputArea]: true,
                [classes.descInput]: true
              })}
              resources={loadedData.short}
              onKeyDown={handleKeyDown}
              onChange={(value) => handleInputChange('short', value)}
            />
          )}
          {!hideHelpText && (
            <CustomInput
              multiline
              rows={4}
              label={
                type !== 'station' ? en['Long Description'] : en['Help Text']
              }
              variant="outlined"
              size="small"
              type="text"
              name="long"
              disabled={disable}
              inputRef={longRef}
              style={clsx({
                [classes.inputArea]: true
                // [classes.descInput1]: true
              })}
              resources={loadedData.long}
              onKeyDown={handleKeyDown}
              onChange={(value) => handleInputChange('long', value)}
            />
          )}
          {helperText && <SaveHelperText />}
        </Grid>
      ) : type !== 'station' ? (
        <Grid>
          <DefaultCard
            style={clsx({
              [classes.root]: !disable,
              [classes.preview]: disable,
              [classes.descSpacing]: true
            })}
            px={1}
          >
            {!hideName && (
              <CustomInput
                multiline
                rows={1}
                label={en['Title']}
                variant="outlined"
                size="small"
                type="text"
                name="title"
                disabled={disable}
                inputRef={titleRef}
                style={clsx({
                  [classes.inputArea]: true,
                  [classes.descInput]: true
                })}
                resources={loadedData.title}
                onKeyDown={handleKeyDown}
                onChange={(value) => handleInputChange('title', value)}
              />
            )}
            {!hideDescription && (
              <CustomInput
                multiline
                rows={2}
                label={en['Short Description']}
                variant="outlined"
                size="small"
                type="text"
                name="short"
                disabled={disable}
                inputRef={shortRef}
                style={clsx({
                  [classes.inputArea]: true,
                  [classes.descInput]: true
                })}
                resources={loadedData.short}
                onKeyDown={handleKeyDown}
                onChange={(value) => handleInputChange('short', value)}
              />
            )}
            {!hideHelpText && (
              <CustomInput
                multiline
                rows={4}
                label={en['Long Description']}
                variant="outlined"
                size="small"
                type="text"
                name="long"
                disabled={disable}
                inputRef={longRef}
                style={clsx({
                  [classes.inputArea]: true,
                  [classes.descInput]: true
                })}
                resources={loadedData.long}
                onKeyDown={handleKeyDown}
                onChange={(value) => handleInputChange('long', value)}
              />
            )}
          </DefaultCard>
          {helperText && <SaveHelperText />}
        </Grid>
      ) : (
        <Grid spacing={1} className={classes.descSpacing1}>
          {!hideName && (
            <CustomInput
              multiline
              rows={1}
              label={en['Display Name']}
              variant="outlined"
              size="small"
              type="text"
              name="title"
              disabled={disable}
              inputRef={titleRef}
              style={clsx({
                [classes.inputArea]: true,
                [classes.descInput1]: true
              })}
              resources={loadedData.title}
              onKeyDown={handleKeyDown}
              onChange={(value) => handleInputChange('title', value)}
            />
          )}
          {!hideDescription && (
            <CustomInput
              multiline
              rows={10}
              label={en['Description']}
              variant="outlined"
              size="small"
              type="text"
              name="short"
              disabled={disable}
              inputRef={shortRef}
              style={clsx({
                [classes.inputArea]: true,
                [classes.descInput1]: true
              })}
              resources={loadedData.short}
              onKeyDown={handleKeyDown}
              onChange={(value) => handleInputChange('short', value)}
            />
          )}
          {!hideHelpText && (
            <CustomInput
              multiline
              rows={1}
              label={en['Help Text']}
              variant="outlined"
              size="small"
              type="text"
              name="long"
              disabled={disable}
              inputRef={longRef}
              style={clsx({
                [classes.inputArea]: true,
                [classes.descInput1]: true
              })}
              resources={loadedData.long}
              onKeyDown={handleKeyDown}
              onChange={(value) => handleInputChange('long', value)}
            />
          )}
          {helperText && <SaveHelperText />}
        </Grid>
      )}
    </React.Fragment>
  );
};

export default DescriptionForm;
