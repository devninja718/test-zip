import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
  dialogPaper: {
    minHeight: '100%',
    maxHeight: '100%',
    maxWidth: '100%',
    paddingTop: 80
  }
}));

export default useStyles;
