import React from 'react';
import Dialog from '@material-ui/core/Dialog';
import useStyles from './style';
import { StationAdminEula } from '@app/components/Eula';

const EULAModal = ({ openModal, setOpenModal }) => {
  const classes = useStyles();

  const handleClose = (e) => {
    setOpenModal(false);
  };

  return (
    <Dialog open={openModal} classes={{ paper: classes.dialogPaper }}>
      <StationAdminEula fromSetting={true} onChange={handleClose} />
    </Dialog>
  );
};

export default EULAModal;
