import React, { useState, useEffect } from 'react';
import clsx from 'clsx';
import { CustomInput, CustomSelectBox } from '@app/components/Custom';
import USStates from '@app/constants/states.json';
import * as globalStyles from '@app/constants/globalStyles';

const StateSelect = ({ resources, stateValue, onStateChange, disable }) => {
  const classes = globalStyles.DescCardStyle();
  const [state, setState] = useState('');

  useEffect(() => {
    if (state !== stateValue) {
      setState(stateValue || '');
    }
  }, [resources, stateValue]);

  const handleStateChange = (item) => {
    setState(item?.value);
    onStateChange(item?.value);
  };

  return (
    <CustomSelectBox
      size="small"
      style={clsx({
        [classes.selectBox]: true
      })}
      label="State"
      variant="filled"
      resources={USStates}
      onChange={handleStateChange}
      value={state}
      disabled={disable}
      noPadding={true}
    />
  );
};

export default StateSelect;
