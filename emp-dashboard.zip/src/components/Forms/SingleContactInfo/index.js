/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, useRef } from 'react';
import clsx from 'clsx';
import { Grid, Typography } from '@material-ui/core';
import { CustomInput } from '@app/components/Custom';
import { DefaultCard } from '@app/components/Cards';
import { SaveHelperText } from '@app/components/Text';
import * as globalStyles from '@app/constants/globalStyles';

const SingleContactForm = ({
  disable,
  resources,
  onChange,
  helperText,
  title
}) => {
  const classes = globalStyles.DescCardStyle();
  const [loadedData, setLoadedData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: ''
  });

  const firstNameRef = useRef();
  const lastNameRef = useRef();
  const emailRef = useRef();
  const phoneRef = useRef();

  useEffect(() => {
    setLoadedData({
      ...loadedData,
      ...resources
    });
  }, [resources]);

  const handleInputChange = (type, value) => {
    setLoadedData({
      ...loadedData,
      [type]: value
    });
    onChange({
      ...loadedData,
      [type]: value
    });
  };

  const handleKeyDown = (e, change) => {
    if (e.keyCode === 13 && !e.shiftKey) {
      if (e.target.name === 'firstName') {
        firstNameRef.current.focus();
      }
      if (e.target.name === 'lastName') {
        lastNameRef.current.focus();
      }
      if (e.target.name === 'email') {
        emailRef.current.focus();
      }
      if (e.target.name === 'phone') {
        phoneRef.current.focus();
      }
      e.preventDefault();
    }
  };

  const getTitle = () => {
    if (title) {
      return title;
    } else {
      return 'Educator';
    }
  };

  return (
    <React.Fragment>
      {disable ? (
        <React.Fragment></React.Fragment>
      ) : (
        // <DefaultCard
        //   style={clsx({
        //     [classes.root]: !disable,
        //     [classes.preview]: disable
        //   })}
        //   px={1}
        // >
        <Grid
          container
          spacing={4}
          direction="column"
          justify="flex-start"
          alignItems="flex-start"
          // style={{
          //   padding: 20
          // }}
        >
          <Grid item xs={12}>
            <Typography variant="body2">{getTitle()} Contact Info:</Typography>
          </Grid>
          <Grid
            item
            xs={12}
            md={12}
            lg={12}
            style={{ paddingTop: 0, width: '100%' }}
          >
            <CustomInput
              rows={1}
              label="First Name"
              variant="outlined"
              size="small"
              type="text"
              name="firstName"
              disabled={disable}
              inputRef={firstNameRef}
              style={clsx({
                [classes.inputArea]: true,
                [classes.classInput]: true
              })}
              resources={loadedData.firstName}
              onKeyDown={handleKeyDown}
              onChange={(value) => handleInputChange('firstName', value)}
            />
          </Grid>
          <Grid
            item
            xs={12}
            md={12}
            lg={12}
            style={{ paddingTop: 0, width: '100%' }}
          >
            <CustomInput
              rows={1}
              label="Last Name"
              variant="outlined"
              size="small"
              type="text"
              name="lasttName"
              disabled={disable}
              inputRef={lastNameRef}
              style={clsx({
                [classes.inputArea]: true,
                [classes.classInput]: true
              })}
              resources={loadedData.lastName}
              onKeyDown={handleKeyDown}
              onChange={(value) => handleInputChange('lastName', value)}
            />
          </Grid>
          <Grid
            item
            xs={12}
            md={12}
            lg={12}
            style={{ paddingTop: 0, width: '100%' }}
          >
            <CustomInput
              rows={1}
              label="Email"
              variant="outlined"
              size="small"
              type="text"
              name="email"
              disabled={disable}
              inputRef={emailRef}
              style={clsx({
                [classes.inputArea]: true,
                [classes.classInput]: true
              })}
              resources={loadedData.email}
              onKeyDown={handleKeyDown}
              onChange={(value) => handleInputChange('email', value)}
            />
          </Grid>
          <Grid
            item
            xs={12}
            md={12}
            lg={12}
            style={{ paddingTop: 0, width: '100%' }}
          >
            <CustomInput
              rows={1}
              label="Phone Number"
              variant="outlined"
              size="small"
              type="text"
              name="phone"
              disabled={disable}
              inputRef={phoneRef}
              style={clsx({
                [classes.inputArea]: true,
                [classes.classInput]: true
              })}
              resources={loadedData.phone}
              onKeyDown={handleKeyDown}
              onChange={(value) => handleInputChange('phone', value)}
            />
          </Grid>
          {helperText && <SaveHelperText />}
        </Grid>
        // </DefaultCard>
      )}
    </React.Fragment>
  );
};

export default SingleContactForm;
