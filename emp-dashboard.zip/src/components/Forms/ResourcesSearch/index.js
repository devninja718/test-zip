import React, { useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {
  Box,
  Button,
  InputBase,
  IconButton,
  Typography
} from '@material-ui/core';
import { Search as SearchIcon } from '@material-ui/icons';
import { CustomSelectBox, CustomInput } from '@app/components/Custom';
import UserSearch from '@app/components/Forms/UserList/Search';
import { Search } from '@material-ui/icons';

const MessageStatus = [
  { label: 'Set the start to now', value: 'active' },
  { label: 'Set the start to the future', value: 'inactive' },
  { label: 'Set the end to past', value: 'expired' }
];

const useStyles = makeStyles((theme) => ({
  root: {
    padding: '0px 4px',
    display: 'flex',
    alignItems: 'center',
    width: '80%',
    marginTop: 2
  },
  input: {
    marginLeft: theme.spacing(1),
    flex: 1
  },
  iconButton: {
    padding: 10
  },
  divider: {
    height: 28,
    margin: 4
  },
  selectFilter: {
    // minHeight: 50,
    background: theme.palette.common.white,
    width: '100%'
  }
}));

const ResourcesSearchForm = ({ resources, sourceType, onChange }) => {
  const classes = useStyles();
  const [searchKey, setSearchKey] = useState();
  const [status, setStatus] = useState('');
  const [contentType, setContentType] = useState(sourceType);

  const handleClick = () => {
    onChange(searchKey);
  };

  const handleChanges = (type, value) => {
    if (type === 'grade') {
      setStatus(value);
      onChange('grade', value);
    }
    if (type === 'contentType') {
      setContentType(value);
      onChange('contentType', value);
    }
  };

  return (
    <Box className={classes.root}>
      <CustomInput
        label="What you are searching for?"
        type="text"
        variant="outlined"
        size="small"
        style={classes.input}
        // onChange={(value) => setName(value)}
      />

      <CustomSelectBox
        variant="outlined"
        label="Grade Level"
        style={classes.selectFilter}
        variant="outlined"
        value={status}
        resources={resources}
        onChange={(event) => handleChanges('grade', event)}
        size="small"
      />

      <CustomInput
        label="Category?"
        type="text"
        variant="outlined"
        size="small"
        style={classes.input}
        // onChange={(value) => setName(value)}
      />

      <CustomSelectBox
        id="istricts"
        label="Source"
        variant="outlined"
        value={contentType}
        resources={['All Resources', 'PBS Learning Media', 'OER Common']}
        style={classes.selectFilter}
        onChange={(event) => handleChanges('contentType', event)}
        size="small"
      />
    </Box>
  );
};

export default ResourcesSearchForm;
