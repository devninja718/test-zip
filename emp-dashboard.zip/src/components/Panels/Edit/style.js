import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
  root: {
    background: theme.palette.primary.contrastText,
    padding: theme.spacing(1),
    flexGrow: 1,
    overflowX: 'auto',
    paddingBottom: 100
  },
  toolbar: {
    display: 'flex',
    alignItems: 'center',
    fontWeight: 700,
    position: 'relative',
    color: theme.palette.blueGrey['500'],
    overflow: 'hidden'
  },
  separator: {
    background: theme.palette.blueGrey['500'],
    height: 2,
    marginBottom: theme.spacing(2)
  },
  actionGroup: {
    display: 'flex',
    position: 'absolute',
    right: 0,
    '@media (max-width:1280px) and (min-width:1280px)': {
      marginRight: '7vw'
    }
  },
  actionButton: {
    // color: theme.palette.blueGrey['800'],
    marginLeft: '2px',
    marginRight: '2px',
    // background: theme.palette.blueGrey['50'],
    background: '#37474f !important',
    paddingTop: 0,
    paddingBottom: 0,
    borderRadius: 3,
    marginBottom: theme.spacing(0.5),
    textTransform: 'none',
    '& .svg-inline--fa': {
      fontSize: '16px'
    },
    height: 30,
    marginBottom: 4
  },
  main: {
    overflowY: 'auto',
    height: 'calc(100vh - 180px)',
    overflowX: 'hidden'
    // overflowY: 'hidden'
  },
  sliderMenuArea: {
    height: 53,
    marginTop: -53,
    flex: 1,
    flexDirection: 'column',
    zIndex: theme.zIndex.drawer + 100,
    position: 'absolute'
  },
  sliderMenu: {
    height: 50,
    marginTop: 0,
    display: 'flex'
  },
  indicator: {
    backgroundColor: theme.palette.blueGrey['800']
  },
  tab: {
    minWidth: 110,
    paddingTop: theme.spacing(4)
  },
  addBtn: {
    // background: theme.palette.blueGrey['500'],
    backgroundColor: '#37474f !important',
    color: 'white',
    height: 30,
    marginLeft: theme.spacing(2),
    '&:hover': {
      background: theme.palette.blueGrey['500'],
      color: theme.palette.blueGrey['50']
    }
  }
}));

export default useStyles;
