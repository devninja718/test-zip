import React, { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { useMenuContext } from '@app/providers/MenuContext';
import {
  Box,
  Button,
  Typography,
  Divider,
  IconButton,
  Paper,
  Tab,
  Tabs,
  Select,
  MenuItem
} from '@material-ui/core';
import {
  Save,
  Publish,
  Cancel,
  Delete,
  Edit,
  CloudUpload,
  RemoveRedEye,
  CloudDownload,
  Search,
  Add,
  GetApp,
  ArrowBackIosRounded
} from '@material-ui/icons';
import {
  faPlus,
  faUserPlus,
  faSearch,
  faList,
  faInfo,
  faUndo,
  faChevronRight,
  faChevronLeft,
  faFileImport
} from '@fortawesome/free-solid-svg-icons';

import useStyles from './style';
import { ImageList } from '@app/components/GalleryPanel';
import { useUserContext } from '@app/providers/UserContext';
import { useGalleryContext } from '@app/providers/GalleryContext';
import ResourcesSearchForm from '@app/components/Forms/ResourcesSearch';
import { en } from '@app/language';
import { useNotifyContext } from '@app/providers/NotifyContext';

const getSchemaTitle = (schemaType) => {
  const schemas = {
    station: 'Station',
    district: 'District',
    class: 'Class',
    school: 'School',
    material: 'Material'
  };
  const schemaTitle = schemas[schemaType];
  if (schemaTitle) {
    return schemaTitle;
  }
  return schemaType;
};

const EditPanel = ({
  title,
  schemaType,
  panelSize,
  canPublish,
  publishType,
  canShowPublis,
  canUpdate,
  canEdit,
  canNew,
  canDelete,
  canUpload,
  canFilter,
  canAdd,
  canList,
  canGallery,
  galleryType,
  canSearch,
  canShowInfo,
  tabSetting,
  isTabReset,
  onChange,
  onSearch,
  onTabChnage,
  children,
  hideAction,
  filterData,
  filterValue,
  onFilter,
  showLeftDropDown,
  showPreview,
  activePreview,
  canRefresh,
  currentMenu,
  canSaveConfig,
  canSave,
  canDownload,
  selectedData,
  canIngest,
  isMenuCenter,
  canCancel,
  gradeResources,
  showMoreMode,
  UserSearch,
  tabValue,
  tabStatus,
  canSubmit
}) => {
  const classes = useStyles();
  const [value, setValue] = useState(tabValue || 0);
  const [superAdmin, setSuperAdmin] = useState(false);
  const [isMenuOpen] = useMenuContext();
  const {
    openRight,
    setOpenRight,
    setGalleryChildren,
    setGalleryData,
    setSearchGallery
  } = useGalleryContext();
  const [currentUser] = useUserContext();
  const [spinRefresh, setSpinRefresh] = useState(false);
  const { notify } = useNotifyContext();

  useEffect(() => {
    const onLoad = async () => {
      try {
        if (currentUser?.schemaType === 'superAdmin') {
          setSuperAdmin(true);
        }
      } catch (err) {
        console.log(err);
      }
    };
    if (currentUser) {
      onLoad();
    }
  }, [currentUser]);

  useEffect(() => {
    if (isTabReset) {
      setValue(0);
    }
  }, [isTabReset]);

  useEffect(() => {
    setValue(tabValue || 0);
    if (onTabChnage) onTabChnage(tabValue || 0);
  }, [tabValue]);

  const handleChange = (event, newValue) => {
    setValue(newValue);
    onTabChnage(newValue);
  };

  function wait(timeout) {
    return new Promise((resolve) => {
      setTimeout(resolve, timeout);
    });
  }

  const handleRefresh = async () => {
    setSpinRefresh(true);
    onChange('refresh');
  };

  useEffect(() => {
    const doRefresh = async () => {
      if (spinRefresh) {
        await wait(1000);
        setSpinRefresh(false);
      }
    };

    doRefresh();
  }, [spinRefresh]);

  const setUpGallery = () => {
    if (!openRight) {
      setSearchGallery('');
      if (galleryType === 'banner') {
        setGalleryData((data) => ({ ...data, title: 'Banner Gallery' }));
        setGalleryChildren(<ImageList schemaType="stockBanner" />);
      } else if (galleryType === 'avatar') {
        setGalleryData((data) => ({ ...data, title: 'Avatar Gallery' }));
        setGalleryChildren(<ImageList schemaType="stockAvatar" />);
      } else if (galleryType === 'image') {
        setGalleryData((data) => ({ ...data, title: 'Image Gallery' }));
        setGalleryChildren(<ImageList schemaType="stockImage" />);
      } else {
        setGalleryData((data) => ({ ...data, title: 'Logo Gallery' }));
        setGalleryChildren(<ImageList schemaType="stockLogo" />);
      }
    }

    setOpenRight((state) => !state);
  };

  return (
    <Box className={classes.root}>
      {tabSetting && (
        <div
          className={classes.sliderMenuArea}
          style={{
            width:
              currentUser.schemaType === 'schoolAdmin'
                ? 'calc(100% - 670px)'
                : 'calc(100% - 520px)'
          }}
        >
          <Paper
            elevation={0}
            style={{
              justifyContent: 'center',
              alignItems: 'center',
              position: isMenuCenter ? 'relative' : 'absolute'
            }}
            className={classes.sliderMenu}
          >
            <Tabs
              value={value}
              onChange={handleChange}
              classes={{
                indicator: classes.indicator
              }}
            >
              {tabSetting.desc && (
                <Tab label={en['Description']} className={classes.tab} />
              )}

              {tabSetting.packages && (
                <Tab label={en['Packages']} className={classes.tab} />
              )}

              {tabSetting.config && (
                <Tab label={en['Config']} className={classes.tab} />
              )}

              {tabSetting.topology && (
                <Tab label={en['Topology']} className={classes.tab} />
              )}
              {tabSetting.people && (
                <Tab label={en['Users']} className={classes.tab} />
              )}
              {tabSetting.htmlEditor && (
                <Tab label={en['HTML Editor']} className={classes.tab} />
              )}
              {tabSetting.attachment && (
                <Tab label={en['Attachments']} className={classes.tab} />
              )}
              {tabSetting.teachers && (
                <Tab label={en['Educators']} className={classes.tab} />
              )}
              {tabSetting.students && (
                <Tab label={en['Students']} className={classes.tab} />
              )}

              {tabSetting.administrator && (
                <Tab label={en['Administrators']} className={classes.tab} />
              )}

              {tabSetting.categories && (
                <Tab label={en['Categories']} className={classes.tab} />
              )}
              {tabSetting.asset && (
                <Tab label={en['Asset']} className={classes.tab} />
              )}
              {tabSetting.styles && (
                <Tab label={en['Styles']} className={classes.tab} />
              )}

              {tabSetting.analyse && (
                <Tab label={en['Analytics']} className={classes.tab} />
              )}

              {tabSetting.systemMessages && (
                <Tab label={en['System Messages']} className={classes.tab} />
              )}

              {tabSetting.criteria && (
                <Tab label={en['Metadata']} className={classes.tab} />
              )}

              {tabSetting.data && (
                <Tab label={en['Data']} className={classes.tab} />
              )}

              {tabSetting.files && (
                <Tab label={en['Files']} className={classes.tab} />
              )}

              {tabSetting.right && (
                <Tab
                  label={en['Rights Management']}
                  disabled={tabSetting.disableMenu?.right ? true : false}
                  className={classes.tab}
                />
              )}
            </Tabs>
          </Paper>
        </div>
      )}
      <Box p={1}>
        <div className={classes.toolbar}>
          {schemaType === 'tutorial' &&
          ((!canUpdate && canAdd) || !showMoreMode) ? (
            <Typography variant="subtitle1" style={{ fontWeight: 500 }}>
              {UserSearch ? UserSearch : title}
            </Typography>
          ) : schemaType === 'tutorial' && (!canAdd || canUpdate) ? (
            <Button
              onClick={(e) => {
                schemaType === 'tutorial' && !canAdd
                  ? onChange('backToTutorials')
                  : onChange('cancel');
              }}
              className={classes.actionButton}
              startIcon={<ArrowBackIosRounded />}
              variant="contained"
              color="primary"
            >
              {en['Back to Tutorials']}
            </Button>
          ) : title === 'Resources' ? (
            <ResourcesSearchForm
              resources={gradeResources}
              sourceType={'All Resources'}
              onChange={(type, value) => onChange(type, value)}
            />
          ) : (
            <Typography variant="subtitle1" style={{ fontWeight: 500 }}>
              {UserSearch ? UserSearch : title}
            </Typography>
          )}
          {!hideAction ? (
            <div className={classes.actionGroup}>
              {canIngest && (
                <Button
                  onClick={() => onChange('ingest')}
                  className={classes.actionButton}
                  disabled={!canEdit}
                  startIcon={
                    <FontAwesomeIcon
                      icon={faFileImport}
                      size="sm"
                      style={{ cursor: 'pointer' }}
                    />
                  }
                  variant="contained"
                  color="primary"
                >
                  {en['Ingest']}
                </Button>
              )}
              {title !== 'Tutorial' && canAdd && (
                <Button
                  onClick={() => onChange('add')}
                  className={classes.actionButton}
                  disabled={!canEdit}
                  startIcon={
                    <FontAwesomeIcon
                      icon={faUserPlus}
                      size="sm"
                      style={{ cursor: 'pointer' }}
                    />
                  }
                  variant="contained"
                  color="primary"
                >
                  {tabStatus?.teachers ? en['Add Educator'] : en['Add User']}
                </Button>
              )}

              {title === 'Tutorial' && canAdd && !canUpdate && (
                <Button
                  onClick={() => onChange('add')}
                  className={classes.actionButton}
                  disabled={!canEdit}
                  startIcon={
                    <FontAwesomeIcon
                      icon={faPlus}
                      size="sm"
                      style={{ cursor: 'pointer' }}
                    />
                  }
                  variant="contained"
                  color="primary"
                >
                  {en['New']}
                </Button>
              )}

              {publishType && (
                <Button
                  onClick={() => onChange('packageDownload')}
                  className={classes.actionButton}
                  disabled={!canEdit}
                  startIcon={<GetApp />}
                  variant="contained"
                  color="primary"
                >
                  {en['Download All']}
                </Button>
              )}
              {canPublish && (
                <Button
                  onClick={() => onChange('publish')}
                  className={classes.actionButton}
                  disabled={!canEdit}
                  startIcon={<Publish />}
                  variant="contained"
                  color="primary"
                >
                  {publishType ? en['Trigger Packaging'] : en['Publish']}
                </Button>
              )}
              {title !== 'Tutorial' &&
                schemaType !== 'tutorial' &&
                canSave &&
                (canUpdate ? (
                  <Button
                    onClick={() => onChange('save')}
                    className={classes.actionButton}
                    disabled={!canEdit}
                    startIcon={<Save />}
                    variant="contained"
                    color="primary"
                  >
                    {en['Save']}
                  </Button>
                ) : (
                  title !== 'Resources' &&
                  title !== 'Clear' && (
                    <IconButton
                      onClick={() => onChange('edit')}
                      className={classes.actionButton}
                      disabled={!canEdit}
                      style={{ cursor: 'pointer', color: 'white' }}
                    >
                      <Edit />
                    </IconButton>
                  )
                ))}
              {title === 'Tutorial' && canUpdate && (
                <Button
                  onClick={() => onChange('save')}
                  className={classes.actionButton}
                  disabled={!canEdit}
                  startIcon={<Save />}
                  variant="contained"
                  color="primary"
                >
                  {en['Save']}
                </Button>
              )}

              {/* {canSearch && (
                <Button
                  onClick={() => onChange('search')}
                  className={classes.actionButton}
                  // disabled={!canEdit}
                  startIcon={<Search />}
                  variant="contained"
                  color="primary"
                >
                  Search
                </Button>
              )} */}
              {canDelete && (
                <Button
                  onClick={() => onChange('delete')}
                  className={classes.actionButton}
                  // disabled={!canEdit}
                  startIcon={<Delete />}
                  variant="contained"
                  color="primary"
                >
                  {en['Delete']}
                </Button>
              )}
              {canRefresh && (
                <Button
                  onClick={() => onChange('refresh')}
                  className={classes.actionButton}
                  disabled={!canRefresh}
                  startIcon={
                    <FontAwesomeIcon
                      icon={faUndo}
                      spin={spinRefresh}
                      size="sm"
                      style={{
                        animationDirection: 'alternate-reverse',
                        cursor: 'pointer'
                      }}
                    />
                  }
                  variant="contained"
                  color="primary"
                >
                  {en['Refresh']}
                </Button>
              )}
              {showPreview && (
                <Button
                  onClick={() => {
                    if (!activePreview) {
                      notify(
                        'There are no active students published for this station.',
                        {
                          variant: 'warning',
                          autoHideDuration: 3000
                        }
                      );
                    } else onChange('preview');
                  }}
                  className={classes.actionButton}
                  // disabled={!canEdit}
                  startIcon={<RemoveRedEye />}
                  variant="contained"
                  color={activePreview ? 'primary' : 'inherit'}
                >
                  {en['Preview']}
                </Button>
              )}
              {canShowInfo && superAdmin && (
                <Button
                  onClick={() => onChange('info')}
                  className={classes.actionButton}
                  disabled={!canEdit}
                  startIcon={
                    <FontAwesomeIcon
                      icon={faInfo}
                      size="sm"
                      style={{ cursor: 'pointer' }}
                    />
                  }
                  variant="contained"
                  color="primary"
                >
                  {en['Info']}
                </Button>
              )}
              {canGallery ? (
                <Button
                  onClick={setUpGallery}
                  className={classes.actionButton}
                  disabled={!canEdit}
                  startIcon={
                    <FontAwesomeIcon
                      icon={openRight ? faChevronLeft : faChevronRight}
                      size="sm"
                      style={{ cursor: 'pointer' }}
                    />
                  }
                  variant="contained"
                  color="primary"
                >
                  {en['Galleries']}
                </Button>
              ) : (
                []
              )}

              {canSearch && (
                <Button
                  onClick={() => onChange('search')}
                  className={classes.actionButton}
                  // disabled={!canEdit}
                  startIcon={<Search />}
                  variant="contained"
                  color="primary"
                >
                  {en['Search']}
                </Button>
              )}
              {canDownload && (
                <Button
                  onClick={() => onChange('download')}
                  className={classes.actionButton}
                  disabled={!canEdit}
                  startIcon={<CloudDownload />}
                  variant="contained"
                  color="primary"
                >
                  {en['Download Data']}
                </Button>
              )}
              {canCancel && (
                <Button
                  onClick={() => onChange('cancel')}
                  className={classes.actionButton}
                  startIcon={<Cancel />}
                  variant="contained"
                  color="primary"
                >
                  {en['Cancel']}
                </Button>
              )}
              {canSubmit && (
                <Button
                  onClick={() => onChange('submit')}
                  className={classes.actionButton}
                  // startIcon={<Cancel />}
                  variant="contained"
                  color="primary"
                >
                  {en['Submit']}
                </Button>
              )}
            </div>
          ) : (
            <div className={classes.actionGroup}>
              {canSaveConfig && (
                <Button
                  onClick={() => onChange('save')}
                  className={classes.actionButton}
                  disabled={!canEdit}
                  startIcon={<Save />}
                  variant="contained"
                  color="primary"
                >
                  {en['Save']}
                </Button>
              )}
              {canUpload && (
                <Button
                  onClick={() => onChange('upload')}
                  className={classes.actionButton}
                  disabled={!canEdit}
                  startIcon={<CloudUpload />}
                  variant="contained"
                  color="primary"
                >
                  {en['Bulk Upload']}
                </Button>
              )}
              {canIngest && (
                <Button
                  onClick={() => onChange('ingest')}
                  className={classes.actionButton}
                  disabled={!canEdit}
                  startIcon={
                    <FontAwesomeIcon
                      icon={faFileImport}
                      size="sm"
                      style={{ cursor: 'pointer' }}
                    />
                  }
                  variant="contained"
                  color="primary"
                >
                  {en['Ingest']}
                </Button>
              )}
              {canAdd && (
                <Button
                  onClick={() => onChange('add')}
                  className={classes.actionButton}
                  disabled={!canEdit}
                  startIcon={
                    <FontAwesomeIcon
                      icon={faUserPlus}
                      size="sm"
                      style={{ cursor: 'pointer' }}
                    />
                  }
                  variant="contained"
                  color="primary"
                >
                  {tabStatus?.teachers ? en['Add Educator'] : en['Add User']}
                </Button>
              )}

              {canDelete && currentMenu === 'user' && (
                <Button
                  onClick={() => onChange('delete')}
                  className={classes.actionButton}
                  startIcon={<Delete />}
                  variant="contained"
                  color="primary"
                >
                  {en['Delete']}
                </Button>
              )}
              {canList && (
                <IconButton
                  onClick={() => onChange('list')}
                  className={classes.actionButton}
                  disabled={!canEdit}
                >
                  <FontAwesomeIcon
                    icon={faList}
                    size="sm"
                    style={{ cursor: 'pointer', color: 'white' }}
                  />
                </IconButton>
              )}
              {canSearch && (
                <IconButton
                  onClick={() => onChange('search')}
                  className={classes.actionButton}
                  disabled={!canEdit}
                >
                  <FontAwesomeIcon
                    icon={faSearch}
                    size="sm"
                    style={{ cursor: 'pointer', color: 'white' }}
                  />
                </IconButton>
              )}
              {canFilter && !showLeftDropDown && (
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={filterValue}
                  style={{ minWidth: '150px' }}
                  onChange={(event) => onFilter(event.target.value)}
                >
                  <MenuItem value="all">All</MenuItem>
                  {filterData.map((item, index) => (
                    <MenuItem value={item.value} key={index}>
                      {item.label}
                    </MenuItem>
                  ))}
                </Select>
              )}

              {publishType && (
                <Button
                  onClick={() => onChange('packageDownload')}
                  className={classes.actionButton}
                  disabled={!canEdit}
                  startIcon={<GetApp />}
                  variant="contained"
                  color="primary"
                >
                  {en['Download All']}
                </Button>
              )}

              {canPublish && (
                <Button
                  onClick={() => onChange('publish')}
                  className={classes.actionButton}
                  disabled={!canEdit}
                  startIcon={<Publish />}
                  variant="contained"
                  color="primary"
                >
                  {publishType ? en['Trigger Packaging'] : en['Publish']}
                </Button>
              )}

              {canRefresh && (
                <Button
                  onClick={handleRefresh}
                  className={classes.actionButton}
                  disabled={!canRefresh}
                  startIcon={
                    <FontAwesomeIcon
                      icon={faUndo}
                      spin={spinRefresh}
                      size="sm"
                      style={{
                        animationDirection: 'alternate-reverse',
                        cursor: 'pointer'
                      }}
                    />
                  }
                  variant="contained"
                  color="primary"
                >
                  {en['Refresh']}
                </Button>
              )}
              {canShowInfo && superAdmin && (
                <Button
                  onClick={() => onChange('info')}
                  className={classes.actionButton}
                  disabled={!canEdit}
                  startIcon={
                    <FontAwesomeIcon
                      icon={faInfo}
                      size="sm"
                      style={{ cursor: 'pointer' }}
                    />
                  }
                  variant="contained"
                  color="primary"
                >
                  {en['Info']}
                </Button>
              )}
              {canNew && (
                <Button
                  variant="contained"
                  size="small"
                  style={{ marginBottom: 5 }}
                  onClick={() => onChange('new')}
                  className={classes.addBtn}
                  startIcon={<Add />}
                  variant="contained"
                  color="primary"
                >
                  {en['New']}
                </Button>
              )}
              {canDownload && (
                <Button
                  onClick={() => onChange('download')}
                  className={classes.actionButton}
                  disabled={!canEdit}
                  startIcon={<CloudDownload />}
                  variant="contained"
                  color="primary"
                >
                  {en['Download Data']}
                </Button>
              )}
              {canCancel && (
                <Button
                  onClick={() => onChange('cancel')}
                  className={classes.actionButton}
                  startIcon={<Cancel />}
                  variant="contained"
                  color="primary"
                >
                  {en['Cancel']}
                </Button>
              )}
              {canGallery ? (
                <Button
                  onClick={setUpGallery}
                  className={classes.actionButton}
                  disabled={!canEdit}
                  startIcon={
                    <FontAwesomeIcon
                      icon={openRight ? faChevronLeft : faChevronRight}
                      size="sm"
                      style={{ cursor: 'pointer' }}
                    />
                  }
                  variant="contained"
                  color="primary"
                >
                  {en['Galleries']}
                </Button>
              ) : (
                []
              )}
            </div>
          )}
        </div>
        <Divider className={classes.separator} />
        <main className={classes.main}>{children}</main>
      </Box>
    </Box>
  );
};

EditPanel.defaultProps = {
  canSave: true
};

export default EditPanel;
