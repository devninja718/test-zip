/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect } from 'react';
import { Box, Typography, Divider, Button, Grid } from '@material-ui/core';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faPlus,
  faUpload,
  faUndo,
  faFileImport,
  faTrash,
  faArrowLeft
} from '@fortawesome/free-solid-svg-icons';
import { Resizable } from 'react-resizable';
import { useMenuContext } from '@app/providers/MenuContext';
import useStyles from './style';
import { useUserContext } from '@app/providers/UserContext';
import { usePaginationContext } from '@app/providers/Pagination';
import CustomPagination from '@app/components/Pagination';
import { en } from '@app/language';

const MainPanel = ({
  icon,
  title,
  showAddBtn,
  showRefresh,
  totalDisable,
  disableAddBtn,
  canPublish,
  canReload,
  canImport,
  showDeleteBtn,
  onChange,
  children,
  extraComponent,
  selectedTreeItem,
  viewMethod,
  cardViewList
}) => {
  const classes = useStyles();
  const [isMenuOpen, setIsMenuOpen, , , , , setTempOpenMenu] = useMenuContext();
  const [spinRefresh, setSpinRefresh] = useState(false);
  const listPanelWidth = localStorage.getItem('listPanelWidth');
  const [panelSize, setPanelSize] = useState({
    width: listPanelWidth
      ? cardViewList
        ? parseInt(listPanelWidth) < 350
          ? 350
          : parseInt(listPanelWidth)
        : parseInt(listPanelWidth)
      : cardViewList
      ? 350
      : 310,
    height: 0
  });

  const [currentUser] = useUserContext();

  const userInfo = currentUser || null;

  const pathName = window.location.pathname;

  const [, setClassVariables] = usePaginationContext();
  const [, setClassWithoutAuthorVariables] = usePaginationContext();

  useEffect(() => {
    if (!isMenuOpen) {
      setIsMenuOpen(true);
    }
  }, []);

  function wait(timeout) {
    return new Promise((resolve) => {
      setTimeout(resolve, timeout);
    });
  }

  const handleRefresh = async () => {
    setSpinRefresh(true);
    onChange('refresh');
  };

  useEffect(() => {
    const doRefresh = async () => {
      if (spinRefresh) {
        await wait(1000);
        setSpinRefresh(false);
      }
    };

    doRefresh();
  }, [spinRefresh]);

  const handleHover = () => {
    if (!isMenuOpen) {
      setTempOpenMenu(true);
    }
  };

  const handleUnHover = () => {
    if (!isMenuOpen) {
      setTempOpenMenu(false);
    }
  };

  const onResize = (event, { element, size, handle }) => {
    let width = size.width;
    if (width < 300) {
      width = 300;
    }
    if (cardViewList && width < 350) {
      width = 350;
    }
    localStorage.setItem('listPanelWidth', width);
    setPanelSize({ width: width });
  };

  return viewMethod !== 'card' || cardViewList ? (
    <Resizable
      width={panelSize.width}
      height={200}
      axis="x"
      onResize={onResize}
      className={classes.resizable}
    >
      <Box
        className={classes.root}
        height={panelSize.height}
        onMouseOver={handleHover}
        onMouseOut={handleUnHover}
        style={{
          width: panelSize.width,
          transition: 'all 0.3s'
        }}
      >
        <div className={classes.toolbar}>
          <div style={{ width: '10%' }}>
            <FontAwesomeIcon
              icon={icon}
              size="1x"
              style={{ marginRight: '15px', width: '16px', height: '16px' }}
            />
          </div>
          <div>
            <Typography
              variant="h6"
              style={{ fontWeight: 600, fontSize: '1rem' }}
            >
              {title}
            </Typography>
          </div>
          {extraComponent}
          {showAddBtn && (
            <div className={classes.menu}>
              <Button
                onClick={() =>
                  (selectedTreeItem && disableAddBtn) || totalDisable
                    ? onChange('')
                    : onChange('create')
                }
                className={classes.actionButton}
                disabled={(selectedTreeItem && disableAddBtn) || totalDisable}
                startIcon={
                  <FontAwesomeIcon
                    icon={faPlus}
                    size="sm"
                    style={
                      (selectedTreeItem && disableAddBtn) || totalDisable
                        ? { opacity: 0.6, cursor: 'not-allowed' }
                        : { cursor: 'pointer' }
                    }
                  />
                }
                variant="contained"
                color="primary"
                id="newButton"
              >
                {en['New']}
              </Button>
              {canPublish && (
                <FontAwesomeIcon
                  icon={faUpload}
                  size="lg"
                  onClick={() => onChange('publish')}
                  style={{ cursor: 'pointer' }}
                />
              )}
              {canReload && (
                <FontAwesomeIcon
                  icon={faUndo}
                  size="lg"
                  onClick={() => onChange('reload')}
                  style={{ cursor: 'pointer' }}
                />
              )}
              {showDeleteBtn && (
                <FontAwesomeIcon
                  icon={faTrash}
                  size="lg"
                  onClick={() => onChange('delete')}
                  style={{ cursor: 'pointer' }}
                />
              )}
              {showRefresh && (
                <Button
                  onClick={handleRefresh}
                  className={classes.actionButton}
                  startIcon={
                    <FontAwesomeIcon
                      icon={faUndo}
                      size="sm"
                      spin={spinRefresh}
                      style={{
                        animationDirection: 'alternate-reverse',
                        cursor: 'pointer'
                      }}
                    />
                  }
                  variant="contained"
                  color="primary"
                >
                  {en['Reload']}
                </Button>
              )}
            </div>
          )}
          {canImport && (
            <div className={classes.menu}>
              <FontAwesomeIcon
                icon={faFileImport}
                size="lg"
                onClick={() => onChange('import')}
                style={{ cursor: 'pointer' }}
              />
            </div>
          )}
          {cardViewList && (
            <div className={classes.menu}>
              <Button
                onClick={() => onChange('back')}
                className={classes.actionButton}
                startIcon={
                  <FontAwesomeIcon
                    icon={faArrowLeft}
                    size="sm"
                    spin={spinRefresh}
                    style={{
                      animationDirection: 'alternate-reverse',
                      cursor: 'pointer'
                    }}
                  />
                }
                variant="contained"
                color="primary"
              >
                {en['Back to Classes']}
              </Button>
            </div>
          )}
        </div>
        <Divider className={classes.separator} />
        <main
          className={classes.main}
          style={
            pathName.includes('/materials')
              ? { height: 'calc(100vh - 210px)' }
              : {}
          }
        >
          {children}
        </main>
        {pathName.includes('/materials') &&
          (cardViewList ? (
            <CustomPagination
              userInfo={userInfo}
              cardViewList={cardViewList}
              // handlePagination={}
            />
          ) : (
            <CustomPagination
              userInfo={userInfo}
              handlePagination={
                userInfo?.schemaType === 'sysAdmin' ||
                userInfo?.schemaType === 'superAdmin'
                  ? setClassWithoutAuthorVariables
                  : setClassVariables
              }
            />
          ))}
      </Box>
    </Resizable>
  ) : (
    <Grid className={classes.root} style={{ width: '100%' }}>
      <div className={classes.toolbar} style={{ marginBottom: 3 }}>
        <div>
          <FontAwesomeIcon
            icon={icon}
            size="1x"
            style={{ marginRight: '15px', width: '16px', height: '16px' }}
          />
        </div>
        <div>
          <Typography
            variant="h6"
            style={{ fontWeight: 600, fontSize: '1rem' }}
          >
            {title}
          </Typography>
        </div>
        {extraComponent}
        {showAddBtn && (
          <div className={classes.menu}>
            {/* <Button
              onClick={() =>
                (selectedTreeItem && disableAddBtn) || totalDisable
                  ? onChange('')
                  : onChange('create')
              }
              className={classes.actionButton}
              startIcon={
                <FontAwesomeIcon
                  icon={faPlus}
                  size="sm"
                  style={
                    (selectedTreeItem && disableAddBtn) || totalDisable
                      ? { opacity: 0.6, cursor: 'not-allowed' }
                      : { cursor: 'pointer' }
                  }
                />
              }
              variant="contained"
              color="primary"
            >
              {en['New']}
            </Button> */}
            {canPublish && (
              <FontAwesomeIcon
                icon={faUpload}
                size="lg"
                onClick={() => onChange('publish')}
                style={{ cursor: 'pointer' }}
              />
            )}
            {canReload && (
              <FontAwesomeIcon
                icon={faUndo}
                size="lg"
                onClick={() => onChange('reload')}
                style={{ cursor: 'pointer' }}
              />
            )}
            {showDeleteBtn && (
              <FontAwesomeIcon
                icon={faTrash}
                size="lg"
                onClick={() => onChange('delete')}
                style={{ cursor: 'pointer' }}
              />
            )}
            {showRefresh && (
              <Button
                onClick={handleRefresh}
                className={classes.actionButton}
                startIcon={
                  <FontAwesomeIcon
                    icon={faUndo}
                    size="sm"
                    spin={spinRefresh}
                    style={{
                      animationDirection: 'alternate-reverse',
                      cursor: 'pointer'
                    }}
                  />
                }
                variant="contained"
                color="primary"
              >
                {en['Reload']}
              </Button>
            )}
          </div>
        )}
        {canImport && (
          <div className={classes.menu}>
            <FontAwesomeIcon
              icon={faFileImport}
              size="lg"
              onClick={() => onChange('import')}
              style={{ cursor: 'pointer' }}
            />
          </div>
        )}
      </div>
      <Divider className={classes.separator} />
      <main
        className={classes.main}
        style={
          pathName.includes('/materials')
            ? { height: 'calc(100vh - 210px)' }
            : {}
        }
      >
        {children}
      </main>
      {pathName.includes('/materials') && (
        <CustomPagination
          userInfo={userInfo}
          handlePagination={
            userInfo?.schemaType === 'sysAdmin' ||
            userInfo?.schemaType === 'superAdmin'
              ? setClassWithoutAuthorVariables
              : setClassVariables
          }
        />
      )}
    </Grid>
  );
};

export default MainPanel;
