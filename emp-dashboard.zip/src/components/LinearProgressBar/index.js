import LinearWithValueLabel from './LinearProgressBar';

export default LinearWithValueLabel;