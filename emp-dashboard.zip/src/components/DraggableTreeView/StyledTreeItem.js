import React, { useEffect } from 'react';
import { Typography, Box } from '@material-ui/core';
import useStyles from './style';
import DescriptionIcon from '@material-ui/icons/Description';
import graphql from '@app/graphql';
import { useMutation } from '@apollo/client';
import {
  faBroadcastTower,
  faSchool,
  faStoreAlt,
  faChalkboardTeacher,
  faFileAlt
} from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { useTreeListContext } from '@app/providers/TreeListContext';
import { getNotificationOpt } from '@app/constants/Notifications';
import { useNotifyContext } from '@app/providers/NotifyContext';

export default function StyledTreeItem(props) {
  const classes = useStyles();
  const {
    labelText,
    labelIcon: LabelIcon,
    selectedTreeItem,
    state,
    isclasses,
    type,
    allData,
    onClick,
    updateGrouping
  } = props;
  const getItemIcon = (value) => {
    if (value === 'station') return faBroadcastTower;
    if (value === 'district') return faSchool;
    if (value === 'school') return faStoreAlt;
    if (value === 'class') return faChalkboardTeacher;
    if (value === 'googleClass') return faChalkboardTeacher;
    if (value === 'googleMaterial') return faFileAlt;
  };
  const { unPublish } = useTreeListContext();
  const { notify } = useNotifyContext();

  const handleUnpublish = async () => {
    await unPublish(allData);
    const notiOps = getNotificationOpt('material', 'success', 'unpublish');
    notify(notiOps.message, notiOps.options);
  };

  const isSelected = () => {
    if (selectedTreeItem && selectedTreeItem._id === allData._id) {
      return true;
    }
    return false;
  };

  // useEffect(() => {
  //   setUpdateGrouping(updateGrouping);
  // }, [updateGrouping]);

  return (
    <div
      onClick={(event) => {
        event.preventDefault();
        onClick(event, allData?._id);
      }}
      id={labelText?.replace(/\s/g, '')}
      className={isSelected() ? classes.labelRootSelected : classes.labelRoot}
    >
      {isclasses ? (
        type !== 'googleMaterial' ? (
          type && (
            <FontAwesomeIcon
              className={classes.labelIcon}
              icon={getItemIcon(type)}
            />
          )
        ) : (
          <DescriptionIcon />
        )
      ) : (
        <LabelIcon color="inherit" className={classes.labelIcon} />
      )}
      <Typography variant="body2" className={classes.labelText}>
        {labelText}
      </Typography>
      {state === 'published' && type === 'material' && (
        <Box
          className={classes.publishstate}
          component={Typography}
          onClick={handleUnpublish}
        >
          Published
        </Box>
      )}
      {state === 'packaged' && (
        <Box className={classes.packagestate} component={Typography}>
          Packaged
        </Box>
      )}
    </div>
  );
}
