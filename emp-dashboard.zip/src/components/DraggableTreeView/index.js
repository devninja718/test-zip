/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react';
import 'react-sortable-tree/style.css';
import FolderIcon from '@material-ui/icons/Folder';
import DescriptionIcon from '@material-ui/icons/Description';
import { getDisplayName } from '@app/utils/functions';
import SortableTree from 'react-sortable-tree';
import FileExplorerTheme from './theme';
import StyledTreeItem from './StyledTreeItem';
import { useTreeListContext } from '@app/providers/TreeListContext';
import { useLazyQuery } from '@apollo/client';
import graphql from '@app/graphql';
import { useUserContext } from '@app/providers/UserContext';

let clicks = [];
let timeout;
const DraggableTreeView = ({
  resources,
  selectedTreeItem,
  onClick,
  rootTitle,
  onChange,
  setSelected,
  expanded,
  classLoadedData,
  stationLoadedData,
  districtLoadedData,
  schoolLoadedData,
  materialLoadedData,
  role,
  loadedclassId,
  searchResults,
  isTopology,
  isResource,
  userInfo,
  updateGrouping
}) => {
  const [expandedKeys, setExpandedKeys] = useState([]);
  const [treeData, setTreeData] = useState();
  const [unpublishClass, setUnpublishClass] = useState();
  const [canDrag, setCanDrag] = useState();
  const [assignedStudentIdList, setAssignedStudentIdList] = useState();
  const { isUpdate, setUpdate, setSelectedNode, changeChildPublishStatus } =
    useTreeListContext();
  const [isChildrenListChecked, setChildrenListChecked] = useState(false);
  const [currentUser] = useUserContext();

  const canDrop = ({
    node,
    prevPath,
    prevParent,
    prevTreeIndex,
    nextPath,
    nextParent,
    nextTreeIndex
  }) => {
    if (node.schemaType === 'class') {
      if (nextParent) {
        return false;
      }
    } else {
      if (
        nextParent &&
        nextParent.childrenIdList &&
        prevParent?.topology?.class === nextParent?.topology?.class
      ) {
        const childNames = nextParent.children?.filter(
          (item) => item.name === node.name
        );
        if (childNames && childNames.length > 1) {
          return false;
        }
        return true;
      } else {
        return false;
      }
    }
    return true;
  };

  const [
    getStudents,
    { loading: studentLoading, data: studentData, error: studentError }
  ] = useLazyQuery(graphql.queries.userGrouping);

  const fetchStudents = async (studentVariables) => {
    if (assignedStudentIdList && assignedStudentIdList.length > 0) {
      await getStudents({
        variables: studentVariables,
        fetchPolicy: 'cache-and-network',
        nextFetchPolicy: 'cache-first'
      });
    }
  };

  const handleSelect = async (event, nodeIds) => {
    event.preventDefault();
    clicks.push(new Date().getTime());
    window.clearTimeout(timeout);
    timeout = window.setTimeout(() => {
      if (
        clicks.length > 1 &&
        clicks[clicks.length - 1] - clicks[clicks.length - 2] < 250
      ) {
        if (clicks.length > 10) {
          clicks = [];
        }
        onChange('rename');
      }
    }, 250);

    let selectedItem = resources?.find((e) => e._id === nodeIds);
    if (!selectedItem)
      selectedItem = stationLoadedData?.find((e) => e._id === nodeIds);
    if (!selectedItem)
      selectedItem = districtLoadedData?.find((e) => e._id === nodeIds);
    if (!selectedItem)
      selectedItem = schoolLoadedData?.find((e) => e._id === nodeIds);
    if (!selectedItem)
      selectedItem = classLoadedData?.find((e) => e._id === nodeIds);
    if (materialLoadedData) {
      if (!selectedItem)
        selectedItem = materialLoadedData?.find((e) => e._id === nodeIds);
    }

    // setSelectedTreeItem(selectedItem);
    if (nodeIds !== 'root') {
      onClick('single', selectedItem);
      // select(selectedItem);
    }
    if (selectedItem?._id) {
      if (expandedKeys.includes(selectedItem._id)) {
        // remove ot not??
      } else {
        setExpandedKeys([...expandedKeys, selectedItem._id]);
      }
    }
  };

  const childrenTreeItems = (list, parentID, nodeIndex) => {
    let data = list.filter((e) => e.parentId === parentID);
    const result = data?.map((el, index) => {
      return {
        key: el._id,
        title: el.name,
        expanded: expandedKeys.includes(el._id),
        children: childrenTreeItems(list, el._id, index + 2),
        ...el
      };
    });
    return result;
  };

  const topologyChildrenTreeItems = (parentID, nodeIndex, parentType) => {
    let data = [];
    if (parentType === 'root') {
      data = stationLoadedData;
    }
    if (parentType === 'station')
      data = districtLoadedData.filter((e) => e.parentId === parentID);
    if (parentType === 'district')
      data = schoolLoadedData.filter((e) => e.parentId === parentID);
    if (parentType === 'school')
      data = classLoadedData.filter((e) => e.parentId === parentID);
    if (materialLoadedData) {
      if (parentType === 'googleClass') {
        data = materialLoadedData.filter((e) => e.parentId === parentID);
      }
    }

    if (parentID === 'resource') {
      const result = resources
        ?.filter((item) => !item?.parentId)
        ?.map((el, index) => ({
          key: el._id,
          title: el.name,
          expanded: expandedKeys.includes(el._id),
          children: childrenTreeItems(resources, el._id, index + 2),
          ...el
        }));
      return result;
    }

    const result = data?.map((el, index) => {
      return {
        key: el._id,
        title: el.name,
        expanded: expandedKeys.includes(el._id),
        children: childrenTreeItems(resources, el._id, index + 2),
        ...el
      };
    });
    return result;
  };

  const isChildren = (data) => {
    return data.find((e) => e.parentId === loadedclassId) ? true : false;
  };

  const getTreeItems = () => {
    if (searchResults) {
      if (searchResults === 'No Results') {
        return { key: 0, title: 'No Results' };
      } else {
        let data = searchResults.map((el, index) => {
          if (searchResults.childrenIdList) {
            return { key: 0, title: 'No Results', ...el };
          } else {
            return {
              key: el._id,
              title: getDisplayName(el.name),
              expanded: expandedKeys.includes(el._id),
              ...el
            };
          }
        });
        return data;
      }
    } else {
      if (role === 'educator') {
        const title = rootTitle ? rootTitle : 'root';
        let children = [];
        if (isChildren) {
          children = childrenTreeItems(resources, loadedclassId, 2);
        }
        let data = {
          key: loadedclassId,
          title,
          expanded: expandedKeys.includes(loadedclassId),
          ...selectedTreeItem,
          children
        };
        return data;
      } else {
        if (isTopology) {
          if (userInfo?.schemaType === 'districtAdmin') {
            const data = districtLoadedData?.map((el, index) => {
              return {
                key: el._id,
                title: el.name,
                expanded: expandedKeys.includes(el._id),
                children: topologyChildrenTreeItems(
                  el._id,
                  index + 2,
                  el.schemaType
                ),
                ...el
              };
            });
            return data;
          } else {
            return {
              key: 'root',
              title: rootTitle ? rootTitle : 'root',
              expanded: expandedKeys.includes('root'),
              children: topologyChildrenTreeItems('root', 'root', 'root'),
              ...selectedTreeItem
            };
          }
        } else {
          if (!isResource && classLoadedData) {
            const data = classLoadedData?.map((el, index) => {
              return {
                key: el._id,
                title: getDisplayName(el.name),
                expanded: expandedKeys.includes(el._id),
                children: childrenTreeItems(resources, el._id, index + 2),
                ...el
              };
            });
            return data;
          } else {
            return {
              key: 'root',
              title: rootTitle ? rootTitle : 'root',
              expanded: expandedKeys.includes('root'),
              children: topologyChildrenTreeItems('resource', 'root', 'root'),
              ...selectedTreeItem
            };
          }
        }
      }
    }
  };

  const updateOrder = async (data) => {
    const { treeData, node, path, nextParentNode } = data;

    const { prevNode: uperNode, nextNode: underNode } = getPrevNextNodes(
      node,
      path,
      treeData
    );
    try {
      const timestamp = new Date().valueOf() / 1000;
      let newRank = node.rank;
      if (uperNode && underNode) {
        if (uperNode.parentId !== underNode.parentId) {
          // moved to top or bottom
          if (underNode.parentId === uperNode._id) {
            //moved top
            if (underNode.rank) {
              newRank = underNode.rank - 300;
            } else {
              newRank = timestamp;
            }
          } else {
            //moved bottom
            if (uperNode.rank) {
              newRank = uperNode.rank + 300;
            } else {
              newRank = timestamp;
            }
          }
        } else {
          // dropped between 2 items
          if (uperNode.rank && underNode.rank)
            newRank = (uperNode.rank + underNode.rank) / 2;
          else {
            if (uperNode.rank) {
              newRank = uperNode.rank + 300;
            } else if (underNode.rank) {
              newRank = underNode.rank - 300;
            } else {
              newRank = node.rank && node.rank !== 0 ? node.rank : timestamp;
            }
          }
        }
      } else {
        if (!uperNode && !underNode) {
          newRank = timestamp;
        } else {
          if (uperNode?.rank) {
            newRank = uperNode.rank + 300; // remove 300 second
          } else if (underNode?.rank) {
            newRank = underNode.rank - 300;
          } else {
            newRank = node.rank && node.rank !== 0 ? node.rank : timestamp;
          }
        }
      }
      const rank = Math.round(newRank);

      let assetUrlVariables;
      if (nextParentNode && node.parentId !== nextParentNode._id) {
        // update parentNode's child list
        const parentVariables = {
          id: nextParentNode._id,
          schemaType: nextParentNode.schemaType,
          version: nextParentNode.version,
          trackingAuthorName: currentUser?.name,
          childrenIdList: nextParentNode.childrenIdList?.includes(node._id)
            ? nextParentNode.childrenIdList
            : [...nextParentNode.childrenIdList, node._id]
        };
        await updateGrouping({
          variables: {
            ...parentVariables
          }
        });

        // update previous parent node's child list
        const parent = getNodeByKey(node.parentId, treeData);
        if (parent) {
          let childIds = parent.childrenIdList?.filter(
            (item) => item !== node._id
          );
          const prevParentVariables = {
            id: parent._id,
            schemaType: parent.schemaType,
            version: parent.version,
            trackingAuthorName: currentUser?.name,
            childrenIdList: childIds
          };
          await updateGrouping({
            variables: {
              ...prevParentVariables
            }
          });
        }

        // update node's parent id and parentIdList
        assetUrlVariables = {
          id: node['_id'],
          schemaType: node.schemaType,
          version: node.version,
          parentIdList:
            nextParentNode.schemaType === 'class'
              ? [nextParentNode._id]
              : [...nextParentNode.parentIdList, nextParentNode._id],
          parentId: nextParentNode._id,
          rank: rank
        };

        if (node.children) {
          for (const child of node.children) {
            let childParentIdList = child.parentIdList?.filter(
              (pid) => pid !== parent._id
            );
            if (!childParentIdList.includes(nextParentNode._id)) {
              childParentIdList.push(nextParentNode._id);
            }
            let variables = {
              id: child._id,
              schemaType: child.schemaType,
              version: child.version,
              trackingAuthorName: currentUser?.name,
              parentIdList: [...assetUrlVariables.parentIdList, node._id]
            };
            await updateGrouping({ variables });
          }
        }

        // check publish status for nextParent node
        if (
          nextParentNode.schemaType === 'material' &&
          nextParentNode.status === 'published' &&
          node.status !== 'published'
        ) {
          changeChildPublishStatus(node, 'published');
        }
      } else {
        assetUrlVariables = {
          id: node['_id'],
          schemaType: node.schemaType,
          version: node.version,
          trackingAuthorName: currentUser?.name,
          rank: rank
        };
      }
      const result = await updateGrouping({
        variables: {
          ...assetUrlVariables
        }
      });
    } catch (err) {
      console.log('update rank error: ', err);
    }
  };

  const getPrevNextNodes = (node, path, tree) => {
    let prevNode = null;
    let nextNode = null;
    if (path.length === 1) {
      // moved classes
      tree.forEach((element, index) => {
        if (element.key === node.key) {
          if (index !== 0) {
            prevNode = tree[index - 1];
          }
          if (index !== tree.length - 1) {
            nextNode = tree[index + 1];
          }
        }
      });
    } else {
      // moved 1 level child
      let parentNode = tree.find((item) => item.key === path[0]);
      if (parentNode)
        parentNode.children?.forEach((element, index) => {
          if (element.key === node.key) {
            if (index !== 0) {
              prevNode = parentNode.children[index - 1];
            }
            if (index !== parentNode.children.length - 1) {
              nextNode = parentNode.children[index + 1];
            }
          }
          if (element.children) {
            // move 2 level child
            element.children.forEach((childElement, index) => {
              if (childElement.key === node.key) {
                if (index !== 0) {
                  prevNode = element.children[index - 1];
                }
                if (index !== element.children.length - 1) {
                  nextNode = element.children[index + 1];
                }
              }
              if (childElement.children) {
                // move 3 level child
                childElement.children.forEach((childChildElement, index) => {
                  if (childChildElement.key === node.key) {
                    if (index !== 0) {
                      prevNode = childElement.children[index - 1];
                    }
                    if (index !== childElement.children.length - 1) {
                      nextNode = childElement.children[index + 1];
                    }
                  }
                });
              }
            });
          }
        });
    }
    return { prevNode, nextNode };
  };

  const getNodeByKey = (key, tree) => {
    if (tree == null || tree.length === 0) return;
    for (const item of tree) {
      if (item._id === key) {
        return item;
      }
      if (item.children) {
        for (const subItem of item.children) {
          if (subItem._id === key) {
            return subItem;
          }
          if (subItem.children) {
            for (const subSubItem of subItem.children) {
              if (subSubItem._id === key) {
                return subSubItem;
              }
              for (const lastSubItem of subSubItem.children) {
                if (lastSubItem._id === key) {
                  return lastSubItem;
                }
              }
            }
          }
        }
      }
    }
  };

  const handleItemChangeStatus = async (type, value) => {
    if (type === 'unpublished') {
      // updateClassStatus(value);
    }
  };

  const updateClassStatus = async (value) => {
    let selectedClass = classLoadedData.filter(
      (el) => el._id === value.topology?.class
    );
    if (selectedClass) {
      let childMaterials = resources.filter(
        (el) =>
          selectedClass[0]?.childrenIdList?.includes(el._id) &&
          el._id !== value._id &&
          el.status === 'published'
      );

      if (childMaterials && childMaterials.length > 0) {
        if (selectedClass[0]?.status !== 'published') {
          let varaibleData = {
            id: selectedClass[0]['_id'],
            schemaType: selectedClass[0].schemaType,
            version: selectedClass[0].version,
            trackingAuthorName: currentUser?.name,
            status: 'published'
          };
          await updateGrouping({
            variables: varaibleData
          });
        }
      } else {
        if (selectedClass[0]?.status !== 'unpublished') {
          setUnpublishClass(selectedClass[0]);
          let varaibleData = {
            id: selectedClass[0]['_id'],
            schemaType: selectedClass[0].schemaType,
            assigneeIdList: [],
            version: selectedClass[0].version,
            trackingAuthorName: currentUser?.name,
            status: 'unpublished'
          };
          await updateGrouping({
            variables: varaibleData
          });

          if (
            selectedClass[0]?.assigneeIdList &&
            selectedClass[0]?.assigneeIdList.length > 0
          ) {
            updateAssignedStudents(selectedClass[0]?.assigneeIdList);
          }
        }
      }
    }
  };

  const updateAssignedStudents = async (studentIds) => {
    setAssignedStudentIdList(studentIds);
    let variable = {
      parentId: unpublishClass?.topology?.district,
      schemaType: 'student'
    };
    fetchStudents(variable);
  };

  useEffect(() => {
    if (
      !studentLoading &&
      !studentError &&
      studentData &&
      assignedStudentIdList?.length > 0
    ) {
      let data = studentData.grouping.filter((el) =>
        assignedStudentIdList.includes(el._id)
      );
      if (data && data.length > 0) {
        updateStudentInfo(data);
      }
    }
  }, [studentLoading, studentError, studentData]);

  const updateStudentInfo = async (studentData) => {
    for (const ml of studentData) {
      let childrenIdList = ml.childrenIdList?.filter(
        (el) => el !== unpublishClass._id
      );
      await updateGrouping({
        variables: {
          id: ml['_id'],
          schemaType: 'student',
          childrenIdList: childrenIdList,
          version: ml.version,
          trackingAuthorName: currentUser?.name,
          status:
            childrenIdList && childrenIdList.length > 0
              ? 'published'
              : 'unpublished'
        }
      });
    }
    setAssignedStudentIdList();
  };

  const checkTreeNode = async (node) => {
    if (node.childrenIdList == null) return;
    if (node.schemaType === 'class') {
    }
    if (node.children?.length !== node.childrenIdList?.length) {
      let realChildrenIds = node.children?.map((item) => item._id);

      const parentVariables = {
        id: node._id,
        schemaType: node.schemaType,
        version: node.version,
        trackingAuthorName: currentUser?.name,
        childrenIdList: realChildrenIds
      };
      if (node.schemaType === 'class') {
      }
      await updateGrouping({
        variables: {
          ...parentVariables
        }
      });
    } else {
      if (node.schemaType === 'class') {
        console.log('class Not Update ');
      }
    }
    if (node.children?.length) {
      node.children.forEach((element) => {
        checkTreeNode(element);
      });
    }
  };

  const updateChildrenInfo = (treeList) => {
    treeList.forEach((element) => {
      checkTreeNode(element);
    });
  };

  useEffect(() => {
    const data = getTreeItems();
    setTreeData(data);
  }, [
    classLoadedData,
    resources,
    stationLoadedData,
    districtLoadedData,
    materialLoadedData,
    schoolLoadedData,
    expandedKeys
  ]);

  // useEffect(() => {
  //   if (treeData?.length && !isChildrenListChecked) {
  //     updateChildrenInfo(treeData);
  //     setChildrenListChecked(true);
  //   }
  // }, [treeData]);

  useEffect(() => {
    if (selectedTreeItem != null) {
      const expands = selectedTreeItem?.parentIdList
        ? [...selectedTreeItem.parentIdList, selectedTreeItem._id]
        : [selectedTreeItem._id, selectedTreeItem.parentId];
      setExpandedKeys(expands);
    }
  }, []);

  useEffect(() => {
    if (isUpdate) {
      const data = getTreeItems();
      setTreeData(data);
      setUpdate(false);
    }
  }, [isUpdate]);

  useEffect(() => {
    if (selectedTreeItem?.schemaType === 'class') {
      setCanDrag(false);
    } else {
      setCanDrag(true);
    }
  }, [selectedTreeItem]);

  useEffect(() => {
    if (expanded) {
      if (!expandedKeys.includes(expanded)) {
        setExpandedKeys([...expandedKeys, expanded]);
      }
    }
  }, [expanded]);

  useEffect(() => {
    if (selectedTreeItem?._id && treeData) {
      const node = getNodeByKey(selectedTreeItem?._id, treeData);
      setSelectedNode(node);
    }
  }, [selectedTreeItem]);

  return (
    <div className="draggable-container">
      {treeData && (
        <SortableTree
          treeData={treeData}
          onChange={(newTree) => {
            setTreeData(newTree);
          }}
          isVirtualized={false}
          generateNodeProps={({ node, path }) => ({
            title: (
              <StyledTreeItem
                key={node?._id}
                nodeId={node?._id}
                labelText={`${
                  node?.schemaType === 'class'
                    ? node?.source?.classSource?.name
                      ? `${node?.source?.classSource?.name} - `
                      : ''
                    : ''
                }${getDisplayName(node?.name)}`}
                labelIcon={
                  node?.schemaType === 'material' && !node?.childrenIdList
                    ? DescriptionIcon
                    : FolderIcon
                }
                type={node?.schemaType}
                state={node?.status}
                allData={node}
                isChildren={node?.childrenIdList?.length > 0 ? true : false}
                onClick={(event, id) => {
                  handleSelect(event, id);
                  // select(node);
                }}
                onChange={handleItemChangeStatus}
                isclasses={node.schemaType === 'class'}
                selectedTreeItem={selectedTreeItem}
                updateGrouping={updateGrouping}
              />
            )
          })}
          theme={FileExplorerTheme}
          onDragStateChanged={(data) => {
            // console.log(data);
          }}
          onMoveNode={(data) => {
            updateOrder(data);
          }}
          maxDepth={4}
          getNodeKey={(node) => node.node?._id}
          onVisibilityToggle={({ treeData, node, expanded, path }) => {
            if (expanded) {
              setExpandedKeys([...expandedKeys, node._id]);
            } else {
              var filtered = expandedKeys.filter((val) => val !== node._id);
              setExpandedKeys(filtered);
            }
          }}
          canDrop={canDrop}
          canDrag={canDrag}
        />
      )}
    </div>
  );
};

export { DraggableTreeView as default };
