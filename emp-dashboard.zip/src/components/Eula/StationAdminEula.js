import React, { useState, useEffect, useRef } from 'react';
import html2canvas from 'html2canvas';
import { Auth } from 'aws-amplify';
import graphql from '@app/graphql';
import { useMutation } from '@apollo/client';
import { useHistory } from 'react-router-dom';
import { useUserContext } from '@app/providers/UserContext';
import { getCurrentUTCTime } from '@app/utils/date-manager';
import { jsPDF } from 'jspdf';
import { getConfigParams } from '@app/utils/functions';
import axios from 'axios';
import MyPDF from './eula_agree.pdf';

import {
  Paper,
  Box,
  CardContent,
  Button,
  Typography,
  Link
} from '@material-ui/core';
import './style.css';

const StationAdminEula = ({ fromSetting, onChange }) => {
  const history = useHistory();
  const [updateGrouping] = useMutation(graphql.mutations.updateGrouping);
  const targetRef = useRef();
  const [agreementDocUrl, setAgreementDocUrl] = useState();
  const [currentUser, setCurrentUser, status, setStatus] = useUserContext();
  const [definedFileLink, setDefinedFileLink] = useState(false);

  const fileName = 'Educator EULA with Content License Agreement.7.29.2021.pdf';

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(async () => {
    let parames = await getConfigParams();
    let docLink =
      'https://s3.us-east-2.amazonaws.com/' +
      parames.assetBucketName +
      '/config/' +
      fileName;
    axios
      .get(docLink)
      .then((response) => {
        setDefinedFileLink(true);
        setAgreementDocUrl(docLink);
      })
      .catch((error) => {
        setDefinedFileLink(false);
      });
  }, []);

  const onSignOut = async () => {
    console.log('$53');
    await Auth.signOut();
    window.localStorage.clear();
    history.push('/');
  };

  const onAgree = async () => {
    if (currentUser) {
      const timestamp = getCurrentUTCTime();
      const result = await updateGrouping({
        variables: {
          id: currentUser?._id,
          schemaType: currentUser?.schemaType,
          version: currentUser?.version,
          trackingAuthorName: currentUser?.name,
          status: 'active',
          loginInfo: {
            EULAsignedAt: timestamp,
            lastSeenAt: currentUser?.loginInfo?.lastSeenAt
              ? currentUser?.loginInfo?.lastSeenAt
              : timestamp,
            count: currentUser?.loginInfo?.count
          }
        }
      });
      if (result) {
        window.location.reload();
      }
    }
  };

  const onDownloadEula = async () => {
    var HTML_Width = document.getElementById('eulaDoc').offsetWidth;
    var HTML_Height = document.getElementById('eulaDoc').offsetHeight;
    var top_left_margin = 15;
    var PDF_Width = HTML_Width + top_left_margin * 2;
    var PDF_Height = PDF_Width * 1.4 + top_left_margin * 2;
    var canvas_image_width = HTML_Width;
    var canvas_image_height = HTML_Height;

    var totalPDFPages = Math.ceil(HTML_Height / (PDF_Width * 1.4)) - 1;

    html2canvas(document.getElementById('eulaDoc'), { allowTaint: true }).then(
      function (canvas) {
        canvas.getContext('2d');

        console.log(canvas.height + '  ' + canvas.width);

        var imgData = canvas.toDataURL('image/jpeg', 1.0);
        var pdf = new jsPDF('p', 'pt', [PDF_Width, PDF_Height]);
        pdf.addImage(
          imgData,
          'JPG',
          top_left_margin,
          top_left_margin,
          canvas_image_width,
          canvas_image_height
        );

        for (var i = 1; i <= totalPDFPages; i++) {
          pdf.addPage();
          pdf.addImage(
            imgData,
            'JPG',
            top_left_margin,
            -(PDF_Height * i) + top_left_margin * 4,
            canvas_image_width,
            canvas_image_height
          );
        }

        pdf.save('test.pdf');
      }
    );
  };

  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        width: '100%',
        height: 'flex'
      }}
    >
      <Paper
        style={{
          maxHeight: '85vh',
          width: '55%',
          overflowY: 'scroll',
          overflowX: 'hidden',
          marginTop: 30,
          paddingRight: 70,
          paddingLeft: 70,
          marginBottom: 30
        }}
      >
        <CardContent id="eulaDoc" ref={targetRef}>
          <Typography variant="h5" style={{ textAlign: 'center' }}>
            <Box fontWeight="fontWeightBold">
              END USER LICENSE AGREEMENT (EULA)
            </Box>
          </Typography>
          <Typography variant="body1" style={{ marginTop: 20 }}>
            <Box fontWeight="fontWeightBold" style={{ textIndent: '18px' }}>
              This End User License Agreement (“EULA” or "Agreement") is a
              binding legal contract between you as an end user of WITF, Inc.
              (“Licensee” or “Sub-Licensor”), who is an authorized distributor
              of SIG Digital Infrastructure LLC, a Delaware limited liability
              company, with its principal place of business at 2805 Wilderness
              Place, Suite 100, Boulder, CO 80301 (“Licensor”) in accordance
              with the Master License, Support and Services Agreement (“Master
              Agreement”) executed between Licensee and Licensor on January 19,
              2021. By installing, accessing or using the software and any
              associated user manuals and other documentation provided by
              Licensor (“Documentation”) and Enhancements (as defined below)
              provided with this Agreement (collectively, the “Software” or
              “Licensed Software”) you as an end user (you or “User”) will be
              bound by the terms of this Agreement and any and all exhibits
              hereto. If you do not agree to the terms of this Agreement,
              Licensor is not willing to license any right to use or access the
              Software to you in accordance with the Master Agreement. In such
              event, you may not install, access, use or copy the Software.
            </Box>
          </Typography>
          <Typography variant="subtitle1" style={{ marginTop: 30 }}>
            <Box fontWeight="fontWeightBold">
              SOFTWARE ACCESS AND USE LICENSE
            </Box>
          </Typography>

          <Typography variant="body1" style={{ marginTop: 20 }}>
            <Box>
              The Software is being licensed, and not sold, to you by Licensee
              as a Sub-licensor of Licensor’s Software under and in accordance
              with their Master Agreement. Except for the limited license
              granted in this Agreement, Licensor and Sub-Licensor retain all
              their respective right, title and interest in the Software, all
              copies thereof, and all proprietary rights in the Software,
              including copyrights, patents, trademarks and trade secret rights.
            </Box>
          </Typography>

          <Typography
            variant="subtitle1"
            style={{ marginTop: 20, marginRight: 0 }}
          >
            <ol>
              <li>
                <strong>GRANT OF LICENSE.</strong> This Agreement grants you the
                following rights, as applicable:
                <br />
                <ol>
                  <li>
                    {' '}
                    <strong> License.</strong> Subject to and in accordance with
                    the Master Agreement between Licensor and&nbsp;Licensee, you
                    are hereby granted a nonexclusive, nontransferable,
                    revocable (as&nbsp;permitted herein) right and license to
                    access and use the Software which will be hosted&nbsp;by
                    Licensor during the term of the Agreement.
                  </li>
                  <li>
                    {' '}
                    <strong>Enhancements.</strong> Licensor reserves the right
                    to upgrade, enhance, change or modify the&nbsp;Software at
                    any time in its sole discretion
                    (&ldquo;Enhancements&rdquo;). Any Enhancements
                    made&nbsp;available to you by Licensor, if any, will be
                    subject to the terms of this Agreement.
                  </li>
                  <li>
                    {' '}
                    <strong>Third Party Components.</strong> The Software and
                    future Enhancements may contain certain&nbsp;third party
                    components (&ldquo;Third Party Components&rdquo;) which are
                    provided to you under&nbsp;terms and conditions which are
                    different from this Agreement, or which require
                    Licensor&nbsp;to provide you with certain notices and/or
                    information. Your use of each Third Party&nbsp;Component
                    which contains or is accompanied by its own license
                    agreement will be&nbsp;subject to the terms and conditions
                    of such other license agreement, and not
                    this&nbsp;Agreement. Notwithstanding the foregoing, the
                    following terms and conditions apply to&nbsp;all
                    &ldquo;Third Party Components&rdquo;: (i) all Third Party
                    Components are provided on an &ldquo;AS IS&rdquo; basis;
                    (ii) Licensor will not be liable to you or indemnify you for
                    any claims related to the Third Party Components; and (iii)
                    Licensor will not be liable for any direct,
                    indirect,&nbsp;incidental, special, exemplary, punitive or
                    consequential damages with respect to the Third Party
                    Components. Your sole and exclusive remedy with regard to
                    any defect,&nbsp;claim, or other dispute relating to the
                    Third Party Components is to cease use of
                    such&nbsp;components.
                  </li>
                  <li>
                    {' '}
                    <strong>
                      License to Licensor to Use User Information.
                    </strong>{' '}
                    You hereby grant a license to Licensor to&nbsp;use your
                    information (&ldquo;User Information&rdquo;) in connection
                    with your access and use of the&nbsp;Software. Licensor may
                    de-identify User Information such that it is no longer
                    considered&nbsp;personally identifiable information or
                    otherwise no longer identifies you as a User.&nbsp;Licensor
                    may further aggregate and use such de-identified User
                    Information for providing&nbsp;functionality, content and
                    other information to you and other users of the
                    Software.&nbsp;Licensor may use de-identified User
                    Information, alone or in the aggregate with
                    other&nbsp;users&rsquo; de-identified User Information, to
                    support, maintain and improve the operation&nbsp;and
                    performance of the Software to the extent permitted under
                    the Master Agreement.&nbsp;Some areas of the Software allow
                    Users to submit, post, display, provide, or
                    otherwise&nbsp;make available content such as profile
                    information, videos, images, music,
                    comments,&nbsp;questions, and other content or information
                    (any such materials a User submits, posts,&nbsp;displays,
                    provides, or otherwise makes available on the Service is
                    referred to as &ldquo;User&nbsp;Content&rdquo;). You hereby
                    agree that our use of such User Content shall be governed by
                    the&nbsp;terms set forth on Exhibit A (Content License
                    Agreement).
                  </li>
                  <li>
                    {' '}
                    <strong>Intellectual Property Ownership.</strong> The
                    Software contains material that is protected by&nbsp;United
                    States copyright and trade secret law, and by international
                    treaty provisions. All&nbsp;rights not expressly granted to
                    Licensee under this Agreement are expressly reserved
                    by&nbsp;Licensor and its licensors. You shall not modify,
                    remove or destroy any proprietary&nbsp;markings or
                    confidential legends placed upon or contained within the
                    Software, the&nbsp;Documentation, or any related materials.
                    All copyrights, patents, trade secrets,&nbsp;trademarks,
                    service marks, trade names, moral rights and other
                    intellectual property and&nbsp;proprietary rights in the
                    Software shall remain the sole and exclusive property of
                    Licensor&nbsp;or its licensors, as applicable.
                  </li>
                  <li>
                    {' '}
                    <strong>Beta Software.</strong> Licensor may designate
                    certain Enhancements or new releases of the&nbsp;Software as{' '}
                    <strong>&ldquo;Beta Software.&rdquo;</strong>
                    Such Beta Software will not be ready for use in a
                    production&nbsp;environment. At this early stage of
                    development, operation of the Beta Software may be&nbsp;
                    unpredictable and lead to erroneous results. You acknowledge
                    and agree that: (i) the&nbsp;Beta Software is experimental
                    and has not been fully tested; (ii) the Beta Software
                    may&nbsp;not meet your requirements; (iii) the use or
                    operation of the Beta Software may not be&nbsp;uninterrupted
                    or error free; (iv) your use of the Beta Software is for
                    purposes of&nbsp;evaluating and testing the product and
                    providing feedback to Licensor; (v) you shall&nbsp;inform
                    your employees, staff members, and other users regarding the
                    nature of the Beta&nbsp;Software; and (vi) you will hold all
                    information relating to the Beta Software and your
                    use&nbsp;of the Beta Software, including any performance
                    measurements and other data relating&nbsp;to the Beta
                    Software, in strict confidence and shall not disclose such
                    information to any&nbsp;unauthorized third parties. Your use
                    of the Beta Software shall be subject to all of
                    the&nbsp;terms and conditions set forth herein relating to
                    the Software. You shall promptly report&nbsp;any errors,
                    defects, or other deficiencies in the Beta Software to
                    Licensor.&nbsp;NOTWITHSTANDING ANY OTHER PROVISION OF THIS
                    AGREEMENT, ALL BETA SOFTWARE IS PROVIDED &ldquo;
                    AS-IS&rdquo; AND &ldquo;AS-AVAILABLE,&rdquo; WITHOUT
                    WARRANTIES OF ANY KIND. You&nbsp;hereby waive any and all
                    claims, now known or later discovered, that you may
                    have&nbsp;against Licensor and its suppliers/licensors
                    arising out of your use of the Beta Software.
                  </li>
                  <li>
                    {' '}
                    <strong>TERM.</strong> The license will commence on the date
                    you first use the Software or accept this Agreement,
                    whichever is earlier (the &ldquo;Effective Date&rdquo;), and
                    shall remain in effect until the termination of this license
                    in accordance with Section 7 hereunder.
                  </li>
                </ol>
              </li>
              <br />
              <li>
                <strong>LIMITATIONS ON LICENSE.</strong> Subject to the
                Licensor&rsquo;s agreement with the Licensee, the&nbsp;license
                granted to you in this Agreement is restricted at least as
                follows:
                <ol>
                  <li>
                    <strong>Limitations on Copying and Distribution.</strong>{' '}
                    You may not copy or distribute or make&nbsp;derivative works
                    of the Software except to the extent that copying is
                    necessary to use the&nbsp;Software for purposes set forth
                    herein. You may make a single copy of the Software
                    for&nbsp;backup and archival purposes.
                  </li>
                  <li>
                    <p>
                      <strong>
                        Limitations on Reverse Engineering and Modification.
                      </strong>{' '}
                      You may not reverse engineer,&nbsp;decompile, disassemble,
                      modify or create works derivative of the Software. You may
                      not&nbsp;alter or modify any disabling mechanism which may
                      be resident in the Software.
                    </p>
                  </li>
                  <li>
                    <p>
                      <strong>Sublicense, Rental, and Third Party Use.</strong>{' '}
                      Unless and to the extent You are an
                      authorized&nbsp;reseller of the Software, You may not
                      assign, sublicense, rent, timeshare, loan, lease
                      or&nbsp;otherwise transfer the Software, or directly or
                      indirectly permit any third party to use or&nbsp;copy the
                      Software.
                    </p>
                  </li>
                  <li>
                    <p>
                      <strong>Bypass Security.</strong> You may not bypass or
                      breach any security device or protection used by&nbsp;the
                      Software or access or use the Software other than through
                      the use of your own then&nbsp;valid access credentials to
                      the Software.
                    </p>
                  </li>
                  <li>
                    <p>
                      <strong>No Unlawful or Injurious Information.</strong> You
                      may not input, upload, transmit, or otherwise&nbsp;provide
                      to or through the Software, any information or materials
                      that are unlawful or&nbsp;injurious, or contain, transmit,
                      or activate any code that would harm or impede in
                      any&nbsp;way the function, security, integrity, operation
                      of the Software and any data stored, used&nbsp;or accessed
                      by the Software, including any devices on which the
                      Software operates.
                    </p>
                  </li>
                  <li>
                    <p>
                      <strong>Proprietary Notices.</strong> You may not remove
                      any proprietary notices (e.g., copyright
                      and&nbsp;trademark notices) from the Software. You must
                      reproduce the copyright and all other&nbsp;proprietary
                      notices displayed on the Software on each permitted
                      back-up or archival copy.
                    </p>
                  </li>
                  <li>
                    <p>
                      <strong>Use in Accordance with Documentation.</strong> All
                      use of the Software shall be in accordance with its then
                      current Documentation.
                    </p>
                  </li>
                  <li>
                    <p>
                      <strong>Compliance with Applicable Law.</strong> You shall
                      be solely responsible for ensuring that your&nbsp;use of
                      the Software, including but not limited to any data,
                      information or materials you&nbsp;may input upload,
                      transmit, or otherwise provide to the Software, is in
                      compliance with all applicable foreign, federal, state and
                      local laws, and rules and regulations.&nbsp;
                    </p>
                  </li>
                  <li>
                    <p>
                      <strong>Confidentiality.</strong> You acknowledge and
                      agree the Software and associated Documentation constitute
                      valuable proprietary and confidential information and
                      intellectual property (collectively, the
                      &ldquo;Proprietary Information&rdquo;) of Licensor. You
                      may not use or disclose the&nbsp;Proprietary Information
                      without Licensor&rsquo;s prior written consent. You agree
                      to use at&nbsp;least the same degree of care in protecting
                      the Proprietary Information as you use to protect your own
                      similar information, but in no event less than reasonable
                      care. You&nbsp;acknowledge that due to the unique nature
                      of the Proprietary Information, Licensor will not have an
                      adequate remedy in money or damages in the event of any
                      unauthorized use&nbsp;or disclosure of its Proprietary
                      Information. In addition to any other remedies that
                      may&nbsp;be available in law, in equity or otherwise,
                      Licensor shall be entitled to obtain
                      injunctive&nbsp;relief to prevent such unauthorized use or
                      disclosure. You shall not use any information&nbsp;or data
                      disclosed by Licensor in connection with this Agreement to
                      contest the validity of&nbsp;any Licensor intellectual
                      property. Any such use of Licensor&rsquo;s information and
                      data shall&nbsp;constitute a material, non-curable breach
                      of this Agreement.
                    </p>
                  </li>
                </ol>
              </li>
              <li>
                <strong>DMCA NOTICE.</strong> Since Licensor respects artist and
                content owner rights, it is Licensor&rsquo;spolicy to respond to
                alleged infringement notices that comply with the Digital
                Millennium Copyright Act of 1998 (&ldquo;DMCA&rdquo;). If you
                believe that your copyrighted work has been copied in a way that
                constitutes copyright infringement and is accessible via the
                Service, please notify Licensor&rsquo;s copyright agent as set
                forth in the DMCA. For your complaint to be valid under the
                DMCA, you must provide the following information in writing:
                <ol>
                  <li>
                    An electronic or physical signature of a person authorized
                    to act on behalf of the copyright owner;
                  </li>
                  <li>
                    Identification of the copyrighted work that you claim has
                    been infringed;
                  </li>
                  <li>
                    Identification of the material that is claimed to be
                    infringing and where it is located on the Service;
                  </li>
                  <li>
                    Information reasonably sufficient to permit Licensor to
                    contact you, such as your address, telephone number, and,
                    e-mail address;
                  </li>
                  <li>
                    {' '}
                    A statement that you have a good faith belief that use of
                    the material in the manner complained of is not authorized
                    by the copyright owner, its agent, or law;
                  </li>
                  <li>
                    <p>
                      A statement, made under penalty of perjury, that the above
                      information is accurate,&nbsp;and that you are the
                      copyright owner or are authorized to act on behalf of the
                      owner.&nbsp;The above information must be submitted to the
                      following DMCA Agent:
                      <br />
                      &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Attn: DMCA Notice
                      <br />
                      &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; PMEP, LLC
                      <br />
                      &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Address:&nbsp;PPL
                      Public Media Center&nbsp; 839 Sesame Street,
                      <br />
                      &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Bethlehem, PA 18015
                      <br />
                      &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Tel: 610.867.4677
                      <br />
                      &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Email: dmca@pmep.org
                      <br />
                      UNDER FEDERAL LAW, IF YOU KNOWINGLY MISREPRESENT THAT
                      ONLINE MATERIAL IS&nbsp;INFRINGING, YOU MAY BE SUBJECT TO
                      CRIMINAL PROSECUTION FOR PERJURY AND&nbsp;CIVIL PENALTIES,
                      INCLUDING MONETARY DAMAGES, COURT COSTS, AND
                      ATTORNEYS&rsquo;&nbsp;FEES. Please note that this
                      procedure is exclusively for notifying Licensor and
                      its&nbsp;affiliates that your copyrighted material has
                      been infringed. The preceding requirements&nbsp;are
                      intended to comply with Licensor&rsquo;s rights and
                      obligations under the DMCA, including&nbsp;17 U.S.C.
                      &sect;512(c), but do not constitute legal advice. It may
                      be advisable to contact an&nbsp;attorney regarding your
                      rights and obligations under the DMCA and other
                      applicable&nbsp;laws. In accordance with the DMCA and
                      other applicable law, we have adopted a policy&nbsp;of
                      terminating, in appropriate circumstances, Users who are
                      deemed to be repeat&nbsp;infringers. Licensor may also at
                      its sole discretion limit access to the Service
                      and/or&nbsp;terminate the User Accounts of any Users who
                      infringe any intellectual property rights&nbsp;of others,
                      whether or not there is any repeat infringement.
                    </p>
                  </li>
                </ol>
              </li>
              <li>
                <strong>LIMITED WARRANTIES AND MAINTENANCE</strong>
                <ol>
                  <li>
                    <strong>Software.</strong> Unless a warranty is otherwise
                    specifically provided in writing to you by&nbsp;Licensor or
                    Licensee, the Software and Documentation IS PROVIDED
                    &ldquo;AS-IS&rdquo; AND &ldquo;AS-AVAILABLE,&rdquo; WITHOUT
                    WARRANTIES OF ANY KIND.
                  </li>
                  <li>
                    <strong>MAINTENANCE SERVICES.</strong> During the period for
                    which the Licensor may provide&nbsp;maintenance services, if
                    any, for the Software, Licensor will provide you with
                    any&nbsp;enhancements that Licensor may distribute from time
                    to time. If your agreement with&nbsp;Licensee so provides,
                    you may have access to telephone support to assist you in
                    resolving&nbsp;problems encountered in the use of the
                    Software, which are attributable to the
                    Software,&nbsp;during such hours and via contact information
                    that would be made available to you by&nbsp;Licensee.
                  </li>
                </ol>
              </li>
              <br />
              <li>
                <strong>TERMINATION.</strong>
                <ol>
                  <li>
                    <strong>Breach of Agreement.</strong> Without prejudice to
                    any other rights, Licensor may terminate this Agreement on
                    thirty (30) days prior written notice if you fail to comply
                    with any of the terms and conditions of this Agreement and
                    fail to cure the failure within the foregoing&nbsp;period,
                    provided that Licensor shall be entitled to immediately
                    terminate this Agreement without notice in the event you
                    breach the license terms and restrictions set forth
                    in&nbsp;Section 1 or Section 2, or the confidentiality
                    obligations under this Agreement
                  </li>
                  <li>
                    <strong>Termination for Convenience.</strong> You may
                    terminate this Agreement at any time by discontinuing use of
                    the Software and complying with your termination obligations
                    set&nbsp;forth below in Section 5.4.
                  </li>
                  <li>
                    <strong>Termination via Master Agreement.</strong> This
                    Agreement will terminate any time and at the time Licensees
                    Master Agreement with Licensor is terminated.
                  </li>
                  <li>
                    <strong>Licensee&rsquo;s Termination Obligations.</strong>{' '}
                    In the event of any expiration or termination of this
                    Agreement for any reason, you must remove all copies of the
                    Software and all of its&nbsp;components from all of your
                    systems, and destroy all related media and Documentation, if
                    any. The license granted to the Software will automatically
                    terminate on expiration or termination of this Agreement.
                  </li>
                </ol>
              </li>
              <br />
              <li>
                <strong>LIMITATION OF LIABILITY.</strong> TO THE MAXIMUM EXTENT
                PERMITTED BY LAW, IN NO EVENT SHALL LICENSOR OR ITS SUPPLIERS BE
                LIABLE TO YOU OR ANY THIRD PARTY FOR ANY SPECIAL, INCIDENTAL,
                CONSEQUENTIAL, PUNITIVE, INDIRECT DAMAGES, OR ANY OTHER DAMAGES,
                WHICH SHALL INCLUDE, WITHOUT LIMITATION, DAMAGES FOR PERSONAL
                INJURY, LOST PROFITS, LOST DATA AND BUSINESS INTERRUPTION,
                ARISING OUT OF THE USE OR INABILITY TO USE THE SOFTWARE, EVEN IF
                LICENSOR HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES
                (WHETHER SUCH DAMAGES ARISE IN CONTRACT, TORT (INCLUDING
                NEGLIGENCE), OR OTHERWISE). IN ANY CASE, THE ENTIRE LIABILITY OF
                LICENSOR AND ITS SUPPLIERS UNDER THIS AGREEMENT FOR ALL DAMAGES
                OF EVERY KIND AND TYPE (WHETHER SUCH DAMAGES ARISE IN CONTRACT,
                TORT (INCLUDING NEGLIGENCE), OR OTHERWISE) SHALL BE LIMITED TO
                THE INITIAL LICENSE FEE PAID BY YOU, IF ANY, FOR THE SOFTWARE.
              </li>
              <br />
              <li>
                <strong>GOVERNING LAW.</strong> This Agreement is governed by
                and construed in accordance with the laws of the State of New
                York as applied to agreements entered into and wholly performed
                within the State of New York between New York residents. Any
                action or proceeding brought by either party hereto shall be
                brought only in a state or federal court of competent
                jurisdiction located in the Borough of Manhattan, and the
                parties submit to the in personam jurisdiction of such courts
                for purposes of any action or proceeding.GOVERNING LAW. This
                Agreement is governed by and construed in accordance with the
                laws of the State of New York as applied to agreements entered
                into and wholly performed within the State of New York between
                New York residents. Any action or proceeding brought by either
                party hereto shall be brought only in a state or federal court
                of competent jurisdiction located in the Borough of Manhattan,
                and the parties submit to the in personam jurisdiction of such
                courts for purposes of any action or proceeding.
              </li>
              <br />
              <li>
                <strong>GENERAL.</strong>
                <ol>
                  <li>
                    This Agreement constitutes the entire understanding and
                    agreement between Licensor and you with respect to the
                    transactions contemplated in this Agreement and supersedes
                    all prior or contemporaneous oral or written communications
                    with respect to the subject matter of this Agreement, all of
                    which are merged in this Agreement.
                  </li>
                  <li>
                    This Agreement shall not be modified, amended or in any way
                    altered except by an instrument in writing signed by
                    authorized representatives of both parties.
                  </li>
                  <li>
                    In the event that any provision of this Agreement is found
                    invalid or unenforceable pursuant to judicial decree, the
                    remainder of this Agreement shall remain valid and
                    enforceable according to its terms. Any failure by Licensor
                    to strictly enforce any provision of this Agreement will not
                    operate as a waiver of that provision or any subsequent
                    breach of that provision.
                  </li>
                  <li>This Agreement is not assignable by you.</li>
                  <li>
                    The following provisions shall survive any termination or
                    expiration of this Agreement: Sections 2 (Limitations on
                    License), 5 (Termination), 6 (Limitation of Liability) and 8
                    (General).
                  </li>
                  <li>
                    <strong>AUTHORIZATION.</strong> By downloading, installing,
                    accessing, or using the Software, you indicate that you have
                    the authority to bind yourself and your organization to the
                    terms of this Agreement.
                  </li>
                </ol>
              </li>
            </ol>
          </Typography>
          <br />
          <br />
          <Typography variant="h5" style={{ textAlign: 'center' }}>
            <Link fontWeight="fontWeightBold" underline="always" color="black">
              EXHIBIT A
            </Link>
          </Typography>
          <br />
          <Typography variant="h6" style={{ textAlign: 'center' }}>
            <Box fontWeight="fontWeightBold">
              PMEP, LLC
              <br />
              CONTENT LICENSE AGREEMENT
              <br />
              Last Modified: July 9, 2021
            </Box>
          </Typography>
          <br />
          <Typography variant="body1" style={{ textAlign: 'left' }}>
            This Content License Agreement (the
            <strong> &ldquo;Agreement&rdquo;</strong>) is a binding contract
            between you (<strong>&ldquo;you,&rdquo; &ldquo;your,&rdquo;</strong>{' '}
            or <strong>&ldquo;Licensor&rdquo;</strong>) and PMEP, LLC (
            <strong>
              &ldquo;PMEP,&rdquo; &ldquo;we,&rdquo; or &ldquo;us&rdquo;
            </strong>
            ). This Agreement governs your access to and use of our online
            services, web site, and software provided on or in connection with
            the service (collectively, the{' '}
            <strong>&ldquo;Service&rdquo;</strong>). By accessing or using the
            Service, or by clicking a button or checking a box marked &ldquo;I
            Agree&rdquo; (or something similar), or by otherwise manifesting
            your assent, you signify that you have read, understood, and agree
            to be bound by this Agreement. PMEP reserves the right to modify
            these terms and will provide notice of these changes as described
            below.
          </Typography>
          <br />
          <br />
          <Typography variant="h5" style={{ textAlign: 'center' }}>
            <Link fontWeight="fontWeightBold" underline="always" color="black">
              AGREEMENT
            </Link>
          </Typography>
          <br />
          <Typography variant="body1">
            <ol>
              <li>
                <strong>Definitions.</strong>
                <div className="agreement">
                  <ol>
                    <li>
                      <strong>“Your Content”</strong> means any photographs,
                      images, videos, and/or other visual and/or audiovisual
                      works that you upload to the Service.
                    </li>
                    <li>
                      <strong>“Your Information”</strong> means the name(s),
                      trademarks, trade names, likeness, photographs,
                      biographical materials, artwork, liner notes, and other
                      graphical or textural materials owned or controlled by you
                      that you upload to the Service.
                    </li>
                    <li>
                      <strong>“Content”</strong> shall mean, collectively, Your
                      Content and Your Information.
                    </li>
                  </ol>
                </div>
              </li>
              <br />
              <li>
                <strong>License Grant.</strong> You hereby grant to PMEP a
                royalty-free, fully-paid-up, sublicensable, transferable,
                perpetual, irrevocable, worldwide, non-exclusive license to
                digitize, encode, reproduce, store, archive, modify, publish,
                list information regarding, edit, translate, distribute,
                publicly perform, digitally perform, publicly display, and make
                derivative works of the Your Content, in whole or in part, under
                all intellectual property rights and in any form, media or
                technology, whether now known or hereafter developed, for use on
                or in connection with PMEP’s Services, and to use the Your
                Information to the extent reasonably necessary in connection
                with the exercise of PMEP’s rights in the Your Content.
              </li>
              <br />
              <li>
                <strong>Delivery.</strong> You will deliver the Content to PMEP
                by uploading the Content to the Service.
              </li>
              <br />
              <li>
                <strong>Attribution.</strong> Where feasible, PMEP agrees to use
                commercially reasonable efforts to provide attribution to you as
                the creator of the Content, provided that PMEP’s failure to
                include attribution shall not constitute a breach of this
                Agreement. The format, content, layout, location and other
                characteristics of the attribution shall be solely determined by
                PMEP. You hereby agree that PMEP may use your name in connection
                with the Content without compensation or further permission.
              </li>
              <br />
              <li>
                <strong>No Fees.</strong> The parties agree that access to and
                use of the Content is free of charge and will not be subject to
                any fees, costs, or expenses.
              </li>
              <br />
              <li>
                <strong>Ownership.</strong>
                <div className="agreement">
                  <li></li>
                  <ol>
                    <li>
                      <strong>By You.</strong>PMEP acknowledges and agrees that,
                      as between you and PMEP, you own all right, title, and
                      interest in and to the Content and the intellectual
                      property rights therein, and, except as expressly provided
                      herein, nothing in this Agreement will confer on PMEP any
                      right of ownership or interest in the Content.
                    </li>
                    <li>
                      <strong>By PMEP.</strong>You acknowledge and agree that,
                      as between you and PMEP, PMEP shall own all right, title,
                      and interest in and to (i) PMEP’s Services, and (ii) any
                      derivative works made by PMEP to the Content, and (with
                      respect to both (i) and (ii)) all intellectual property
                      rights therein, and nothing in this Agreement will confer
                      on you any right of ownership or interest in any of the
                      foregoing.
                    </li>
                  </ol>
                </div>
              </li>
              <br />
              <li>
                <strong>Third Party Obligations.</strong> You shall be solely
                responsible for all licensing, clearance, reporting and payment
                obligations of any kind to third parties in connection with the
                Content, including but not limited to any applicable union
                and/or guild payments or royalties. Upon request, you shall
                provide PMEP with documentation sufficient to demonstrate your
                compliance with the terms of this Section.
              </li>
              <br />
              <li>
                <strong>Representations and Warranties.</strong> You represent
                and warrant that: (a) you have the full right, power, and
                authority to enter into this Agreement, and to grant any and all
                necessary rights and licenses provided herein; (b) the Content
                does not and will not infringe any intellectual property rights
                or any other proprietary rights of a third party (including
                third party publicity or privacy rights), and you have obtained
                valid releases for all persons appearing in the Content; (c) you
                have the right, power and authority to grant any and all
                necessary rights and licenses provided under this Agreement,
                including without limitation, all necessary copyright,
                performance, and reproduction rights and other related rights to
                the Content, free and clear of all claims and encumbrances
                without violating the rights of any person or entity, including
                any third party intellectual property rights; (d) PMEP’s use of
                the Content as permitted hereunder will not infringe any common
                law, statute or other rights whatsoever, including without
                limitation any copyright, trademark or other personal or
                proprietary right of any person, or confer on any person, firm
                or company a right of action or claim for damages against PMEP
                or expose PMEP to civil or criminal proceedings; and (e) you
                have not granted, and will not grant, any rights which conflict
                with those rights granted to PMEP hereunder.
              </li>
              <br />
              <li>
                <strong>Indemnity.</strong>You hereby indemnify, and agree to
                indemnify, defend and hold harmless PMEP and its officers,
                directors, consultants, employees, successors and assigns
                (“Indemnified Parties”) from and against any and all damages,
                losses, liabilities and expenses (including reasonable
                attorneys’ fees) incurred as a result of any third party claim,
                demand or action arising from any breach of any of the foregoing
                representations, warranties, or other undertakings or
                obligations in this Agreement or implied by law. Either party
                will promptly notify the other upon learning of any claim,
                action or proceeding arising out of or relating to a breach
                subject to this indemnity (although PMEP’s delay or failure to
                do so will not relieve you of any of your obligations under this
                paragraph), and PMEP will reasonably cooperate in the defense at
                your expense. For any claim defended by you, PMEP may choose to
                be separately represented at its own expense. No settlement
                intended to admit liability or bind any Indemnified Party is
                valid or final without the Indemnified Party’s written consent.
              </li>
              <br />
              <li>
                <strong>Release.</strong> You hereby release, and agree to
                release, PMEP and its officers, directors, consultants,
                employees, successors and assigns, from any claim of any kind or
                nature whatsoever arising from the use of the Content permitted
                hereunder, including, but not limited to, those based upon
                defamation, invasion of privacy, right of publicity, copyright,
                moral rights, or any other personal and/or property rights, and
                you agree not to assert or maintain any such claims against PMEP
                and its officers, directors, consultants, employees, successors
                and assigns.
              </li>
              <br />
              <li>
                <strong>Miscellaneous.</strong> This Agreement constitutes the
                entire agreement between the parties and supersedes all previous
                agreements, oral or written, with respect to the subject matter
                of this Agreement. This Agreement may not be amended without the
                prior written consent of both parties. You may not assign this
                Agreement, or any portion thereof, without PMEP’s prior written
                consent. PMEP may freely assign this Agreement. Any permitted
                assignment of this Agreement shall be binding upon and
                enforceable by and against the parties’ successors and assigns,
                provided that any unauthorized assignment shall be null and void
                and constitute a breach of this Agreement. This Agreement shall
                be governed and construed in accordance with the laws of the
                State of New York without regards to conflicts of laws. The
                parties agree the sole jurisdiction and venue for any disputes
                or actions arising under this Agreement shall be the
                jurisdiction of the Superior Court of the State of New York, New
                York County or the United States District Court for the Southern
                District of New York. As between one another, the parties are
                independent contractors and will have no right to assume or
                create any obligation or responsibility on behalf of the other
                party. If any provision of this Agreement is held invalid or
                unenforceable, it shall be replaced with the valid provision
                that most closely reflects the intent of the parties and the
                remaining provisions of the Agreement will remain in full force
                and effect. Each party acknowledges and represents that, in
                executing this Agreement, it has had the opportunity to seek
                advice as to its legal rights from legal counsel and that the
                person signing on its behalf has read and understood all of the
                terms and provisions of this Agreement. This Agreement will not
                be construed more strictly against either party as a result of
                its participation in its preparation.
              </li>
              <br />
              <li>
                <strong>Contact.</strong> Please contact us at info@pmep.org
                with any questions regarding this Agreement.
              </li>
              <br />
            </ol>
          </Typography>
          <Box height={100}>
            <a
              href={definedFileLink ? agreementDocUrl : MyPDF}
              target="_blank"
              rel="noopener noreferrer"
              download="EULA_Agree.pdf"
            >
              <Button
                variant="contained"
                style={{ marginTop: 20, float: 'left' }}
              >
                Download
              </Button>
            </a>
            {!fromSetting && (
              <Button
                color="primary"
                variant="contained"
                style={{ marginTop: 20, float: 'right' }}
                onClick={onAgree}
              >
                Agree
              </Button>
            )}

            {!fromSetting && (
              <Button
                variant="contained"
                style={{ marginTop: 20, float: 'right', marginRight: 20 }}
                onClick={onSignOut}
              >
                Not Agree
              </Button>
            )}

            {fromSetting && (
              <Button
                variant="contained"
                style={{ marginTop: 20, float: 'right' }}
                onClick={() => onChange('close')}
              >
                Close
              </Button>
            )}
          </Box>
        </CardContent>
      </Paper>
    </div>
  );
};

export default StationAdminEula;
