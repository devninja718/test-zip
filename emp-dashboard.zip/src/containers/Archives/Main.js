/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect } from 'react';
import clsx from 'clsx';
import { MainPanel } from '@app/components/Panels';
import { faSitemap } from '@fortawesome/pro-solid-svg-icons';
import { CircularProgress, Grid, Box } from '@material-ui/core';
import CustomTreeView from '@app/components/TreeViewPanel';
import SearchBar from 'material-ui-search-bar';
import {
  CustomDialog,
  CustomInput,
  CustomSelectBox
} from '@app/components/Custom';
import { getNotificationOpt } from '@app/constants/Notifications';
import * as globalStyles from '@app/constants/globalStyles';
import StatesList from '@app/constants/states.json';
import { getDisplayName } from '@app/utils/functions';
import { useNotifyContext } from '@app/providers/NotifyContext';
import { useFilterContext } from '@app/providers/FilterContext';
import { useSelectionContext } from '@app/providers/SelectionContext';
import { en } from '@app/language';

const ArchivesMain = ({
  resources,
  onChange,
  showLoading,
  selectedTreeItem,
  setSelectedTreeItem,
  createGrouping,
  updateGrouping,
  stationLoadedData,
  districtLoadedData,
  schoolLoadedData,
  classLoadedData,
  selected,
  setSelected,
  expanded,
  setExpanded,
  userInfo,
  showStateFilter,
  materialLoadedData
}) => {
  const classes = globalStyles.globaluseStyles();
  const { notify } = useNotifyContext();
  const [selectedState, setSelectedState] = useState();
  const {
    filterStateValue,
    setFilterStateValue,
    filteredStationId,
    filteredDistrictId,
    filteredDistrictList,
    currentSelectedType,
    setFilteredDistrictId
  } = useFilterContext();
  const [openCreate, setOpenCreate] = useState(false);
  const [openSearch, setOpenSearch] = useState(false);
  const [stateError, setStateError] = useState(false);
  const [newSearchKey, setNewSearchKey] = useState('');
  const [createDialogSetting, setCreateDialogSetting] = useState({});
  const [searchResults, setSearchResults] = useState();
  const stateListFromTopology = stationLoadedData
    ?.map((item) => item?.topology?.state)
    ?.filter((item) => item !== null && item?.length > 0);
  const filteredStateList = StatesList.filter((item) =>
    stateListFromTopology.includes(item?.value)
  );

  useEffect(() => {
    setCreateDialogSetting({
      error: false,
      helpText: en['Please input the name. It is required.'],
      autoFocus: true
    });
    setFilterStateValue('all');
  }, []);

  const handleMainPanelChange = (value) => {
    if (value === 'create') {
      setStateError(false);
      setSelectedState();
      setCreateDialogSetting({
        error: false,
        helpText: en['Please input the name. It is required'],
        autoFocus: true
      });
      setOpenCreate(true);
    }
    if (value === 'rename') {
    }
    if (value === 'refresh') onChange('refresh', true);
  };

  const handleElClicked = (type, value) => {
    if (type === 'single') {
      onChange('elSingleClick', value);
      if (
        value &&
        value._id !== filteredDistrictId &&
        currentSelectedType === 'district'
      ) {
        setFilteredDistrictId('all');
      }
    }
    if (type === 'root') onChange('root', value);
  };

  const handleRequestSearch = (value) => {
    onChange('delete', false);
    let results = [];
    results = resources.filter((e) => e.name === value);
    results = results.concat(
      resources.filter((e) => e.tagList?.includes(value))
    );
    if (results.length > 0) {
      setSearchResults(results);
    } else {
      setSearchResults(null);
    }
  };

  const handleCancelSearch = (event) => {
    setOpenSearch(false);
    setSearchResults(null);
    setNewSearchKey();
    let newexpanded = [
      ...selectedTreeItem?.parentIdList,
      selectedTreeItem?._id
    ];
    setExpanded(newexpanded);
    setSelected(selectedTreeItem?._id);
    handleElClicked('single', selectedTreeItem);
  };

  const handleStateChange = (data) => {
    console.log('change');
    setFilterStateValue(data?.value);
  };

  const getFilteredStation = () => {
    if (filteredStationId === 'all') {
      return stationLoadedData.filter((item) => {
        if (!filterStateValue || filterStateValue === 'all') return true;
        if (filterStateValue === item?.topology?.state) return true;
        return false;
      });
    } else {
      return stationLoadedData.filter((item) => {
        if (filteredStationId === item._id) return true;
        return false;
      });
    }
  };

  useEffect(() => {
    const stations = getFilteredStation().map((item) => item._id);
    if (selectedTreeItem && !stations.includes(selectedTreeItem?._id)) {
      if (
        !filteredDistrictList
          .map((item) => item.value)
          .includes(selectedTreeItem._id)
      ) {
        onChange('changeStation');
        setSelected();
      }
    }
  }, [filterStateValue]);

  useEffect(() => {
    if (filteredStationId && filteredStationId !== 'all') {
      const value = stationLoadedData.find((item) => {
        if (filteredStationId === item._id) return true;
        return false;
      });
      onChange('elSingleClick', value);
      setSelected(value?._id);
    } else {
      onChange('changeStation');
      setSelected();
    }
  }, [filteredStationId]);

  useEffect(() => {
    if (filteredDistrictId && filteredDistrictId !== 'all') {
      const value = districtLoadedData.find((item) => {
        if (filteredDistrictId === item._id) return true;
        return false;
      });
      if (value) {
        onChange('elSingleClick', value);
        setSelected(value._id);
      }
    } else {
      if (currentSelectedType !== 'district') {
        onChange('changeStation');
        setSelected();
      }
    }
  }, [filteredDistrictId]);

  useEffect(() => {
    if (districtLoadedData?.length > 0) {
      if (
        currentSelectedType === 'district' &&
        selectedTreeItem._id === filteredStationId
      ) {
        const value = districtLoadedData.find(
          (item) => filteredDistrictId === item._id
        );
        if (value) {
          onChange('elSingleClick', value);
          setSelected(value._id);
        }
      }
    }
    console.log(districtLoadedData);
  }, [districtLoadedData]);

  return (
    <MainPanel
      title={en['Archives']}
      icon={faSitemap}
      showFilter={true}
      showAddBtn={false}
      showRefresh
      disableAddBtn={
        selectedTreeItem
          ? selectedTreeItem?.schemaType === 'class'
            ? true
            : false
          : true
      }
      totalDisable={
        typeof selectedTreeItem === 'undefined' &&
        userInfo?.schemaType === 'districtAdmin'
          ? true
          : false
      }
      filteredStateList={filteredStateList}
      handleStateChange={handleStateChange}
      showStateFilter={showStateFilter}
      onChange={handleMainPanelChange}
      selectedTreeItem={selectedTreeItem}
    >
      {openSearch && (
        <div>
          <SearchBar
            value={newSearchKey}
            onChange={(newValue) => setNewSearchKey(newValue)}
            onCancelSearch={() => handleCancelSearch()}
            onRequestSearch={(value) => handleRequestSearch(value)}
          />
        </div>
      )}

      <div className={classes.elementList}>
        {(!stationLoadedData || stationLoadedData.length === 0) &&
        showLoading ? (
          <Box display="flex" justifyContent="center">
            <CircularProgress size={30} my={5} />
          </Box>
        ) : (
          <CustomTreeView
            resources={resources}
            selectedTreeItem={selectedTreeItem}
            setSelectedTreeItem={setSelectedTreeItem}
            onClick={handleElClicked}
            onChange={handleMainPanelChange}
            setSelected={setSelected}
            selected={selected}
            setExpanded={setExpanded}
            expanded={expanded}
            rootTitle={en['Stations']}
            stationLoadedData={getFilteredStation()}
            districtLoadedData={districtLoadedData}
            schoolLoadedData={schoolLoadedData}
            classLoadedData={classLoadedData}
            materialLoadedData={materialLoadedData}
            searchResults={searchResults}
            openSearch={openSearch}
            isTopology
            isAchive
            userInfo={userInfo}
          />
        )}
      </div>
    </MainPanel>
  );
};

export default ArchivesMain;
