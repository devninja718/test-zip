import React, { useState, useEffect, useContext, useRef } from 'react';
import { withRouter } from 'react-router-dom';
import { Grid } from '@material-ui/core';
import useStyles from './style';
import clsx from 'clsx';
import { EditPanel } from '@app/components/Panels';
import { useMutation } from '@apollo/client';
import TutorialCard from '@app/components/Custom/TutorialCard';
import { useUserContext } from '@app/providers/UserContext';
import AppContext from '@app/AppContext';
import {
  CustomInput,
  CustomDialog,
  CustomCheckBox
} from '@app/components/Custom';
import { AltText } from '@app/components/Forms';
import { getNotificationOpt } from '@app/constants/Notifications';
import { useNotifyContext } from '@app/providers/NotifyContext';
import graphql from '@app/graphql';
import { useLazyQuery } from '@apollo/client';
import { DefaultCard } from '@app/components/Cards';
import TextEditor from '@app/components/TextEditor';
import * as globalStyles from '@app/constants/globalStyles';
import { useMediaQuery } from 'react-responsive';
import {
  DescriptionForm,
  MultimediaAttachmentForm,
  AvatarUploadForm
} from '@app/components/Forms';
import {
  getUUID,
  getFileBaseURLFromURL,
  getFileNameFromURL,
  getFileDirectFromURL,
  getAssetUrl
} from '@app/utils/functions';
import { Box, Button, Typography } from '@material-ui/core';
import { ArrowBackIosRounded } from '@material-ui/icons';
import { useAssetContext } from '@app/providers/AssetContext';
import { create, remove, update } from '@app/utils/ApolloCacheManager';
import AttachmentPreview from '@app/components/Forms/Attachment/Preview';
import JSONEditor from '@app/components/JSONEditor';
import { en } from '@app/language';
import UserSearch from '@app/components/Forms/UserList/Search';
import useStylesSearch from '../User/searchStyle';
import { useGalleryContext } from '@app/providers/GalleryContext';

const TutorialContainer = ({ history }) => {
  const classes = globalStyles.globaluseStyles();
  const classes1 = useStyles();
  const [currentUser] = useUserContext();
  const [openCreate, setOpenCreate] = useState(false);
  const [newElName, setNewElName] = useState('');
  const [createDialogSetting, setCreateDialogSetting] = useState({});
  const [buttonDisable, setButtonDisable] = useState(false);

  const [loadTableData, setLoadTableData] = useState([]);
  const [loadedData, setLoadedData] = useState([]);
  const [searchStr, setSearchStr] = useState('');
  const [checkbox, setCheckbox] = useState(false);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const { notify } = useNotifyContext();
  const [context, setContext] = useContext(AppContext);
  const [currentRowId, setCurrentRowId] = useState();

  const [tutorialId, setTutorialId] = useState();
  const [descData, setDescData] = useState({});
  const [attachmentStatus, setAttachmentStatus] = useState(false);
  const [isAvatarAttached, setAvatarAttached] = useState(false);
  const [isAvatarUpload, setAvatarUpload] = useState(false);
  const [avatarS3URL, setAvatarS3URL] = useState();
  const [avatarType, setAvatarType] = useState();
  const [cardName, setCardName] = useState();
  const [originDetailData, setOriginDetailData] = useState(undefined);
  const [detailData, setDetailData] = useState(undefined);
  const [altText, setAltText] = useState();
  const [showMoreData, setShowMoreData] = useState(null);
  const [showMoreMode, setShowMoreMode] = useState(false);

  const [tutorial, setTutorial] = useState();

  const [currentAction, setCurrentAction] = useState('');
  const [canUpdate, setCanUpdate] = useState(false);
  const [currentTime, setCurrentTime] = useState();
  const [multimediaAssetsData, setMultimediaAssetsData] = useState();
  const [homeReload, setHomeReload] = useState(true);
  const nameRef = useRef();
  const { attachmentsUploaded, setAttachmentUploaded } = useAssetContext();
  const [avatarSize, setAvatarSize] = useState();
  const [openInfo, setOpenInfo] = useState(false);
  const [isFileRemove, setFileRemove] = useState(false);
  const [startMMAUploading, setStartMMAUploading] = useState(false);
  const { setOpenRight, setGalleryChildren, setGalleryData } =
    useGalleryContext();

  const variables = {
    id: null,
    schemaType: 'tutorial',
    offset: null,
    name: null
  };

  const isMobile = useMediaQuery({ query: `(max-width: 1280px)` });

  const [deleteAssetS3Grouping] = useMutation(
    graphql.mutations.deleteAssetS3Grouping
  );
  const [deleteDocument] = useMutation(graphql.mutations.deleteDocument, {
    update: (cache, { data: { deleteDocument } }) =>
      remove(cache, { data: { deleteDocument } }, currentRowId)
  });

  const [createGrouping] = useMutation(graphql.mutations.createGrouping, {
    update: create
  });

  const [updateGrouping] = useMutation(graphql.mutations.updateGrouping, {
    update: update
  });

  const [getTutorials, { loading, error, data }] = useLazyQuery(
    graphql.queries.TutorialGrouping
  );

  useEffect(() => {
    setOpenRight(false);
    setGalleryData((data) => ({ ...data, title: '' }));
    setGalleryChildren(null);

    fetchTutorials();
    setCurrentTime(new Date().getTime());
    setSearchStr('');
  }, []);

  // useEffect(() => {
  //   fetchTutorials();
  // }, [homeReload]);

  useEffect(() => {
    if (tutorial?._id === tutorialId) {
      setMMAFilesFromTutorial(tutorial);
      if (avatarS3URL == null) {
        if (
          tutorial?.avatar?.fileName &&
          tutorial?.avatar?.fileDir &&
          tutorial?.avatar?.baseUrl
        ) {
          setAvatarS3URL(
            tutorial?.avatar?.baseUrl +
              tutorial?.avatar?.fileDir +
              tutorial?.avatar?.fileName
          );
        } else {
          setAvatarS3URL();
        }
      }
      return;
    }
    setTutorialId(tutorial?._id);
    if (
      tutorial?.avatar?.fileName &&
      tutorial?.avatar?.fileDir &&
      tutorial?.avatar?.baseUrl
    ) {
      setAvatarS3URL(
        tutorial?.avatar?.baseUrl +
          tutorial?.avatar?.fileDir +
          tutorial?.avatar?.fileName
      );
    } else {
      setAvatarS3URL();
    }
    setAltText(tutorial?.avatar?.altText);
    setDescData({
      title: tutorial?.desc?.title?.replace(/<[^>]+>/g, '') || '',
      short: tutorial?.desc?.short?.replace(/<[^>]+>/g, '') || '',
      long: tutorial?.desc?.long?.replace(/<[^>]+>/g, '') || ''
    });
    setDetailData(tutorial?.body || '');
    setOriginDetailData(tutorial?.body || '');
    setMMAFilesFromTutorial(tutorial);
  }, [tutorial]);

  useEffect(() => {
    if (!loading && !error && data) {
      const { grouping } = data;
      setLoadedData(grouping);
    }
  }, [loading, error, data]);

  const fetchTutorials = async () => {
    await getTutorials({
      variables: variables,
      fetchPolicy: 'cache-and-network',
      nextFetchPolicy: 'cache-first'
    });
  };

  useEffect(() => {
    if (attachmentsUploaded) {
      setContext({
        ...context,
        documentDelete: null
      });
      setAttachmentUploaded(false);
    }
  }, [attachmentsUploaded]);

  useEffect(() => {
    if (searchStr == null || searchStr === '') {
      setLoadTableData(loadedData);
      if (tutorial) {
        const tempTuto = loadedData.filter((el) => el._id === tutorial._id);
        setTutorial(tempTuto ? tempTuto[0] : null);
        setMMAFilesFromTutorial(tempTuto ? tempTuto[0] : null);
      }
    } else {
      let filteredData = loadedData.filter(
        (e) =>
          (e.desc &&
            e.desc.title.toLowerCase().includes(searchStr.toLowerCase())) ||
          e.name.toLowerCase().includes(searchStr.toLowerCase()) ||
          (e.desc &&
            e.desc.short.toLowerCase().includes(searchStr.toLowerCase()))
      );

      setLoadTableData(filteredData);
      if (tutorial) {
        const tempTuto = filteredData.filter((el) => el._id === tutorial._id);
        setTutorial(tempTuto ? tempTuto[0] : null);
        setMMAFilesFromTutorial(tempTuto ? tempTuto[0] : null);
      }
    }
  }, [searchStr, loadedData]);

  const setMMAFilesFromTutorial = (ttr) => {
    if (ttr?.multimediaAssets) {
      let mmaData = ttr.multimediaAssets.map((item) => {
        let value = JSON.parse(JSON.stringify(item));
        delete value.__typename;
        return value;
      });
      setMultimediaAssetsData(mmaData);
    }
  };

  const handleSearchChange = async (type, value) => {
    if (type === 'search') {
      setSearchStr(value);
    }
  };

  const handleEditPanelChange = async (type, additionalAction) => {
    if (type === 'backToTutorials') {
      setShowMoreData(null);
    }
    if (type === 'add') {
      setCreateDialogSetting({
        error: false,
        helpText: en['Please input the name. It is required'],
        autoFocus: true
      });
      setOpenCreate(true);
      setShowMoreData(null);
    }

    if (type === 'cancel') {
      setCurrentAction('');
      // setHomeReload((el) => !el);
      setCanUpdate(false);
      setTutorial();
      setDescData();
    }

    if (type === 'save') {
      if (tutorial == null && (cardName == null || cardName === '')) {
        const notiOps = getNotificationOpt('tutorial', 'warning', 'emptyName');
        notify(notiOps.message, notiOps.options);
        return;
      }

      if (tutorial) {
        let variableData = {
          id: tutorial['_id'],
          schemaType: tutorial.schemaType,
          version: tutorial.version
        };

        let isChanged = false;

        const desc = {
          title: descData ? descData.title : '',
          short: descData ? descData.short : '',
          long: descData ? descData.long : ''
        };

        if (
          desc.title !== tutorial.desc?.title ||
          desc.short !== tutorial.desc?.short ||
          desc.long !== tutorial.desc?.long
        ) {
          variableData = {
            ...variableData,
            desc
          };
          isChanged = true;
        }

        if (detailData !== tutorial.detailData) {
          variableData = {
            ...variableData,
            body: detailData
          };
          isChanged = true;
        }

        let avatar = avatarS3URL
          ? {
              uId: tutorial.avatar?.uId ? tutorial.avatar?.uId : getUUID(),
              type: avatarType || 'avatar',
              baseUrl: tutorial.avatar?.baseUrl,
              fileDir: tutorial.avatar?.fileDir,
              status: 'ready',
              altText: altText,
              mimeType: tutorial.avatar?.mimeType,
              fileName: tutorial.avatar?.fileName,
              data: {
                imageSize: avatarSize
              }
            }
          : null;

        if (
          avatarS3URL &&
          // avatarS3URL.includes('galleries') &&
          avatarS3URL !== avatar.baseUrl + avatar.fileDir + avatar.fileName
        ) {
          let mimeType = 'image/jpeg';
          if (avatarS3URL.toLowerCase().endsWith('png')) {
            mimeType = 'image/png';
          }
          avatar.baseUrl = avatarS3URL.split('messages')[0] + 'messages' + '/';
          avatar.fileName = avatarS3URL.split('/').pop();
          avatar.fileDir = avatarS3URL
            .replace(avatar.baseUrl, '')
            .replace(avatar.fileName, '');
          avatar.mimeType = mimeType;
          avatar.data = {
            imageSize: avatarSize
          };
          isChanged = true;
        }

        if (tutorial.avatar?.fileName) {
          if (tutorial?.fileName !== tutorial.avatar?.fileName) {
            variableData = avatarS3URL
              ? {
                  ...variableData,
                  avatar: {
                    ...avatar
                  }
                }
              : {
                  ...variableData,
                  avatar: null
                };
            isChanged = true;
          }
        } else {
          if (avatar) {
            variableData = avatarS3URL
              ? {
                  ...variableData,
                  avatar: {
                    ...avatar
                  }
                }
              : {
                  ...variableData,
                  avatar: null
                };
            isChanged = true;
          }
        }

        if (isAvatarAttached) {
          isChanged = true;
        }

        if (altText !== '' && altText !== tutorial.avatar?.altText) {
          variableData = {
            ...variableData,
            avatar: {
              ...avatar,
              altText
            }
          };
          isChanged = true;
        }

        if (isChanged) {
          await updateGrouping({
            variables: variableData
          });

          if (
            tutorial.avatar?.fileName &&
            tutorial.avatar?.fileName !== avatar?.fileName
          ) {
            const avatarURL =
              tutorial.avatar?.baseUrl +
              tutorial.avatar?.fileDir +
              tutorial.avatar?.fileName;
            const assetUrl = getAssetUrl(avatarURL).split('/')[3];
            const key = avatarURL.split(assetUrl)[1].slice(1);
            await deleteAssetS3Grouping({
              variables: {
                bucket: assetUrl,
                key: key
              }
            });
          }
          // onChange('update', false);
          if (isAvatarAttached) {
            setAvatarUpload(true);
            setAvatarAttached(false);
          } else {
            const notiOps = getNotificationOpt(
              'tutorial',
              'success',
              'publish'
            );
            notify(notiOps.message, notiOps.options);
          }
          if (additionalAction !== 'fileRemoved') {
            setCanUpdate(false);
            setCurrentAction('');
            setTutorial();
          }
        } else {
          setCanUpdate(false);
          // onChange('update', false);
          // if (forceSave) onChange('forceSave', false);
        }
      } else {
        let createVaraibleData = {
          name: cardName,
          version: 1,
          trackingAuthorName: currentUser?.name,
          schemaType: 'tutorial',
          multimediaAssets: null,
          desc: {
            title: descData?.title,
            short: descData?.short,
            long: descData?.long
          },
          body: detailData
        };

        try {
          let response = await createGrouping({
            variables: createVaraibleData
          });
          setTutorial(response.data.createGrouping);

          if (isAvatarAttached) {
            setAvatarUpload(true);
            setAvatarAttached(false);
            return;
          } else {
            const notiOps = getNotificationOpt(
              'tutorial',
              'success',
              'publish'
            );
            notify(notiOps.message, notiOps.options);
            setCurrentAction('');
            // setHomeReload((el) => !el);
            setCanUpdate(false);
            setTutorial();
          }
        } catch (error) {
          notify(error.message, {
            autoHideDuration: 5000,
            variant: 'error'
          });
        }
      }
    }

    if (type === 'info') {
      setOpenInfo(true);
    }
  };

  useEffect(() => {
    if (currentRowId) {
      handleUpdateChange('edit', currentRowId);
    }
  }, []);

  useEffect(() => {
    if (showMoreData == null && tutorial == null) {
      setShowMoreMode(false);
    } else {
      setShowMoreMode(true);
    }
  }, [showMoreData, tutorial]);

  const handleUpdateChange = async (type, value) => {
    if (type === 'edit') {
      setCurrentRowId(value);
      let currentTutorial = loadedData.filter((el) => el._id === value);
      if (currentTutorial.length > 0) {
        setTutorial(currentTutorial[0]);
      }
      setCurrentAction('add');
      setShowMoreData(null);
      setCanUpdate(true);
      if (
        tutorial?.avatar &&
        tutorial.avatar?.baseUrl &&
        tutorial.avatar?.fileName
      ) {
        setAvatarS3URL(
          tutorial.avatar?.baseUrl +
            tutorial.avatar?.fileDir +
            tutorial.avatar?.fileName
        );
      } else {
        setAvatarS3URL();
      }
    }

    if (type === 'delete') {
      setCurrentRowId(value);
      setOpenDeleteDialog(true);
    }
  };

  const handleMultiAttFormChange = async (type, value) => {
    try {
      let assetUrlVariables = {
        id: tutorial['_id'],
        schemaType: tutorial.schemaType,
        version: tutorial.version,
        multimediaAssets: []
      };
      if (type === 'upload' || type === 'reOrder') {
        assetUrlVariables = {
          ...assetUrlVariables,
          multimediaAssets: value
        };
        // return;
      }

      if (type === 'delete') {
        if (multimediaAssetsData) {
          var newData = multimediaAssetsData.slice();
          let filteredData = newData?.filter(
            (el) =>
              !(el.fileName === value.fileName && el.fileDir === value.fileDir)
          );
          assetUrlVariables = {
            ...assetUrlVariables,
            multimediaAssets: filteredData
          };
          setMultimediaAssetsData(filteredData);
        } else {
          let newData = tutorial.multimediaAssets.slice();
          let filteredData = newData?.filter(
            (el) =>
              !(el.fileName === value.fileName && el.fileDir === value.fileDir)
          );

          let mmaData = [];
          if (filteredData) {
            mmaData = filteredData.map((item) => {
              let value = { ...item };
              delete value.__typename;
              return value;
            });
          }
          assetUrlVariables = {
            ...assetUrlVariables,
            multimediaAssets: mmaData
          };
          setMultimediaAssetsData(mmaData);
        }

        const avatarURL = value.baseUrl + value.fileDir + value.fileName;
        const assetUrl = getAssetUrl(avatarURL).split('/')[3];
        const key = avatarURL.split(assetUrl)[1].slice(1);
        await deleteAssetS3Grouping({
          variables: {
            bucket: assetUrl,
            key: key
          }
        });
      }

      if (type === 'update') {
        const tmp = multimediaAssetsData?.slice();
        const idx = tmp?.findIndex(
          (el) => el.fileName === value.fileName && el.fileDir === value.fileDir
        );
        tmp[idx] = { ...tmp[idx], ...value };
        assetUrlVariables = {
          ...assetUrlVariables,
          multimediaAssets: tmp
        };
        setMultimediaAssetsData(tmp);
      }

      assetUrlVariables = {
        ...assetUrlVariables,
        trackingAuthorName: currentUser?.name
      };

      setAttachmentStatus(true);
      await updateGrouping({
        variables: {
          ...assetUrlVariables
        }
      });
      if (type === 'update') {
        const notiOps = getNotificationOpt('attachment', 'success', 'update');
        notify(notiOps.message, notiOps.options);
      }
    } catch (error) {
      console.log(error.message);
    }
  };

  const deleteData = async (changeType, decision) => {
    if (changeType && decision && !checkbox) {
      const notiOps = getNotificationOpt('tutorial', 'warning', 'delete');
      notify(notiOps.message, notiOps.options);
      return;
    }
    if (changeType && decision && checkbox) {
      try {
        await deleteDocument({
          variables: {
            schemaType: 'tutorial',
            id: currentRowId
          }
        });

        const currentRow = loadedData.find((el) => el._id === currentRowId);

        if (
          currentRow?.avatar &&
          currentRow?.avatar?.baseUrl &&
          currentRow?.avatar?.fileDir &&
          currentRow?.avatar?.fileName
        ) {
          let avatarURL =
            currentRow?.avatar?.baseUrl +
            currentRow?.avatar?.fileDir +
            currentRow?.avatar?.fileName;
          const assetUrl = getAssetUrl(avatarURL).split('/')[3];
          const key = avatarURL.split(assetUrl)[1].slice(1);
          await deleteAssetS3Grouping({
            variables: {
              bucket: assetUrl,
              key: key
            }
          });
        }
        // setHomeReload((el) => !el);
        const notiOps = getNotificationOpt('tutorial', 'success', 'delete');
        notify(notiOps.message, notiOps.options);
      } catch {
        console.log(error.message);
        notify(error.message, { variant: 'error' });

        setOpenDeleteDialog(false);
        setCheckbox(false);
        setCurrentRowId();
        return;
      }
    }
    setOpenDeleteDialog(false);
    setCheckbox(false);
    setCurrentRowId();
  };

  const handleOnAvatarChange = (value) => {
    if (value === 'fileAttached') {
      setAvatarAttached(true);
    } else if (value === 'fileRemoved') {
      setAvatarAttached(false);
      setAvatarS3URL();
      setFileRemove(true);
      console.log('avatar dettached');
    } else {
      handleFormChange('avatarUpload', value);
    }
  };

  useEffect(() => {
    if (isFileRemove) {
      handleEditPanelChange('save', 'fileRemoved');
      setFileRemove(false);
    }
  }, [isFileRemove]);

  const handleFormChange = (type, value) => {
    if (type === 'description') {
      setDescData(value);
    }

    if (type === 'avatarType') {
      setAvatarType(value);
    }

    if (type === 'name') {
      setCardName(value);
    }

    if (type === 'avatarUpload') {
      if (value === 'remove') {
        setAvatarS3URL();
      } else {
        setAvatarS3URL(value);
      }
      return;
    }

    if (type === 'textEditor') {
      if (detailData === value) {
        return;
      }

      // prevent update by empty paragraph whose
      //plain text is actually an empty string
      if (
        (detailData || '')
          .replace(/<p>/gi, '')
          .replace(/<\/p>/gi, '')
          .replace(/\n/gi, '') === '' &&
        (value || '')
          .replace(/<p>/gi, '')
          .replace(/<\/p>/gi, '')
          .replace(/\n/gi, '') === ''
      ) {
        return;
      }

      setDetailData(value);
    }
  };

  useEffect(() => {
    if (isAvatarUpload) {
      handleEditPanelChange('save');
      setAvatarUpload(false);
      console.log(avatarS3URL);
    }
  }, [avatarS3URL]);

  const handleClickMore = (data) => (e) => {
    console.log('DATA', data);
    setShowMoreData(data);
  };

  const drawTable = () => {
    return (
      loadTableData.length > 0 &&
      loadTableData.map((row, index) => {
        return (
          <TutorialCard
            docId={row._id}
            name={row.desc ? row.desc.title : ''}
            title={row.desc ? row.desc.title : null}
            avatar_link={
              row?.avatar && row?.avatar?.baseUrl && row?.avatar?.fileDir
                ? row?.avatar?.baseUrl +
                  row?.avatar?.fileDir +
                  row?.avatar?.fileName
                : null
            }
            shortDescription={row.desc ? row.desc.short : null}
            longDescription={row.desc ? row.desc.long : null}
            onUpdate={handleUpdateChange}
            onClickMore={handleClickMore(row)}
          />
        );
      })
    );
  };

  const handleKeyDown = (e, change) => {
    if (e.keyCode === 13 && !e.shiftKey) {
      if (e.target.name === 'name') {
        nameRef.current.focus();
      }
      e.preventDefault();
    }
  };

  const drawTutorialCards = () => {
    return (
      <Grid>
        <Grid container justify="space-between" className={classes1.root}>
          {drawTable(loadedData)}
        </Grid>
        <CustomDialog
          open={openDeleteDialog}
          title={en[`Do you want to delete this card?`]}
          mainBtnName={en['Delete']}
          onChange={deleteData}
        >
          {en['Are you sure want to delete this data?']}
          <br />
          <CustomCheckBox
            color="primary"
            value={checkbox}
            label={en['I agree with this action.']}
            onChange={(value) => setCheckbox(!value)}
          />
        </CustomDialog>
      </Grid>
    );
  };

  const handleCreateDialogChange = async (type, value) => {
    try {
      if (type === 'input') {
        setNewElName(value);
        setCreateDialogSetting({
          error: false,
          helpText: en['Please input the name. It is required'],
          autoFocus: true
        });
      }

      if (type === 'btnClick') {
        if (value) {
          if (!buttonDisable) {
            setButtonDisable(true);
            let result;
            if (value) {
              if (!newElName) {
                setButtonDisable(false);
                setCreateDialogSetting({
                  error: true,
                  helpText: en['Please input the name. It is required'],
                  autoFocus: true
                });
                return;
              }

              let variables = {
                schemaType: 'tutorial',
                name: newElName,
                version: 1,
                trackingAuthorName: currentUser?.name
              };

              result = await createGrouping({ variables });
              setOpenCreate(false);

              const notiOps = getNotificationOpt(
                'tutorial',
                'success',
                'publish'
              );
              notify(notiOps.message, notiOps.options);

              setCurrentAction('add');
              setCurrentTime(new Date().getTime());
              setCanUpdate(true);
              setTutorial(result.data.createGrouping);
              setDescData();
            }
          }
          setNewElName('');

          setButtonDisable(false);
        } else {
          setOpenCreate(false);
          setNewElName('');
        }
      }
    } catch (error) {
      console.log(error.message);
      setNewElName('');
      setButtonDisable(false);
      if (error.message.includes('Name exists')) {
        setCreateDialogSetting({
          error: true,
          helpText: en['Name exists already. Name must be unique.'],
          autoFocus: true
        });
      }
    }
  };

  const getPrimaryVideo = () => {
    if (!showMoreData) return null;

    let asset = showMoreData?.multimediaAssets?.find(
      (asset) => asset.type === 'Primary'
    );

    if (!asset) return null;

    return {
      ...asset,
      url: `${asset.baseUrl}${asset.fileDir}${asset.fileName}`,
      type: asset.mimeType
    };
  };

  const handleInfoDialogChange = async (type, value) => {
    setOpenInfo(false);
  };

  return (
    <EditPanel
      title={showMoreData ? showMoreData?.name : 'Tutorial'}
      canEdit={
        (currentUser.schemaType === 'superAdmin' ||
          currentUser.schemaType === 'sysAdmin') &&
        !showMoreData
          ? true
          : false
      }
      canAdd={
        (currentUser.schemaType === 'superAdmin' ||
          currentUser.schemaType === 'sysAdmin') &&
        !showMoreData
          ? true
          : false
      }
      schemaType="tutorial"
      canUpdate={canUpdate}
      onSearch={handleSearchChange}
      onChange={handleEditPanelChange}
      canShowInfo={tutorial ? true : false}
      showMoreMode={showMoreMode}
      UserSearch={
        <UserSearch
          type={'Tutorial'}
          useStyles={useStylesSearch}
          onChange={(value) => handleSearchChange('search', value)}
        />
      }
    >
      {showMoreData ? (
        <Grid container style={{ padding: '24px 30px 24px 30px' }}>
          <Grid
            container
            spacing={2}
            direction="row"
            justify="flex-start"
            alignItems="flex-start"
          >
            <Grid
              container
              style={{ width: '80%', minWidth: '680px' }}
              direction="column"
            >
              <Grid item xs={12}>
                <Typography>
                  <Box
                    style={{
                      background: 'white',
                      padding: '10px',
                      fontSize: 24
                    }}
                  >
                    {showMoreData.desc?.title}
                  </Box>
                </Typography>
                <Typography>
                  <Box
                    style={{
                      background: 'white',
                      padding: '10px',
                      marginTop: 0,
                      fontSize: 20
                    }}
                  >
                    {showMoreData.desc?.short}
                  </Box>
                </Typography>

                {getPrimaryVideo() && (
                  <div
                    style={{
                      width: '680px',
                      paddingLeft: '10px',
                      marginTop: 24
                    }}
                  >
                    <AttachmentPreview resources={getPrimaryVideo()} />
                  </div>
                )}
                <div
                  style={{ background: 'white', padding: '10px', marginTop: 0 }}
                  dangerouslySetInnerHTML={{ __html: showMoreData.body }}
                ></div>
                <div
                  style={{
                    background: 'white',
                    padding: '10px',
                    borderRadius: 3,
                    border: '1px solid #d3d4d5',
                    marginTop: 0,
                    width: 600,
                    minWidth: 450,
                    marginBottom: 30
                  }}
                >
                  <MultimediaAttachmentForm
                    disable={true}
                    resources={showMoreData}
                    onChange={handleMultiAttFormChange}
                    setStartMMAUploading={setStartMMAUploading}
                  />
                </div>
                <Grid container spacing={4} style={{ marginTop: 0 }}>
                  {/* <Grid item xs={12} sm={12} md={12} lg={7} xl={7}> */}
                  {/* <DefaultCard className={classes.editPanelMobileAttachCard}>
                      <TextEditor
                        disable={true}
                        docId={showMoreData?._id}
                        detailData={showMoreData?.body}
                        textEditor={true}
                        resources={showMoreData}
                        onChange={(value) =>
                          handleFormChange('textEditor', value)
                        }
                      />
                    </DefaultCard> */}
                  {/* <div style={{ background: 'white', padding: '10px', marginTop: 0 }}
                    dangerouslySetInnerHTML={{ __html: showMoreData.body }}
                  ></div> */}
                  {/* </Grid>
                  <Grid item xs={12} sm={12} md={12} lg={5} xl={5}> */}
                  {/* <DefaultCard
                      className={
                        isMobile
                          ? classes.editPanelMobileAttachCard
                          : classes.editPanelAttachCard2
                      }
                    >
                      <MultimediaAttachmentForm
                        disable={true}
                        resources={showMoreData}
                        onChange={handleMultiAttFormChange}
                      />
                    </DefaultCard> */}
                  {/* <div style={{ background: 'white', padding: '10px', borderRadius: 3, border: '1px solid #d3d4d5', marginTop: 0 }} >
                    <MultimediaAttachmentForm
                      disable={true}
                      resources={showMoreData}
                      onChange={handleMultiAttFormChange}
                    />
                  </div> */}
                  {/* </Grid> */}
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      ) : currentAction === 'add' ? (
        <Grid spacing={4} container direction="row" style={{ padding: '16px' }}>
          <Grid item xs={12}>
            <Grid container spacing={4}>
              <Grid item xs={12} sm={12} md={12} lg={8} xl={8}>
                <DefaultCard style={classes.grayPanel}>
                  <Grid container spacing={4} style={{ padding: '24px' }}>
                    <Grid item xs={12}>
                      <CustomInput
                        multiline
                        rows={1}
                        label="Name"
                        variant="outlined"
                        size="small"
                        type="text"
                        name="Name"
                        resources={tutorial ? tutorial.name : null}
                        disabled={false}
                        inputRef={nameRef}
                        style={clsx({
                          [classes.inputArea]: true
                        })}
                        onKeyDown={handleKeyDown}
                        onChange={(value) => handleFormChange('name', value)}
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <AvatarUploadForm
                        disable={false}
                        docId={9?._id}
                        stationId={'tutorials'}
                        resources={avatarS3URL}
                        acceptedFiles={['image/png', 'image/jpg', 'image/jpeg']}
                        title={en['lesson dropzone banner']}
                        onChange={(value) => handleOnAvatarChange(value)}
                        changeAlt={(value) =>
                          handleFormChange('altText', value)
                        }
                        changeAvatarType={(value) =>
                          handleFormChange('avatarType', value)
                        }
                        disableGray={true}
                        isUpload={isAvatarUpload}
                        setUpload={setAvatarUpload}
                        doc={tutorial}
                        altText={tutorial?.avatar?.altText}
                        setAvatarSize={setAvatarSize}
                      />
                    </Grid>
                    <Grid item xs={12}>
                      {avatarS3URL ? (
                        <AltText
                          disable={false}
                          resources={altText}
                          onChange={(value) =>
                            handleFormChange('altText', value)
                          }
                        />
                      ) : (
                        []
                      )}
                    </Grid>
                    <Grid item xs={12}>
                      <DescriptionForm
                        disable={false}
                        resources={descData}
                        onChange={(value) =>
                          handleFormChange('description', value)
                        }
                        helperText={false}
                        disableGray={true}
                      />
                    </Grid>
                  </Grid>
                </DefaultCard>
              </Grid>
              {/* {tutorial && ( */}
              <Grid item xs={12} sm={12} md={12} lg={4} xl={4}>
                <DefaultCard
                  className={
                    isMobile
                      ? classes.editPanelMobileAttachCard
                      : classes.editPanelAttachCard2
                  }
                >
                  <MultimediaAttachmentForm
                    disable={false}
                    resources={tutorial}
                    onChange={handleMultiAttFormChange}
                    setStartMMAUploading={setStartMMAUploading}
                  />
                </DefaultCard>
              </Grid>
              {/* )} */}
              {tutorial && (
                <Grid item xs={12}>
                  <DefaultCard className={classes.editPanelHtmlCard1}>
                    <TextEditor
                      disable={false}
                      docId={tutorial?._id}
                      detailData={originDetailData}
                      textEditor={true}
                      resources={tutorial}
                      onChange={(value) =>
                        handleFormChange('textEditor', value)
                      }
                    />
                  </DefaultCard>
                </Grid>
              )}
            </Grid>
          </Grid>
        </Grid>
      ) : (
        drawTutorialCards(loadedData)
      )}
      <CustomDialog
        mainBtnName={en['Create']}
        open={openCreate}
        title={en[`Create a new Tutorial`]}
        onChange={handleCreateDialogChange}
      >
        <CustomInput
          my={2}
          size="small"
          type="text"
          autoFocus={true}
          label={en[`Enter the Tutorial name *`]}
          value={newElName}
          onChange={(value) => handleCreateDialogChange('input', value)}
          onKeyPress={(event) => {
            if (event.key === 'Enter') {
              handleCreateDialogChange('btnClick', event.target.value);
            }
          }}
          error={createDialogSetting.error}
          helperText={createDialogSetting.helpText}
          variant="outlined"
          width="300px"
        />
      </CustomDialog>
      <CustomDialog
        open={openInfo}
        title={en['Information']}
        maxWidth="sm"
        fullWidth={true}
        customClass={classes.infoDialogContent}
        onChange={handleInfoDialogChange}
      >
        <Grid item xs={12} sm={12} md={12} lg={12}>
          <JSONEditor disable={false} resources={tutorial} />
        </Grid>
      </CustomDialog>
    </EditPanel>
  );
};

export default withRouter(TutorialContainer);
