import React from 'react';
import { withRouter } from 'react-router-dom';
import ResourcesEdit from './Edit';

const ResourcesContainer = ({ history }) => {
  return <ResourcesEdit />;
};

export default withRouter(ResourcesContainer);
