import React, { useState, useEffect } from 'react';
import { Grid } from '@material-ui/core';
import { EditPanel } from '@app/components/Panels';
import * as globalStyles from '@app/constants/globalStyles';
import { LibraryTable } from '@app/components/Tables';
import { en } from '@app/language';
import { useGalleryContext } from '@app/providers/GalleryContext';

const loadedData = [
  {
    schemaType: 'resource',
    type: null
  },
  {
    schemaType: 'resource',
    type: 'PBS'
  },
  {
    schemaType: 'resource',
    type: 'OER'
  }
];
const ResourcesEdit = ({ history }) => {
  const classes = globalStyles.globaluseStyles();
  const [canUpdate, setCanUpdate] = useState(false);
  const [sourceType, setSourceType] = useState('all');
  const [searchAction, setSearchAction] = useState(false);
  const { setOpenRight, setGalleryChildren, setGalleryData } =
    useGalleryContext();

  useEffect(() => {
    setOpenRight(false);
    setGalleryData((data) => ({ ...data, title: '' }));
    setGalleryChildren(null);
  }, []);

  const getGrades = () => {
    return [
      'Preschool',
      'Lower Primary (K-2)',
      'Upper Primary (3-5)',
      'Middle School',
      'High School',
      'Community College',
      'College',
      'Graduate',
      'Career'
    ];
  };

  const handleSearchChange = async (type, value) => {
    if (type === 'search') {
      setSearchAction(true);
    }
  };

  const handleEditPanelChange = async (type, value) => {
    if (type === 'grade') {
    }

    if (type === 'info') {
      // setOpenInfo(true);
    }

    if (type === 'search') {
      setSearchAction(true);
    }

    if (type === 'contentType') {
      if (value === 'All Resources') {
        setSourceType('all');
      } else if (value === 'PBS Learning Media') {
        setSourceType('PBS');
      } else if (value === 'OER Common') {
        setSourceType('OER');
      }
    }
  };

  return (
    <EditPanel
      title={en['Resources']}
      canSearch={true}
      canUpdate={canUpdate}
      onSearch={handleSearchChange}
      onChange={handleEditPanelChange}
      gradeResources={getGrades()}
    >
      <Grid
        spacing={globalStyles.GridSpacingStyles}
        container
        direction="row"
        justify="flex-start"
        alignItems="flex-start"
      >
        <Grid item xs={12} sm={12} md={12} lg={12} spacing={4}>
          <LibraryTable
            library={loadedData[0]}
            pageMenu={'Resources'}
            sourceType={sourceType}
            searchAction={searchAction}
            setSearchAction={setSearchAction}
          />
        </Grid>
      </Grid>
      {/* <CustomDialog
        open={openInfo}
        title="Information"
        maxWidth="sm"
        fullWidth={true}
        customClass={classes.infoDialogContent}
        onChange={handleInfoDialogChange}
      >
        <Grid item xs={12} sm={12} md={12} lg={12}>
          <JSONEditor disable={false} resources={tutorial} />
        </Grid>
      </CustomDialog> */}
    </EditPanel>
  );
};

export default ResourcesEdit;
