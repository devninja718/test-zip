import React, { useState, useEffect } from 'react';
import clsx from 'clsx';
import { MainPanel } from '@app/components/Panels';
import { faCommentAlt } from '@fortawesome/free-solid-svg-icons';
import {
  Box,
  List,
  ListItem,
  ListItemText,
  Typography
} from '@material-ui/core';
import { useSnackbar } from 'notistack';
import { CustomDialog, CustomInput } from '@app/components/Custom';
import { getNotificationOpt } from '@app/constants/Notifications';
import { globaluseStyles } from '@app/constants/globalStyles';
import { useSelectionContext } from '@app/providers/SelectionContext';
import { useUserContext } from '@app/providers/UserContext';
import { en } from '@app/language';

const MessageMain = ({
  selectedDocId,
  variables,
  resources,
  createGrouping,
  onChange
}) => {
  const classes = globaluseStyles();
  const { enqueueSnackbar } = useSnackbar();
  const [openCreate, setOpenCreate] = useState(false);
  const [createDialogSetting, setCreateDialogSetting] = useState({});
  const [newElName, setNewElName] = useState('');
  const [selectedData, setSelectedData] = useState();
  const [buttonDisable, setButtonDisable] = useState(false);
  const [currentUser] = useUserContext();

  useEffect(() => {
    setCreateDialogSetting({
      error: false,
      helpText: en['Please choose one state']
    });
  }, []);

  const handleMainPanelChange = (value) => {
    if (value === 'create') setOpenCreate(true);
  };

  const handleElClicked = (type, value) => {
    if (type === 'single') {
      setSelectedData(value);
      onChange('elSingleClick', value);
    }
  };

  const handleCreateDialogChange = async (type, value) => {
    try {
      if (type === 'input') {
        setNewElName(value);
        setCreateDialogSetting({
          error: false,
          helperText: en['Please enter the new Message name']
        });
      }
      if (type === 'btnClick') {
        if (value) {
          let startAtTimeStamp = new Date().getTime();
          let endAtTimeStamp = new Date().getTime() + 24 * 3600 * 1000;
          var startAt = new Date(startAtTimeStamp);
          var endAt = new Date(endAtTimeStamp);
          const schedule = {
            startAt: startAt && startAt.toISOString(),
            endAt: endAt && endAt.toISOString(),
            status: 'active'
          };

          const result = await createGrouping({
            variables: {
              ...variables,
              schedule,
              name: newElName,
              trackingAuthorName: currentUser?.name,
              version: 1
            }
          });
          const notiOps = getNotificationOpt('message', 'success', 'create');
          enqueueSnackbar(notiOps.message, notiOps.options);
          setSelectedData(result?.data?.createGrouping);
          handleElClicked('single', result?.data?.createGrouping);
        }
        setOpenCreate(false);
        setNewElName('');
      }
    } catch (error) {
      console.log(error.message);
      setNewElName('');
      setButtonDisable(false);
      if (error.message.includes('Name exists')) {
        setCreateDialogSetting({
          error: true,
          helpText: en['Name exists already. Name must be unique.'],
          autoFocus: true
        });
      }
    }
  };

  return (
    <MainPanel
      title={en['Messages']}
      icon={faCommentAlt}
      showAddBtn
      onChange={handleMainPanelChange}
    >
      <List className={classes.elementList}>
        {resources &&
          resources.map((el) => (
            <ListItem
              key={el['_id']}
              onClick={() => handleElClicked('single', el)}
              className={clsx(classes.listItems, {
                [classes.listItem]: el['_id'] !== selectedDocId,
                [classes.listItemSelected]: el['_id'] === selectedDocId
              })}
            >
              <ListItemText className={classes.listItemText}>
                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                  component={Typography}
                  variant="subtitle1"
                >
                  <span
                    className={clsx({
                      [classes.listItemText]: el['_id'] !== selectedDocId,
                      [classes.listSelectedItemText]:
                        el['_id'] === selectedDocId
                    })}
                  >
                    {el.name}
                  </span>
                </Box>
              </ListItemText>
            </ListItem>
          ))}
      </List>
      <CustomDialog
        mainBtnName={en['Create']}
        open={openCreate}
        title={en['Create a new Message']}
        onChange={handleCreateDialogChange}
      >
        <CustomInput
          type="text"
          label={en['Enter Message Name *']}
          value={newElName}
          onChange={(value) => handleCreateDialogChange('input', value)}
          onKeyPress={(event) => {
            if (event.key === 'Enter') {
              handleCreateDialogChange('btnClick', event.target.value);
            }
          }}
          error={createDialogSetting.error}
          helperText={createDialogSetting.helperText}
          variant="outlined"
          size="small"
          width="300px"
        />
      </CustomDialog>
    </MainPanel>
  );
};

export default MessageMain;
