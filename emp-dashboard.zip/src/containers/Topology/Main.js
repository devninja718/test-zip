/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect } from 'react';
import clsx from 'clsx';
import { MainPanel } from '@app/components/Panels';
import { faSitemap } from '@fortawesome/pro-solid-svg-icons';
import { CircularProgress, Grid, Box, Typography } from '@material-ui/core';
import CustomTreeView from '@app/components/TreeViewPanel';
import SearchBar from 'material-ui-search-bar';
import {
  CustomDialog,
  CustomInput,
  CustomSelectBox
} from '@app/components/Custom';
import { getNotificationOpt } from '@app/constants/Notifications';
import * as globalStyles from '@app/constants/globalStyles';
import StatesList from '@app/constants/states.json';
import { getDisplayName } from '@app/utils/functions';
import { useNotifyContext } from '@app/providers/NotifyContext';
import { useFilterContext } from '@app/providers/FilterContext';
import { useSelectionContext } from '@app/providers/SelectionContext';
import { useUserContext } from '@app/providers/UserContext';
import { en } from '@app/language';

const TopologyMain = ({
  resources,
  onChange,
  showLoading,
  selectedTreeItem,
  setSelectedTreeItem,
  createGrouping,
  updateGrouping,
  stationLoadedData,
  districtLoadedData,
  schoolLoadedData,
  classLoadedData,
  selected,
  setSelected,
  expanded,
  setExpanded,
  userInfo,
  showStateFilter,
  whenState,
  setWhenState
}) => {
  const classes = globalStyles.globaluseStyles();
  const { notify } = useNotifyContext();
  const [selectedState, setSelectedState] = useState();
  const {
    filterStateValue,
    setFilterStateValue,
    filteredStationId,
    filteredDistrictId,
    filteredDistrictList,
    currentSelectedType,
    setFilteredDistrictId
  } = useFilterContext();
  const [openCreate, setOpenCreate] = useState(false);
  const [openSearch, setOpenSearch] = useState(false);
  const [stateError, setStateError] = useState(false);
  const [buttonDisable, setButtonDisable] = useState(false);
  const [newElName, setNewElName] = useState('');
  const [newSearchKey, setNewSearchKey] = useState('');
  const [createDialogSetting, setCreateDialogSetting] = useState({});
  const [searchResults, setSearchResults] = useState();
  const [openRename, setOpenRename] = useState(false);
  const [openSave, setOpenSave] = useState(false);
  const [currentUser] = useUserContext();

  const stateListFromTopology = stationLoadedData
    ?.map((item) => item?.topology?.state)
    ?.filter((item) => item !== null && item?.length > 0);
  const filteredStateList = StatesList.filter((item) =>
    stateListFromTopology.includes(item?.value)
  );

  useEffect(() => {
    setCreateDialogSetting({
      error: false,
      helpText: en['Please input the name. It is required.'],
      autoFocus: true
    });
    setFilterStateValue('all');
  }, []);

  const getTopologyState = () => {
    if (
      selectedTreeItem &&
      selectedTreeItem.schemaType !== 'station' &&
      selectedTreeItem?.topology
    ) {
      if (
        selectedTreeItem?.topology?.state == null ||
        selectedTreeItem?.topology?.state === ''
      ) {
        let tpStation = stationLoadedData.filter(
          (el) => el._id === selectedTreeItem?.topology?.station
        );
        if (tpStation.length > 0) {
          return tpStation[0]?.topology?.state;
        }
      }
    }
    return '';
  };

  const checkDublicate = (name, loadedData, schema, notify) => {
    const filterData = loadedData.filter(
      (item) => item?.name?.toLowerCase().trim() === name?.toLowerCase().trim()
    );
    if (filterData.length) {
      setCreateDialogSetting({
        error: true,
        helpText: `A ${schema} by name ${name} already exists`,
        autoFocus: true
      });
      return true;
    } else {
      return false;
    }
  };

  const checkDublicateWithParent = (
    name,
    parentId,
    loadedData,
    schema,
    notify
  ) => {
    const filterData = loadedData.filter(
      (item) =>
        item?.name?.toLowerCase().trim() === name?.toLowerCase().trim() &&
        item?.parentId === parentId
    );
    if (filterData.length) {
      setCreateDialogSetting({
        error: true,
        helpText: `A ${schema} by name ${name} already exists`,
        autoFocus: true
      });
      return true;
    } else {
      return false;
    }
  };

  const handleSaveChange = (value, type) => {
    setOpenSave(false);
    if (type) {
      onChange('SaveStation');
    } else if (!type && value === 'btnClick') {
      setWhenState(false);
      handleMainPanelChange('create', true);
    }
  };

  const handleCreateDialogChange = async (type, value) => {
    try {
      if (type === 'input') {
        setNewElName(value);
        setCreateDialogSetting({
          error: false,
          helpText: en['Please input the name. It is required'],
          autoFocus: true
        });
      }

      if (type === 'btnClick') {
        if (value) {
          if (!buttonDisable) {
            setButtonDisable(true);
            let result;
            if (value) {
              if (!newElName) {
                setButtonDisable(false);
                setCreateDialogSetting({
                  error: true,
                  helpText: en['Please input the name. It is required'],
                  autoFocus: true
                });
                return;
              }

              if (!selectedTreeItem && !selectedState) {
                setStateError(true);
                setButtonDisable(false);
                return;
              }

              // checking dublicate station end;

              if (openRename) {
                result = await updateGrouping({
                  variables: {
                    name: newElName,
                    version: selectedTreeItem?.version,
                    trackingAuthorName: currentUser?.name,
                    id: selectedTreeItem?._id,
                    schemaType: selectedTreeItem?.schemaType
                  }
                });

                onChange('update', false);
                // onChange('refresh', true);
                setNewElName('');

                setSelected(result?.data?.updateGrouping?._id);
                setSelectedTreeItem(result?.data?.updateGrouping);
                handleElClicked('single', result?.data?.updateGrouping);

                const notiOps = getNotificationOpt(
                  'material',
                  'success',
                  'rename'
                );
                notify(notiOps.message, notiOps.options);
              } else {
                let parentIdList = selectedTreeItem?.parentIdList
                  ? [...selectedTreeItem?.parentIdList, selectedTreeItem?._id]
                  : [selectedTreeItem?._id];

                let topologyData = {
                  state: !selectedTreeItem
                    ? selectedState
                    : selectedTreeItem?.topology?.state &&
                      selectedTreeItem?.topology?.state !== ''
                    ? selectedTreeItem?.topology?.state
                    : getTopologyState(),
                  station: selectedTreeItem?.topology?.station,
                  district: selectedTreeItem?.topology?.district,
                  school: selectedTreeItem?.topology?.school,
                  class: selectedTreeItem?.topology?.class,
                  [selectedTreeItem?.schemaType]: selectedTreeItem?._id
                };
                // Timestamp in seconds
                const timestamp = new Date().valueOf() / 1000;
                const schemaType = getSchemaType(selectedTreeItem?.schemaType);

                let variables = {
                  schemaType,
                  name: newElName,
                  trackingAuthorName: currentUser?.name,
                  parentId: selectedTreeItem?._id,
                  version: 1,
                  childrenIdList: [],
                  parentIdList: parentIdList,
                  topology: topologyData,
                  status: schemaType === 'class' ? 'created' : 'published',
                  rank: parseInt(timestamp)
                };

                if (schemaType === 'station') {
                  delete variables.parentId;
                  delete variables.parentIdList;
                }

                result = await createGrouping({ variables });

                setOpenCreate(false);

                const notiOps = getNotificationOpt(
                  getSchemaType(selectedTreeItem?.schemaType),
                  'success',
                  'create'
                );
                notify(notiOps.message, notiOps.options);

                topologyData = {
                  ...topologyData,
                  [getSchemaType(selectedTreeItem?.schemaType)]:
                    result.data.createGrouping._id
                };
                await updateGrouping({
                  variables: {
                    id: result.data.createGrouping._id,
                    schemaType: getSchemaType(selectedTreeItem?.schemaType),
                    version: result.data.createGrouping.version,
                    trackingAuthorName: currentUser?.name,
                    desc: {
                      title: newElName,
                      short: '',
                      long: ''
                    },
                    topology: topologyData,
                    status: 'published'
                  }
                });

                try {
                  const childrenIdList = selectedTreeItem?.childrenIdList
                    ? [
                        ...selectedTreeItem?.childrenIdList,
                        result.data.createGrouping._id
                      ]
                    : [result.data.createGrouping._id];

                  if (selectedTreeItem) {
                    await updateGrouping({
                      variables: {
                        id: selectedTreeItem['_id'],
                        schemaType: selectedTreeItem?.schemaType,
                        version: selectedTreeItem?.version,
                        trackingAuthorName: currentUser?.name,
                        childrenIdList: childrenIdList
                      }
                    });
                  }
                } catch (err) {
                  console.log(err);
                }
              }
            }
            setOpenRename(false);
            onChange('update', false);
            setNewElName('');
            if (selectedTreeItem?._id) {
              let newexpanded = expanded.includes(selectedTreeItem?._id)
                ? expanded
                : [...expanded, selectedTreeItem?._id];
              setExpanded(newexpanded);
            } else {
              setExpanded(['root']);
            }
            handleElClicked('single', result?.data?.createGrouping);
          }
          setButtonDisable(false);
        } else {
          setOpenCreate(false);
          setOpenRename(false);
          setNewElName('');
        }
      }
    } catch (error) {
      console.log(error.message);
      setNewElName('');
      setButtonDisable(false);
      if (error.message.includes('Name exists')) {
        setCreateDialogSetting({
          error: true,
          helpText: en['Name exists already. Name must be unique.'],
          autoFocus: true
        });
      }
    }
  };

  const getSchemaType = (value) => {
    if (value === 'station') return 'district';
    if (value === 'district') return 'school';
    if (value === 'school') return 'class';
    return 'station';
  };

  const getSchemaTitle = (value) => {
    if (value === 'station') return 'District';
    if (value === 'district') return 'School';
    if (value === 'school') return 'Class';
    return 'Station';
  };

  const handleMainPanelChange = (value, canCreate) => {
    if (value === 'create') {
      if (whenState && !canCreate) {
        setOpenSave(true);
        return;
      }
      setStateError(false);
      setSelectedState();
      setCreateDialogSetting({
        error: false,
        helpText: en['Please input the name. It is required'],
        autoFocus: true
      });
      setOpenCreate(true);
    }
    if (value === 'rename') {
      let id = selectedTreeItem && selectedTreeItem?._id;
      setNewElName(selectedTreeItem && getDisplayName(selectedTreeItem?.name));
      id !== 'root' && setOpenRename(true);
    }
    if (value === 'refresh') onChange('refresh', true);
  };

  const handleElClicked = (type, value) => {
    if (type === 'single') {
      onChange('elSingleClick', value);
      if (
        value &&
        value._id !== filteredDistrictId &&
        currentSelectedType === 'district'
      ) {
        setFilteredDistrictId('all');
      }
    }
    if (type === 'root') onChange('root', value);
  };

  const handleRequestSearch = (value) => {
    onChange('delete', false);
    let results = [];
    results = resources.filter((e) => e.name === value);
    results = results.concat(
      resources.filter((e) => e.tagList?.includes(value))
    );
    if (results.length > 0) {
      setSearchResults(results);
    } else {
      setSearchResults(null);
    }
  };

  const handleCancelSearch = (event) => {
    setOpenSearch(false);
    setSearchResults(null);
    setNewSearchKey();
    let newexpanded = [
      ...selectedTreeItem?.parentIdList,
      selectedTreeItem?._id
    ];
    setExpanded(newexpanded);
    setSelected(selectedTreeItem?._id);
    handleElClicked('single', selectedTreeItem);
  };

  const handleStateChange = (data) => {
    console.log('change');
    setFilterStateValue(data?.value);
  };

  const handleStationState = (data) => {
    if (stateError) {
      setStateError(false);
    }

    setSelectedState(data?.value);
  };

  const getFilteredStation = () => {
    if (filteredStationId === 'all') {
      return stationLoadedData.filter((item) => {
        if (!filterStateValue || filterStateValue === 'all') return true;
        if (filterStateValue === item?.topology?.state) return true;
        return false;
      });
    } else {
      return stationLoadedData.filter((item) => {
        if (filteredStationId === item._id) return true;
        return false;
      });
    }
  };

  useEffect(() => {
    const stations = getFilteredStation().map((item) => item._id);
    if (selectedTreeItem && !stations.includes(selectedTreeItem?._id)) {
      if (
        !filteredDistrictList
          .map((item) => item.value)
          .includes(selectedTreeItem._id)
      ) {
        onChange('changeStation');
        setSelected();
      }
    }
  }, [filterStateValue]);

  useEffect(() => {
    if (filteredStationId && filteredStationId !== 'all') {
      const value = stationLoadedData.find((item) => {
        if (filteredStationId === item._id) return true;
        return false;
      });
      onChange('elSingleClick', value);
      setSelected(value?._id);
    } else {
      onChange('changeStation');
      setSelected();
    }
  }, [filteredStationId]);

  useEffect(() => {
    if (filteredDistrictId && filteredDistrictId !== 'all') {
      const value = districtLoadedData.find((item) => {
        if (filteredDistrictId === item._id) return true;
        return false;
      });
      if (value) {
        onChange('elSingleClick', value);
        setSelected(value._id);
      }
    } else {
      if (currentSelectedType !== 'district') {
        onChange('changeStation');
        setSelected();
      }
    }
  }, [filteredDistrictId]);

  useEffect(() => {
    if (districtLoadedData?.length > 0) {
      if (
        currentSelectedType === 'district' &&
        selectedTreeItem._id === filteredStationId
      ) {
        const value = districtLoadedData.find(
          (item) => filteredDistrictId === item._id
        );
        if (value) {
          onChange('elSingleClick', value);
          setSelected(value._id);
        }
      }
    }
  }, [districtLoadedData]);

  return (
    <MainPanel
      title={en['Topologies']}
      icon={faSitemap}
      showFilter={true}
      showAddBtn
      showRefresh
      disableAddBtn={
        selectedTreeItem
          ? selectedTreeItem?.schemaType === 'class'
            ? true
            : false
          : true
      }
      totalDisable={
        typeof selectedTreeItem === 'undefined' &&
        userInfo?.schemaType === 'districtAdmin'
          ? true
          : false
      }
      filteredStateList={filteredStateList}
      handleStateChange={handleStateChange}
      showStateFilter={showStateFilter}
      onChange={handleMainPanelChange}
      selectedTreeItem={selectedTreeItem}
    >
      {openSearch && (
        <div>
          <SearchBar
            value={newSearchKey}
            onChange={(newValue) => setNewSearchKey(newValue)}
            onCancelSearch={() => handleCancelSearch()}
            onRequestSearch={(value) => handleRequestSearch(value)}
          />
        </div>
      )}

      <div className={classes.elementList}>
        {(!stationLoadedData || stationLoadedData.length === 0) &&
        showLoading ? (
          <Box display="flex" justifyContent="center">
            <CircularProgress size={30} my={5} />
          </Box>
        ) : (
          <CustomTreeView
            resources={resources}
            selectedTreeItem={selectedTreeItem}
            setSelectedTreeItem={setSelectedTreeItem}
            onClick={handleElClicked}
            onChange={handleMainPanelChange}
            setSelected={setSelected}
            selected={selected}
            setExpanded={setExpanded}
            expanded={expanded}
            rootTitle={en['Stations']}
            stationLoadedData={getFilteredStation()}
            districtLoadedData={districtLoadedData}
            schoolLoadedData={schoolLoadedData}
            classLoadedData={classLoadedData}
            searchResults={searchResults}
            openSearch={openSearch}
            isTopology
            userInfo={userInfo}
          />
        )}
      </div>
      <CustomDialog
        mainBtnName={en['Create']}
        open={openCreate}
        buttonDisable={buttonDisable}
        customClass={!selectedTreeItem ? classes.dialogWidth : false}
        title={`${en['Create a new']} ${getSchemaTitle(
          selectedTreeItem && selectedTreeItem?.schemaType
        )}`}
        onChange={handleCreateDialogChange}
      >
        <CustomInput
          my={2}
          size="small"
          type="text"
          autoFocus={true}
          label={`Enter the ${getSchemaTitle(
            selectedTreeItem && selectedTreeItem?.schemaType
          )} name *`}
          value={newElName}
          onChange={(value) => handleCreateDialogChange('input', value)}
          onKeyPress={(event) => {
            if (event.key === 'Enter') {
              handleCreateDialogChange('btnClick', event.target.value);
            }
          }}
          fullWidth
          error={createDialogSetting.error}
          helperText={createDialogSetting.helpText}
          variant="outlined"
          width="300px"
        />
        {!selectedTreeItem && (
          <div style={{ marginTop: 20 }}>
            <CustomSelectBox
              size="small"
              label={en['select a state']}
              variant="outlined"
              helperText={stateError ? en['Please select a state'] : ''}
              error={stateError}
              resources={StatesList}
              customStyle={{ width: 350, marginLeft: -4 }}
              onChange={handleStationState}
              value={selectedState}
            />
          </div>
        )}
      </CustomDialog>

      <CustomDialog
        // mainBtnName={en['SAVE']}
        dismissBtnName="Dismiss"
        mainBtnName="Save"
        secondaryBtnName="Discard"
        open={openSave}
        onChange={handleSaveChange}
      >
        <main>
          <Typography variant="subtitle1" className={classes.warning}>
            {en['There are unsaved changes on the panel.']}
            <br />
            {en['Will you discard your current changes?']}
          </Typography>
        </main>
      </CustomDialog>

      <CustomDialog
        mainBtnName={en['Rename']}
        open={openRename}
        title={`${['Rename']} ${selectedTreeItem?.schemaType}`}
        onChange={handleCreateDialogChange}
      >
        <Grid item xs={12} sm={12} md={12} lg={10}>
          <CustomInput
            my={2}
            size="small"
            type="text"
            label={`Enter the ${selectedTreeItem?.schemaType} name *`}
            autoFocus={true}
            value={newElName}
            onChange={(value) => handleCreateDialogChange('input', value)}
            onKeyPress={(event) => {
              if (event.key === 'Enter') {
                handleCreateDialogChange('btnClick', event.target.value);
              }
            }}
            error={createDialogSetting.error}
            helperText=""
            variant="outlined"
            width="300px"
          />
        </Grid>
      </CustomDialog>
    </MainPanel>
  );
};

export default TopologyMain;
