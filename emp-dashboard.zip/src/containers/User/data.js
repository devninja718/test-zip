import { en } from '@app/language';

export const UsersResource = [
  {
    _id: 1,
    name: en['System Admins'],
    schemaType: 'sysAdmin',
    urlKey: 'system-admins',
    type: 'System'
  },
  {
    _id: 2,
    name: en['Educators'],
    schemaType: 'educator',
    urlKey: 'educators',
    type: 'Educator'
  },
  {
    _id: 3,
    name: en['Students'],
    schemaType: 'student',
    urlKey: 'students',
    type: 'Student'
  },
  {
    _id: 4,
    name: en['Station Admins'],
    schemaType: 'stationAdmin',
    urlKey: 'stationAdmins',
    type: 'StationAdmin'
  },
  {
    _id: 5,
    name: en['District Admins'],
    schemaType: 'districtAdmin',
    urlKey: 'districtAdmins',
    type: 'DistrictAdmin'
  },
  {
    _id: 6,
    name: en['School Admins'],
    schemaType: 'schoolAdmin',
    urlKey: 'schoolAdmins',
    type: 'SchoolAdmin'
  }
];
