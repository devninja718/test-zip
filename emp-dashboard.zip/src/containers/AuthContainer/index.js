import React from 'react';
import {
  Authenticator,
  SignIn,
  Greetings,
  ForgotPassword
} from 'aws-amplify-react';
import config from '@app/Config';
import { SnackbarProvider } from 'notistack';
import MySignIn from './Login';
import ForgotPasswordContainer from './ForgotPassword';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import { NotifyContextProvider } from '@app/providers/NotifyContext';

const AuthContainer = ({ children }) => {
  const notistackRef = React.createRef();
  const onClickDismiss = (key) => () => {
    notistackRef.current.closeSnackbar(key);
  };

  return (
    <div>
      <SnackbarProvider
        ref={notistackRef}
        maxSnack={5}
        hideIconVariant
        action={(key) => (
          <IconButton onClick={onClickDismiss(key)}>
            <CloseIcon />
          </IconButton>
        )}
      >
        <NotifyContextProvider>
          <Authenticator
            hide={[SignIn, ForgotPassword, Greetings]}
            amplifyConfig={config.aws}
            federated={
              {
                googleClientId:
                  '798060219259-tconre7aslsq0tamq8b9bt0fg9sansq3.apps.googleusercontent.com'
              }
            }
          >
            <MySignIn />
            <ForgotPasswordContainer />
            {children}
          </Authenticator>
        </NotifyContextProvider>
      </SnackbarProvider>
    </div>
  );
};

export default AuthContainer;
