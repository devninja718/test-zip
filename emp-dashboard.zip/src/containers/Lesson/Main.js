/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect } from 'react';
import { MainPanel } from '@app/components/Panels';
import {
  faBookOpen,
  faChalkboardTeacher
} from '@fortawesome/free-solid-svg-icons';
import { Grid, Typography } from '@material-ui/core';
import DraggableTreeView from '@app/components/DraggableTreeView';
import {
  CustomDialog,
  CustomInput,
  CustomRadioButtonsGroup,
  CustomCheckBox
} from '@app/components/Custom';
import { getNotificationOpt } from '@app/constants/Notifications';
import * as globalStyles from '@app/constants/globalStyles';
import { getAssetUrl, getDisplayName, getUUID } from '@app/utils/functions';
import { useNotifyContext } from '@app/providers/NotifyContext';
import { useFilterContext } from '@app/providers/FilterContext';
import { useSearchContext } from '@app/providers/SearchContext';
import { useLessonViewModeContext } from '@app/providers/LessonViewModeContext';
import { useMutation, useApolloClient, useLazyQuery } from '@apollo/client';
import graphql from '@app/graphql';
import { useUserContext } from '@app/providers/UserContext';
import CustomCard from '@app/components/Custom/Card';
import TreeListPanel from '@app/components/TreeListPanel';
import { en } from '@app/language';

const MaterialMain = ({
  variables,
  resources,
  selected,
  setSelected,
  setResources,
  onChange,
  selectedTreeItem,
  setSelectedTreeItem,
  createGrouping,
  updateGrouping,
  deleteDocument,
  classLoadedData,
  schoolLoadedData,
  onSearch,
  updateShow,
  when,
  setIsCreate,
  createShow,
  setCreateShow,
  stationLoadedData,
  viewMethod,
  history,
  cardViewList,
  setTopologyTitle
}) => {
  const { parent } = variables;
  const classes = globalStyles.globaluseStyles();
  const { notify } = useNotifyContext();
  const [openCreate, setOpenCreate] = useState(false);
  const [openRename, setOpenRename] = useState(false);
  const [openSearch, setOpenSearch] = useState(false);
  const [newElName, setNewElName] = useState('');
  const {
    filteredStationList,
    setFilterStateValue,
    filteredDistrictList,
    filteredDistrictId
  } = useFilterContext();
  const [buttonDisable, setButtonDisable] = useState(false);
  const [newSearchKey, setNewSearchKey] = useState('');
  const [subType, setSubType] = useState('folder');
  const [createDialogSetting, setCreateDialogSetting] = useState({});
  const [expanded, setExpanded] = useState();
  const [searchResults, setSearchResults] = useState();
  const { openSearch: openLessonSearch } = useSearchContext();
  const client = useApolloClient();
  const [currentUser] = useUserContext();
  const [copyAssetS3] = useMutation(graphql.mutations.copyAssetS3);
  const [title, setTitle] = useState('');
  const [openDeleteAbort, setOpenDeleteAbort] = useState(false);
  const [openDelete, setOpenDelete] = useState(false);
  const [checkbox, setCheckbox] = useState(false);
  const [studentResources, setStudentResources] = useState([]);
  const { selectedClassItem, setSelectedClassItem } =
    useLessonViewModeContext();

  const studentVariables = {
    schemaType: 'student',
    offset: null
  };
  const [
    getStudentItems,
    { loading: studentLoading, error: studentError, data: studentData }
  ] = useLazyQuery(graphql.queries.userGrouping);

  const fetchStudents = async (variables) => {
    await getStudentItems({
      variables: variables,
      fetchPolicy: 'cache-and-network',
      nextFetchPolicy: 'cache-first'
    });
  };

  useEffect(() => {
    if (!studentLoading && !studentError && studentData) {
      setStudentResources(studentData.grouping);
    }
  }, [studentLoading, studentError, studentData]);

  useEffect(() => {
    if (studentResources == null || studentResources?.length === 0) {
      fetchStudents(studentVariables);
    }
  }, []);

  const changePage = (item) => {
    setSelectedTreeItem(item);
    setSelected(item?._id);
  };

  const getTitle = async (item) => {
    let itemName = '';
    let finalName = <></>;

    let { data: stationItem } = await client.query({
      query: graphql.queries.nameGrouping,
      variables: {
        id: item?.topology?.station,
        schemaType: 'station'
      }
    });
    let station = getDisplayName(stationItem?.grouping[0]?.name);

    let { data: districtItem } = await client.query({
      query: graphql.queries.nameGrouping,
      variables: {
        id: item?.topology?.district,
        schemaType: 'district'
      }
    });
    let district = getDisplayName(districtItem?.grouping[0]?.name);

    let { data: schoolItem } = await client.query({
      query: graphql.queries.nameGrouping,
      variables: {
        id: item?.topology?.school,
        schemaType: 'school'
      }
    });
    let school = getDisplayName(schoolItem?.grouping[0]?.name);
    if (cardViewList) {
      if (
        currentUser?.schemaType === 'superAdmin' ||
        currentUser?.schemaType === 'sysAdmin'
      ) {
        setTopologyTitle(
          `${station} > ${district} > ${school} > ${selectedClassItem?.name}`
        );
      } else if (currentUser?.schemaType === 'stationAdmin') {
        setTopologyTitle(
          `${station} > ${district} > ${school} > ${selectedClassItem?.name}`
        );
      } else if (currentUser?.schemaType === 'districtAdmin') {
        setTopologyTitle(
          `${station} > ${district} > ${school} > ${selectedClassItem?.name}`
        );
      } else if (currentUser?.schemaType === 'educator') {
        setTopologyTitle(
          `${district} > ${school} > ${selectedClassItem?.name}`
        );
      } else if (currentUser?.schemaType === 'schoolAdmin') {
        setTopologyTitle(`${school} > ${selectedClassItem?.name}`);
      }
    }

    finalName = `${station} > ${district} > ${school} > `;

    item.parentIdList?.forEach((el) => {
      if (itemName) {
        let parentItem = resources?.find((ele) => ele._id === el);
        itemName = `${getDisplayName(itemName)} > ${getDisplayName(
          parentItem?.name
        )}`;
        finalName = (
          <>
            {finalName}
            {` > `}
            <span
              className={classes.breadcrumb}
              onClick={() => changePage(parentItem)}
            >
              {getDisplayName(parentItem?.name)}
            </span>
          </>
        );
      } else {
        let parentItem = classLoadedData?.find((ele) => ele._id === el);
        itemName = getDisplayName(parentItem?.name);
        finalName = (
          <>
            {finalName}
            <span
              className={classes.breadcrumb}
              onClick={() => changePage(parentItem)}
            >
              {itemName}
            </span>
          </>
        );
      }
    });

    itemName = `${itemName} > ${getDisplayName(item.name)}`;
    finalName = (
      <>
        <span
          // className={classes.breadcrumb}
          onClick={() => {
            setSelectedTreeItem({ schemaType: '' });
            history.push('/materials');
          }}
          style={{ paddingRight: 50 }}
        >
          Lessons
        </span>
        {finalName}
        {` > `}
        <span className={classes.breadcrumb}>{getDisplayName(item.name)}</span>
      </>
    );
    return finalName;
  };

  useEffect(() => {
    const onLoad = async () => {
      setCheckbox(false);
      let title = await getTitle(selectedTreeItem);
      setTitle(title);
    };
    if (selectedTreeItem) {
      onLoad();
    }
  }, [selectedTreeItem]);

  useEffect(() => {
    const onLoad = async () => {
      setCheckbox(false);
      let title = await getTitle(selectedClassItem);
      setTitle(title);
    };
    if (selectedClassItem) {
      onLoad();
    }
  }, [selectedClassItem]);

  useEffect(() => {
    setCreateDialogSetting({
      error: false
    });
    setFilterStateValue('all');
  }, []);

  useEffect(() => {
    if (createShow) {
      setOpenCreate(true);
    }
  }, [createShow]);
  useEffect(() => {
    if (!openCreate && setCreateShow) {
      setCreateShow(false);
    }
  }, [openCreate]);

  useEffect(() => {}, [subType]);

  useEffect(() => {
    setOpenSearch(openLessonSearch);
  }, [openLessonSearch]);

  const handleCreateDialogChange = async (type, value, name, addType) => {
    try {
      if (type === 'input') {
        setNewElName(value);
        setCreateDialogSetting({
          error: false
        });
      }

      if (type === 'type') {
        setSubType(value);
      }
      if (type === 'cardView') {
        if (!buttonDisable) {
          setButtonDisable(true);
          let result;
          let updatedResult;
          if (value) {
            if (!name) {
              // const notiOps = getNotificationOpt('extra', 'error', 'name');
              // notify(notiOps.message, notiOps.options);
              setButtonDisable(false);
              setCreateDialogSetting({
                error: true,
                helpText: 'Please input the title. It is required'
              });
              return;
            }

            let stateValue;

            if (
              value?.topology?.state == null ||
              value?.topology?.state === ''
            ) {
              let stationEL = stationLoadedData.filter(
                (el) => el._id === value?.topology?.station
              );
              if (stationEL.length > 0) {
                stateValue = stationEL[0]?.topology?.state;
              }
            } else {
              stateValue = value?.topology?.state;
            }

            let topologyData = {};
            if (!value?.topology?.class) {
              topologyData = {
                state: stateValue,
                station: value?.topology?.station,
                district: value?.topology?.district,
                school: value?.topology?.school,
                class: value?._id
              };
            } else {
              topologyData = {
                state: stateValue,
                station: value?.topology?.station,
                district: value?.topology?.district,
                school: value?.topology?.school,
                class: value?.topology?.class
              };
            }

            if (openRename) {
              await updateGrouping({
                variables: {
                  name: name,
                  version: value?.version,
                  trackingAuthorName: currentUser?.name,
                  id: value?._id,
                  schemaType: 'material'
                }
              });

              const itemIndex = resources.findIndex(
                (resource) => resource._id === value?._id
              );
              const newSelectedItem = { ...value };
              newSelectedItem['name'] = name;

              const newResourcesList = [...resources];
              newResourcesList[itemIndex] = newSelectedItem;
              setResources(newResourcesList);
              setNewElName('');

              const notiOps = getNotificationOpt(
                'material',
                'success',
                'rename'
              );
              notify(notiOps.message, notiOps.options);
            } else {
              let parentIdList = [];

              if (value) {
                parentIdList =
                  value?.schemaType === 'class'
                    ? [value?._id]
                    : [
                        ...(value?.parentIdList ? value?.parentIdList : []),
                        value?._id
                      ];
              }

              let parentClasses = classLoadedData.filter((el) => {
                if (el._id === value.id) {
                  return true;
                } else {
                  return false;
                }
              });

              let parentClass =
                parentClasses && parentClasses.length > 0
                  ? parentClasses[0]
                  : value;

              // Timestamp in seconds
              const timestamp = new Date().valueOf() / 1000;
              console.log('addType:', addType);
              result =
                addType === 'collection'
                  ? await createGrouping({
                      variables: {
                        ...variables,
                        name: name,
                        trackingAuthorName: currentUser?.name,
                        parentId: value?._id,
                        topology: topologyData,
                        version: 1,
                        childrenIdList: [],
                        parentIdList: parentIdList,
                        desc: {
                          title: name
                        },
                        rank: parseInt(timestamp),
                        authorIdList: value?.authorIdList,
                        categories: {
                          lang: value?.categories?.lang
                        }
                      }
                    })
                  : await createGrouping({
                      variables: {
                        ...variables,
                        name: name,
                        trackingAuthorName: currentUser?.name,
                        parentId: value?._id,
                        topology: topologyData,
                        version: 1,
                        childrenIdList: null,
                        parentIdList: parentIdList,
                        desc: {
                          title: name
                        },
                        rank: parseInt(timestamp),
                        authorIdList: value?.authorIdList,
                        categories: {
                          lang: value?.categories?.lang
                        }
                      }
                    });
              let childrenIds = value?.childrenIdList;
              if (childrenIds) {
                childrenIds = [
                  ...childrenIds,
                  result?.data?.createGrouping?._id
                ];
              } else {
                childrenIds = [result?.data?.createGrouping?._id];
              }

              if (childrenIds?.length) {
                let varaibleData = {
                  id: value?._id,
                  schemaType: value?.schemaType,
                  version: value?.version,
                  trackingAuthorName: currentUser?.name,
                  childrenIdList: childrenIds
                };
                await updateGrouping({
                  variables: varaibleData
                });
              }

              if (parentClass?.avatar?.fileName) {
                const { createGrouping } = result?.data;
                const destkey = `${createGrouping?.topology?.station}/${createGrouping?._id}/${parentClass?.avatar?.fileName}`;
                const parentAvatar =
                  parentClass?.avatar?.baseUrl +
                  parentClass?.avatar?.fileDir +
                  parentClass?.avatar?.fileName;
                const assetBucketName = getAssetUrl(parentAvatar).split('/')[3];
                try {
                  await copyAssetS3({
                    variables: {
                      sourceUrl: parentAvatar,
                      destBucket: assetBucketName,
                      destKey: destkey
                    }
                  });

                  const fileDir = createGrouping?._id + '/';
                  let avatar = {
                    uId: getUUID(),
                    type: parentClass?.avatar?.type,
                    baseUrl: parentClass?.avatar?.baseUrl,
                    mimeType: parentClass?.avatar?.mimeType,
                    fileName: parentClass?.avatar?.fileName,
                    fileDir: fileDir
                  };

                  updatedResult = await updateGrouping({
                    variables: {
                      id: createGrouping?._id,
                      schemaType: createGrouping?.schemaType,
                      version: createGrouping?.version,
                      trackingAuthorName: currentUser?.name,
                      avatar: avatar
                    }
                  });
                } catch (err) {
                  console.log(err.message);
                }
              }
              setOpenCreate(false);
              onChange('created', true);
              const notiOps = getNotificationOpt(
                'material',
                'success',
                'create'
              );
              notify(notiOps.message, notiOps.options);
            }
            setOpenRename(false);
            setNewElName('');
            setExpanded(selectedTreeItem._id);
            handleElClicked(
              'single',
              updatedResult?.data?.updateGrouping
                ? updatedResult?.data?.updateGrouping
                : result?.data?.createGrouping
            );
          } else {
            setOpenCreate(false);
            setOpenRename(false);
            setNewElName('');
          }
        }
        setButtonDisable(false);
      }

      if (type === 'btnClick') {
        if (!buttonDisable) {
          console.log('subType:', subType);
          setButtonDisable(true);
          let result;
          let updatedResult;
          if (value) {
            if (!newElName) {
              // const notiOps = getNotificationOpt('extra', 'error', 'name');
              // notify(notiOps.message, notiOps.options);
              setButtonDisable(false);
              setCreateDialogSetting({
                error: true,
                helpText: 'Please input the title. It is required'
              });
              return;
            }

            let stateValue;

            if (
              selectedTreeItem?.topology?.state == null ||
              selectedTreeItem?.topology?.state === ''
            ) {
              let stationEL = stationLoadedData.filter(
                (el) => el._id === selectedTreeItem?.topology?.station
              );
              if (stationEL.length > 0) {
                stateValue = stationEL[0]?.topology?.state;
              }
            } else {
              stateValue = selectedTreeItem?.topology?.state;
            }

            let topologyData = {};
            if (!selectedTreeItem?.topology?.class) {
              topologyData = {
                state: stateValue,
                station: selectedTreeItem?.topology?.station,
                district: selectedTreeItem?.topology?.district,
                school: selectedTreeItem?.topology?.school,
                class: selectedTreeItem?._id
              };
            } else {
              topologyData = {
                state: stateValue,
                station: selectedTreeItem?.topology?.station,
                district: selectedTreeItem?.topology?.district,
                school: selectedTreeItem?.topology?.school,
                class: selectedTreeItem?.topology?.class
              };
            }

            if (openRename) {
              await updateGrouping({
                variables: {
                  name: newElName,
                  version: selectedTreeItem?.version,
                  id: selectedTreeItem?._id,
                  schemaType: 'material',
                  trackingAuthorName: currentUser?.name
                }
              });
              const itemIndex = resources.findIndex(
                (resource) => resource._id === selectedTreeItem?._id
              );
              const newSelectedItem = { ...selectedTreeItem };
              newSelectedItem['name'] = newElName;

              const newResourcesList = [...resources];
              newResourcesList[itemIndex] = newSelectedItem;
              setResources(newResourcesList);
              setNewElName('');

              const notiOps = getNotificationOpt(
                'material',
                'success',
                'rename'
              );
              notify(notiOps.message, notiOps.options);
            } else {
              let parentIdList = [];
              console.log('selectedTreeItem:', selectedTreeItem);
              if (selectedTreeItem) {
                parentIdList =
                  selectedTreeItem?.schemaType === 'class'
                    ? [selectedTreeItem?._id]
                    : [
                        ...(selectedTreeItem?.parentIdList
                          ? selectedTreeItem?.parentIdList
                          : []),
                        selectedTreeItem?._id
                      ];
              }

              let parentClasses = classLoadedData.filter((el) => {
                if (el._id === selectedTreeItem.id) {
                  return true;
                } else {
                  // if (selectedTreeItem.parentIdList.includes(el._id)) {
                  //   return true;
                  // } else {
                  //   return false;
                  // }
                  return false;
                }
              });

              let parentClass =
                parentClasses && parentClasses.length > 0
                  ? parentClasses[0]
                  : selectedTreeItem;

              // Timestamp in seconds
              const timestamp = new Date().valueOf() / 1000;

              result =
                subType === 'folder'
                  ? await createGrouping({
                      variables: {
                        ...variables,
                        name: newElName,
                        trackingAuthorName: currentUser?.name,
                        parentId: selectedTreeItem?._id,
                        topology: topologyData,
                        version: 1,
                        childrenIdList: [],
                        parentIdList: parentIdList,
                        desc: {
                          title: newElName
                        },
                        rank: parseInt(timestamp),
                        authorIdList: selectedTreeItem?.authorIdList,
                        categories: {
                          lang: selectedTreeItem?.categories?.lang
                        }
                      }
                    })
                  : await createGrouping({
                      variables: {
                        ...variables,
                        name: newElName,
                        trackingAuthorName: currentUser?.name,
                        parentId: selectedTreeItem?._id,
                        topology: topologyData,
                        version: 1,
                        childrenIdList: null,
                        parentIdList: parentIdList,
                        desc: {
                          title: newElName
                        },
                        rank: parseInt(timestamp),
                        authorIdList: selectedTreeItem?.authorIdList,
                        categories: {
                          lang: selectedTreeItem?.categories?.lang
                        }
                      }
                    });
              let childrenIds = selectedTreeItem?.childrenIdList;
              if (childrenIds) {
                childrenIds = [
                  ...childrenIds,
                  result?.data?.createGrouping?._id
                ];
              } else {
                childrenIds = [result?.data?.createGrouping?._id];
              }

              if (childrenIds?.length) {
                let varaibleData = {
                  id: selectedTreeItem?._id,
                  schemaType: selectedTreeItem?.schemaType,
                  version: selectedTreeItem?.version,
                  trackingAuthorName: currentUser?.name,
                  childrenIdList: childrenIds
                };
                await updateGrouping({
                  variables: varaibleData
                });
              }

              if (parentClass?.avatar?.fileName) {
                const { createGrouping } = result?.data;
                const destkey = `${createGrouping?.topology?.station}/${createGrouping?._id}/${parentClass?.avatar?.fileName}`;
                const parentAvatar =
                  parentClass?.avatar?.baseUrl +
                  parentClass?.avatar?.fileDir +
                  parentClass?.avatar?.fileName;
                const assetBucketName = getAssetUrl(parentAvatar).split('/')[3];
                try {
                  await copyAssetS3({
                    variables: {
                      sourceUrl: parentAvatar,
                      destBucket: assetBucketName,
                      destKey: destkey
                    }
                  });

                  const fileDir = createGrouping?._id + '/';
                  let avatar = {
                    uId: getUUID(),
                    type: parentClass?.avatar?.type,
                    baseUrl: parentClass?.avatar?.baseUrl,
                    mimeType: parentClass?.avatar?.mimeType,
                    fileName: parentClass?.avatar?.fileName,
                    fileDir: fileDir
                  };

                  updatedResult = await updateGrouping({
                    variables: {
                      id: createGrouping?._id,
                      schemaType: createGrouping?.schemaType,
                      version: createGrouping?.version,
                      trackingAuthorName: currentUser?.name,
                      avatar: avatar
                    }
                  });
                } catch (err) {
                  console.log(err.message);
                }
              }
              setOpenCreate(false);
              onChange('created', true);
              const notiOps = getNotificationOpt(
                'material',
                'success',
                'create'
              );
              notify(notiOps.message, notiOps.options);
            }
            setOpenRename(false);
            setNewElName('');
            setExpanded(selectedTreeItem._id);
            handleElClicked(
              'single',
              updatedResult?.data?.updateGrouping
                ? updatedResult?.data?.updateGrouping
                : result?.data?.createGrouping
            );
          } else {
            setOpenCreate(false);
            setOpenRename(false);
            setNewElName('');
          }
        }
        setButtonDisable(false);
      }
    } catch (error) {
      console.log(error.message);
      setNewElName('');
      setButtonDisable(false);
      setCreateDialogSetting({
        error: true,
        helpText:
          'This ' +
          (subType === 'folder' ? 'collection' : 'lesson') +
          ' already exists. Title must be unique.'
      });
    }
  };
  const handleMainPanelChange = (value) => {
    if (value === 'create') {
      if (when) {
        updateShow(true);
        setIsCreate(true);
      } else {
        setOpenCreate(true);
        setCreateDialogSetting({
          error: false,
          helpText: 'Please input title. It is required',
          autoFocus: true
        });
      }
    }
    if (value === 'rename') {
      let id = selectedTreeItem && selectedTreeItem?._id;
      let schemaType = selectedTreeItem && selectedTreeItem?.schemaType;
      setNewElName(selectedTreeItem && getDisplayName(selectedTreeItem?.name));
      id !== 'root' && schemaType !== 'class' && setOpenRename(true);
      setCreateDialogSetting({
        error: false,
        autoFocus: true
      });
    }
    if (value === 'search') setOpenSearch((prev) => !prev);
    if (value === 'undo') onSearch('');
    if (value === 'refresh') onChange('refresh', true);
    if (value === 'back') {
      onChange('back', true);
    }
  };

  const handleElClicked = (type, value) => {
    if (type === 'single') {
      // Save the lesson id that selected
      localStorage.setItem('previousLesson', JSON.stringify(value));
      if (value?.schemaType === 'class') {
        localStorage.setItem('previousClass', JSON.stringify(value));
      } else {
        let tmp = classLoadedData?.find(
          (el) => el._id === value?.topology?.class
        );
        localStorage.setItem('previousClass', JSON.stringify(tmp));
      }
      onChange('elSingleClick', value);
    }

    if (type === 'cardClick') {
      setSelectedClassItem(value);
      onChange('elCardClick', value);
    }

    if (type === 'root') onChange('root');
  };

  const handleRequestSearch = (value) => {
    let results = [];
    results = resources.filter((e) => e.name === value);
    results = results.concat(
      resources.filter((e) => e.tagList?.includes(value))
    );
    results = results.concat(classLoadedData.filter((e) => e.name === value));
    results = results.concat(
      classLoadedData.filter((e) => e.tagList?.includes(value))
    );
    if (results.length > 0) {
      setSearchResults(results);
    } else {
      setSearchResults('No Results');
    }
    setNewSearchKey(value);
  };

  const handleCancelSearch = (value) => {
    if (!value) {
      setOpenSearch(false);
      setSearchResults(null);
      setNewSearchKey();
    }
  };

  const getFilteredClasses = () => {
    if (
      currentUser?.schemaType === 'superAdmin' ||
      currentUser?.schemaType === 'sysAdmin'
    ) {
      if (filteredDistrictId !== 'all') {
        return classLoadedData.filter(
          (item) => item.topology?.district === filteredDistrictId
        );
      } else {
        if (filteredDistrictList?.length > 0) {
          const filteredDistrictIs = filteredDistrictList.map(
            (item) => item.value
          );
          return classLoadedData.filter((item) => {
            return filteredDistrictIs.includes(item?.topology?.district);
          });
        } else {
          return classLoadedData;
        }
      }
    } else {
      return classLoadedData;
    }
  };

  const getFilteredClassData = () => {
    if (filteredStationList.length > 0) {
      const filteredStationIds = filteredStationList.map((item) => item.value);
      return classLoadedData.filter((item) => {
        return filteredStationIds.length > 0
          ? filteredStationIds.includes(item?.topology?.station)
          : true;
      });
    } else {
      return classLoadedData;
    }
  };

  const handleDeleteDialogChange = async (type, value) => {
    try {
      if (type === 'btnClick') {
        if (!checkbox && value) {
          const notiOps = getNotificationOpt(
            selectedTreeItem?.schemaType,
            'warning',
            'delete'
          );
          notify(notiOps.message, notiOps.options);
          return;
        }
        let parentId = selectedTreeItem?.parentId;
        if (checkbox && value) {
          if (selectedTreeItem?.schemaType === 'class') {
            await deleteDocument({
              variables: {
                id: selectedTreeItem?._id,
                schemaType: selectedTreeItem?.schemaType
              }
            });

            if (
              selectedTreeItem?.schemaType === 'class' ||
              selectedTreeItem.schemaType === 'googleClass'
            ) {
              const schools = schoolLoadedData?.filter(
                (item) => item['_id'] === selectedTreeItem?.parentId
              );
              if (schools) {
                const school = schools[0];
                const schoolClasses = classLoadedData.filter(
                  (item) => item.parentId === selectedTreeItem.parentId
                );
                let childrenIdList = [];
                for (const sClass of schoolClasses) {
                  if (sClass._id !== selectedTreeItem['_id']) {
                    childrenIdList.push(sClass._id);
                  }
                }
                await updateGrouping({
                  variables: {
                    id: school['_id'],
                    schemaType: school.schemaType,
                    version: school.version,
                    trackingAuthorName: currentUser?.name,
                    childrenIdList: childrenIdList ? childrenIdList : []
                  }
                });

                let currentSchool = { ...school };
                currentSchool['childrenIdList'] = childrenIdList;
              }

              if (studentResources) {
                const myStudents = studentResources?.filter((el) =>
                  el.childrenIdList?.includes(selectedTreeItem._id)
                );
                if (myStudents) {
                  try {
                    for (let el of myStudents) {
                      await updateGrouping({
                        variables: {
                          id: el._id,
                          schemaType: el.schemaType,
                          version: el.version,
                          trackingAuthorName: currentUser?.name,
                          childrenIdList: el.childrenIdList?.filter(
                            (ci) => ci !== selectedTreeItem._id
                          )
                        }
                      });
                    }
                  } catch (err) {
                    console.log(err.message);
                  }
                }
              }
            }
            const notiOps = getNotificationOpt(
              selectedTreeItem?.schemaType,
              'success',
              'delete'
            );
            notify(notiOps.message, notiOps.options);
            if (
              viewMethod === 'card' &&
              selectedTreeItem?.schemaType === 'class'
            ) {
              setSelectedTreeItem(selectedTreeItem?.parentId);
            }
          } else {
            if (selectedTreeItem?.childrenIdList?.length > 0) {
              let childrens = resources?.filter((el) =>
                selectedTreeItem?.childrenIdList?.includes(el._id)
              );
              if (childrens.length > 0) {
                setOpenDeleteAbort(true);
                return;
              }
            }
            await deleteDocument({
              variables: {
                id: selectedTreeItem?._id,
                schemaType: selectedTreeItem?.schemaType
              }
            });
            let childrenIds = [];
            let tmp = resources?.filter((el) => el._id === parentId);
            if (tmp.length === 0) {
              tmp = classLoadedData?.filter((el) => el._id === parentId);
              childrenIds = tmp[0]?.childrenIdList?.filter(
                (el) => el !== selectedTreeItem['_id']
              );
            } else {
              childrenIds = tmp[0].childrenIdList?.filter(
                (el) => el !== selectedTreeItem['_id']
              );
            }

            if (tmp.length) {
              let varaibleData = {
                id: tmp[0]?._id,
                schemaType: tmp[0]?.schemaType,
                version: tmp[0]?.version,
                trackingAuthorName: currentUser?.name,
                childrenIdList: childrenIds
              };

              await updateGrouping({
                variables: varaibleData
              });
            }

            const notiOps = getNotificationOpt('material', 'success', 'delete');
            notify(notiOps.message, notiOps.options);

            if (
              viewMethod === 'card' &&
              selectedTreeItem?.schemaType === 'class'
            ) {
              let parentItem = resources.find(
                (el) => el._id === selectedTreeItem?.parentId
              );
              if (!parentItem) {
                parentItem = classLoadedData.find(
                  (el) => el._id === selectedTreeItem.parentId
                );
              }
              setSelectedTreeItem(
                parentItem ? parentItem : selectedTreeItem.parentId
              );
            }
          }
        }
        setCheckbox(false);
        setOpenDelete(false);
      }
    } catch (error) {
      console.log(error.message);
      const notiOps = getNotificationOpt('material', 'error', 'delete');
      notify(notiOps.message, notiOps.options);
    }
  };

  const handleUpdateChange = async (type, value) => {
    if (type === 'edit') {
      onChange('elSingleClick', value);
    }

    if (type === 'delete') {
      setOpenDelete(true);
    }

    if (type === 'btnClick') {
      setSelectedClassItem(value);
      onChange('cardViewList', value);
    }
  };

  const drawTable = (loadTableData) => {
    return (
      loadTableData.length > 0 &&
      loadTableData.map((row, index) => {
        return (
          <CustomCard
            resource={row}
            docId={row._id}
            name={row.desc ? row.desc.title : ''}
            title={row.desc ? row.desc.title : null}
            avatar_link={
              row?.avatar && row?.avatar?.baseUrl && row?.avatar?.fileDir
                ? row?.avatar?.baseUrl +
                  row?.avatar?.fileDir +
                  row?.avatar?.fileName
                : null
            }
            shortDescription={row.desc ? row.desc.short : null}
            longDescription={row.desc ? row.desc.long : null}
            onClick={handleElClicked}
            onUpdate={handleUpdateChange}
            // onClickMore={handleClickMore(row)}
          />
        );
      })
    );
  };

  const drawCards = () => {
    let loadedData = classLoadedData;
    return (
      <Grid style={{ padding: 20 }}>
        <Grid container justify="center" className={classes.root}>
          {drawTable(loadedData)}
        </Grid>
        {/* <CustomDialog
          open={openDeleteDialog}
          title={`Do you want to delete this card?`}
          mainBtnName="Delete"
          onChange={deleteData}
        >
          Are you sure want to delete this data?
          <br />
          <CustomCheckBox
            color="primary"
            value={checkbox}
            label="I agree with this action."
            onChange={(value) => setCheckbox(!value)}
          />
        </CustomDialog> */}
      </Grid>
    );
  };

  return (
    <MainPanel
      isMain={!parent}
      title={
        viewMethod === 'list'
          ? en['Lessons']
          : !cardViewList
          ? en['My Classes']
          : en['Lessons']
      }
      // title={"Lessons"}
      // icon={faBookOpen}
      icon={
        viewMethod === 'list'
          ? faBookOpen
          : selectedTreeItem?.schemaType !== 'class' &&
            selectedTreeItem?.schemaType !== 'material'
          ? faChalkboardTeacher
          : faBookOpen
      }
      showAddBtn={!cardViewList || viewMethod === 'list'}
      showRefresh={!cardViewList || viewMethod === 'list'}
      totalDisable={
        selectedTreeItem
          ? selectedTreeItem.schemaType === 'material' &&
            (selectedTreeItem?.childrenIdList === null ||
              selectedTreeItem?.parentIdList?.length > 2)
            ? true
            : false
          : true
      }
      onChange={handleMainPanelChange}
      selectedTreeItem={selectedTreeItem}
      viewMethod={viewMethod}
      cardViewList={cardViewList}
    >
      {viewMethod !== 'card' ? (
        /* {openSearch && (
        <div>
          <Autocomplete
            freeSolo
            id="free-solo-2-demo"
            disableClearable
            value={newSearchKey}
            onChange={(event, newValue) => handleRequestSearch(newValue)}
            onInputChange={(event, value) => handleCancelSearch(value)}
            options={tagsData.map((option) => option)}
            renderInput={(params) => (
              <TextField
                {...params}
                margin="normal"
                variant="outlined"
                InputProps={{
                  ...params.InputProps,
                  type: 'search',
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon />
                    </InputAdornment>
                  )
                }}
              />
            )}
          />
        </div>
      )} */
        <div className={classes.elementList}>
          <DraggableTreeView
            resources={resources}
            setSelectedTreeItem={setSelectedTreeItem}
            onClick={handleElClicked}
            onChange={handleMainPanelChange}
            setSelected={setSelected}
            selected={selected}
            selectedTreeItem={selectedTreeItem}
            setExpanded={setExpanded}
            expanded={expanded}
            classLoadedData={getFilteredClasses()}
            searchResults={searchResults}
            openSearch={openSearch}
            updateGrouping={updateGrouping}
          />
        </div>
      ) : cardViewList ? (
        <div className={classes.elementList}>
          <TreeListPanel
            loadedData={resources}
            selectedTreeItem={selectedTreeItem}
            selectedClassItem={selectedClassItem}
            setSubType={setSubType}
            setNewElName={setNewElName}
            onClick={handleElClicked}
            onChange={handleCreateDialogChange}
          />
        </div>
      ) : (
        drawCards()
      )}
      <CustomDialog
        mainBtnName={en['Create']}
        open={openCreate}
        title={en['Create New']}
        buttonDisable={buttonDisable}
        onChange={handleCreateDialogChange}
      >
        <Grid item xs={12} sm={12} md={12} lg={10}>
          <CustomRadioButtonsGroup
            setSubType={setSubType}
            selectedTreeItem={selectedTreeItem}
            onChange={handleCreateDialogChange}
          />
        </Grid>
        <Grid item xs={12} sm={12} md={12} lg={10}>
          <CustomInput
            my={2}
            size="small"
            type="text"
            label={en['Enter the title *']}
            focus={true}
            autoFocus={true}
            value={newElName}
            onChange={(value) => handleCreateDialogChange('input', value)}
            onKeyPress={(event) => {
              if (event.key === 'Enter') {
                handleCreateDialogChange('btnClick', event.target.value);
              }
            }}
            error={createDialogSetting.error}
            helperText={createDialogSetting.helpText}
            variant="outlined"
            width="300px"
          />
        </Grid>
      </CustomDialog>
      <CustomDialog
        mainBtnName={en['Rename']}
        open={openRename}
        title={`${en['Rename']} ${selectedTreeItem?.schemaType}`}
        onChange={handleCreateDialogChange}
      >
        <Grid item xs={12} sm={12} md={12} lg={10}>
          <CustomInput
            my={2}
            size="small"
            type="text"
            autoFocus={true}
            label={`Enter the ${selectedTreeItem?.schemaType} name *`}
            value={newElName}
            onChange={(value) => handleCreateDialogChange('input', value)}
            onKeyPress={(event) => {
              if (event.key === 'Enter') {
                handleCreateDialogChange('btnClick', event.target.value);
              }
            }}
            error={createDialogSetting.error}
            helperText={createDialogSetting.helpText}
            variant="outlined"
            width="300px"
          />
        </Grid>
      </CustomDialog>
      <CustomDialog
        open={openDelete}
        title={
          en['Do you want to delete this'] +
          ' ' +
          selectedTreeItem?.schemaType +
          '?'
        }
        mainBtnName={en['Remove']}
        onChange={handleDeleteDialogChange}
      >
        <Typography variant="subtitle1">
          {selectedTreeItem?.schemaType === 'class'
            ? en['remove class']
            : en['remove lesson alert']}
        </Typography>
        <CustomCheckBox
          color="primary"
          value={checkbox}
          label={
            selectedTreeItem?.schemaType === 'class'
              ? en['I agree to delete the class.']
              : en['I agree with this action.']
          }
          onChange={(value) => setCheckbox(!value)}
        />
      </CustomDialog>
      <CustomDialog
        open={openDeleteAbort}
        title={en["Can't delete the data."]}
        secondaryBtnName={en['Ok']}
        onChange={() => {
          setOpenDeleteAbort(false);
          setOpenDelete(false);
        }}
      >
        <Typography variant="h6">{en['delete notify']}</Typography>
      </CustomDialog>
    </MainPanel>
  );
};

export default MaterialMain;
