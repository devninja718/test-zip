/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, useContext } from 'react';
import { withRouter } from 'react-router-dom';
import { useQuery, useMutation, useLazyQuery } from '@apollo/client';
import { Box, Typography } from '@material-ui/core';
import RouteLeavingGuard from '@app/components/RouteLeavingGuard';
import graphql from '@app/graphql';
import AppContext from '@app/AppContext';
import { useUserContext } from '@app/providers/UserContext';
import { useStateContext } from '@app/providers/StateContext';
import { useGalleryContext } from '@app/providers/GalleryContext';
import MaterialMain from './Main';
import MaterialEdit from './Edit';
import TopologyEdit from '../Topology/Edit';
import useStyles from './style';
import { useNotifyContext } from '@app/providers/NotifyContext';
import { usePaginationContext } from '@app/providers/Pagination';
import { getNotificationOpt } from '@app/constants/Notifications';
import { useSelectionContext } from '@app/providers/SelectionContext';
import { useFilterContext } from '@app/providers/FilterContext';
import StatesList from '@app/constants/states.json';
import { useAssetContext } from '@app/providers/AssetContext';
import {
  create,
  remove,
  update,
  upsertMMA,
  deleteMMA
} from '@app/utils/ApolloCacheManager';
import { useViewMethodContext } from '@app/providers/ViewMethodContext';
import { useSearchContext } from '@app/providers/SearchContext';
import { useLessonViewModeContext } from '@app/providers/LessonViewModeContext';
import { en } from '@app/language';

const MaterialContainer = ({ history }) => {
  const classes = useStyles();
  const [showEdit, setShowEdit] = useState(false);
  const [whenState, setWhenState] = useState(false);
  const [isOutSide, setIsOutSide] = useState(false);
  const [loadedData, setLoadedData] = useState([]);
  const [currentUser] = useUserContext();
  const [classLoadedData, setClassLoadedData] = useState([]);
  const [schoolLoadedData, setSchoolLoadedData] = useState([]);
  const [modalShow, setModalShow] = useState(false);
  const [isCreate, setIsCreate] = useState(false);
  const [createShow, setCreateShow] = useState(false);
  const { notify } = useNotifyContext();
  const { setOpenRight } = useGalleryContext();
  const [editPanelData, setEditPanelData] = useState();
  const [editTmpData, setEditTmpData] = useState();
  const [selectedDocId, setSelectedDocId] = useState();
  const [isForceSave, setIsForceSave] = useState(false);
  const [context, setContext] = useContext(AppContext);
  const [forceSaveDocId, setForceSaveDocId] = useState();
  const [forceSaveDoc, setForceSaveDoc] = useState();
  const [isFirst, setIsFirst] = useState(0);
  const [selectedTreeItem, setSelectedTreeItem] = useState();
  const [selected, setSelected] = useState([]);
  const [parentTreeItem, setParentTreeItem] = useState();
  const [attStatus, setAttStatus] = useState(true);
  const [refresh, setRefresh] = useState(false);
  const [forceChangeItem, setForceChangeItem] = useState();
  const [offset, setOffset] = useState(0);
  const [limit, setLimit] = useState(2500);
  const { nextSelected, setNextSelected } = useSelectionContext();
  const { filteredStationList } = useFilterContext();
  const [stationLoadedData, setStationLoadedData] = useState([]);
  const { attachmentsUploaded, setAttachmentUploaded } = useAssetContext();
  const { viewMethod } = useViewMethodContext();
  const [, , , , pageNumber, setPageNumber] = usePaginationContext();
  const [cardViewList, setCardViewList] = useState(false);
  const [topologyTitle, setTopologyTitle] = useState('');
  const { setOpenLessonSearch } = useSearchContext();
  const { selectedClassItem, setSelectedClassItem } =
    useLessonViewModeContext();
  const [isFirstLoad, setFirstLoad] = useState(true);

  const [createGrouping] = useMutation(graphql.mutations.createGrouping, {
    update: create
  });

  const stationVariables = {
    id: null,
    schemaType: 'station',
    offset: null,
    name: null,
    sortBy: 'createdAt'
  };

  const {
    loading: stationLoading,
    error: stationError,
    data: stationData
  } = useQuery(graphql.queries.StationGrouping, {
    variables: stationVariables,
    fetchPolicy: 'cache-and-network',
    nextFetchPolicy: 'cache-first'
  });

  useEffect(() => {
    if (!stationLoading && !stationError) {
      const { grouping } = stationData;
      setStationLoadedData(grouping);
    }
  }, [stationLoading, stationError, stationData]);

  useEffect(() => {
    if (viewMethod === 'card') {
      if (selectedTreeItem && selectedClassItem) {
        setCardViewList(true);
        setShowEdit(true);
      } else {
        setShowEdit(false);
        setCardViewList(false);
      }
    } else if (viewMethod === 'list') {
      setCardViewList(false);
    }
    // setCardViewList(false);
    setPageNumber(1);
  }, [viewMethod]);

  const getGrouping = (selectedTreeItem) => {
    if (selectedTreeItem) {
      const schemaType = selectedTreeItem.schemaType;
      if (schemaType === 'station') {
        return graphql.queries.StationGrouping;
      } else if (schemaType === 'district') {
        return graphql.queries.DistrictGrouping;
      } else if (schemaType === 'school') {
        return graphql.queries.SchoolGrouping;
      } else if (schemaType === 'class') {
        return graphql.queries.ClassGrouping;
      } else if (schemaType === 'material') {
        return graphql.queries.MaterialGrouping;
      } else {
        return graphql.queries.MaterialGrouping;
      }
    }
  };

  const [
    getSchool,
    { loading: schoolLoading, data: schoolData, error: schoolError }
  ] = useLazyQuery(graphql.queries.SchoolGrouping);

  const [
    getClass,
    { loading: classLoading, data: classData, error: classError }
  ] = useLazyQuery(graphql.queries.ClassGrouping);

  const [
    getSelectedItem,
    { loading: selectedLoading, data: selectedData, error: selectedError }
  ] = useLazyQuery(getGrouping(selectedTreeItem));

  const [getData, { loading, data, error }] = useLazyQuery(
    graphql.queries.MaterialGrouping
  );

  const [updateGrouping] = useMutation(graphql.mutations.updateGrouping, {
    update: update
  });

  const [upsertMMAGrouping] = useMutation(graphql.mutations.upsertMMA, {
    update: upsertMMA
  });

  const [deleteMMAGrouping] = useMutation(graphql.mutations.deleteMMA, {
    update: deleteMMA
  });

  const [createBulkUsersGrouping] = useMutation(
    graphql.mutations.createBulkUsersGrouping
  );

  const [deleteDocument] = useMutation(graphql.mutations.deleteDocument, {
    update: (cache, { data: { deleteDocument } }) =>
      remove(cache, { data: { deleteDocument } }, selectedTreeItem?._id)
  });
  const userInfo = currentUser || null;

  const [variables, setVariables] = useState({
    id: null,
    schemaType: 'material',
    offset: null,
    limit: null,
    name: null,
    sortBy: 'rank'
  });

  const [classVariables, setClassVariables] = usePaginationContext();
  const [classWithoutAuthorVariables, setClassWithoutAuthorVariables] =
    usePaginationContext();

  const schoolVariables = {
    id: null,
    schemaType: 'school',
    parentId: selectedTreeItem?.topology?.district,
    offset: null,
    name: null
  };

  const fetchSelected = async () => {
    await getSelectedItem({
      variables: {
        id: selectedTreeItem?._id,
        schemaType: selectedTreeItem?.schemaType
      },
      fetchPolicy: 'cache-and-network',
      nextFetchPolicy: 'cache-first'
    });
  };

  const fetchSchool = async () => {
    await getSchool({
      variables: schoolVariables,
      fetchPolicy: 'cache-and-network',
      nextFetchPolicy: 'cache-first'
    });
  };

  const fetchClasses = async () => {
    let variable =
      userInfo?.schemaType === 'sysAdmin' ||
      userInfo?.schemaType === 'superAdmin'
        ? classWithoutAuthorVariables
        : classVariables;

    if (
      isFirstLoad &&
      (userInfo?.schemaType === 'sysAdmin' ||
        userInfo?.schemaType === 'superAdmin')
    ) {
      setClassWithoutAuthorVariables({
        ...classWithoutAuthorVariables,
        stationId: null,
        topology: null,
        state: null
      });
      variable = {
        ...variable,
        topology: null,
        state: null,
        stationId: null
      };
      setFirstLoad(false);
    }

    await getClass({
      variables: {
        ...variable,
        sortBy: 'createdAt'
      },
      fetchPolicy: 'cache-and-network',
      nextFetchPolicy: 'cache-first'
    });
  };

  const fetchMaterialData = async () => {
    await getData({
      variables,
      fetchPolicy: 'cache-and-network',
      nextFetchPolicy: 'cache-first'
    });
  };

  useEffect(() => {
    let prevClassVariable = localStorage.getItem('classVariables');
    if (prevClassVariable) {
      prevClassVariable = JSON.parse(prevClassVariable);
      setOffset(prevClassVariable.offset);
      setClassVariables(prevClassVariable);
    }
    if (viewMethod === 'card') {
      if (selectedTreeItem && selectedClassItem) {
        setCardViewList(true);
      } else {
        handleMainChange('back', true);
        setTopologyTitle();
        setShowEdit(false);
      }
    }
  }, []);

  useEffect(() => {
    if (!selectedLoading && !selectedError && selectedData) {
      const { grouping } = selectedData;
      const selectedItem = grouping.find(
        (el) => el._id === selectedTreeItem?._id
      );
      if (selectedItem) {
        setEditPanelData(selectedItem);
      }
    }
  }, [selectedLoading, selectedError, selectedData]);

  useEffect(() => {
    if (classData && classData?.grouping?.length) {
      let selectedLesson = localStorage.getItem('previousLesson');
      let selectedClass = localStorage.getItem('previousClass');
      if (selectedClass) {
        selectedClass = JSON.parse(selectedClass);
        setSelectedClassItem(selectedClass);
      }
      if (selectedLesson) {
        try {
          selectedLesson = JSON.parse(selectedLesson);
          if (viewMethod !== 'card') {
            handleMainChange('elSingleClick', selectedLesson);
          } else {
            handleMainChange('elCardClick', selectedLesson);
          }
        } catch (e) {}
      }
    }
  }, [classData]);

  useEffect(() => {
    if (!schoolLoading && !schoolError && schoolData) {
      const { grouping } = schoolData;
      const schoolList = [];
      grouping.map((item) =>
        schoolList.push({ label: item['name'], value: item['_id'] })
      );
      setSchoolLoadedData(grouping);
    }
  }, [schoolLoading, schoolError, schoolData]);

  useEffect(() => {
    if (selectedTreeItem) {
      fetchSelected();
    }
  }, [history.location.pathname]);

  useEffect(() => {
    fetchMaterialData();
    fetchClasses();
  }, [classWithoutAuthorVariables, classVariables]);

  useEffect(() => {
    if (selectedTreeItem?._id) {
      fetchSelected();
      if (selectedTreeItem?.schemaType === 'class') {
        fetchSchool();
      }
    }
    setOpenRight(false);
  }, [selectedTreeItem]);

  useEffect(() => {
    if (refresh) {
      setContext({
        ...context,
        groupingAdd: null
      });
      setRefresh(false);
    }
  }, [refresh]);

  useEffect(() => {
    if (!schoolLoading && !schoolError && schoolData) {
      const { grouping } = schoolData;
      const schoolList = [];
      grouping.map((item) =>
        schoolList.push({ label: item['name'], value: item['_id'] })
      );
      setSchoolLoadedData(grouping);
    }
  }, [schoolLoading, schoolError, schoolData]);

  useEffect(async () => {
    if (!classLoading && !classError && classData) {
      const { grouping } = classData;
      if (userInfo?.schemaType === 'districtAdmin') {
        const tmp = grouping?.filter(
          (el) => el.topology.district === userInfo?.parentId
        );
        let sortedData = [...tmp];
        setClassLoadedData(sortedData);
      } else if (userInfo?.schemaType === 'stationAdmin') {
        const tmp = grouping?.filter(
          (el) => el.topology.station === userInfo?.parentId
        );
        let sortedData = [...tmp];
        setClassLoadedData(sortedData);
      } else if (userInfo?.schemaType === 'schoolAdmin') {
        const tmp = grouping?.filter(
          (el) => el.parentId === userInfo?.parentId
        );
        let sortedData = [...tmp];
        setClassLoadedData(sortedData);
      } else if (userInfo?.schemaType === 'educator') {
        const tmp = grouping?.filter((el) =>
          el.authorIdList?.includes(userInfo._id)
        );
        let sortedData = [...tmp];
        let resultData = sortedData;
        setClassLoadedData(resultData);
      } else {
        let sortedData = [...grouping];
        setClassLoadedData(sortedData);
      }
    }
  }, [classLoading, classError, classData, offset, limit]);

  useEffect(() => {
    if (!loading && !error && data) {
      const { grouping } = data;
      let sortedData = [...grouping];
      setLoadedData(sortedData.sort((a, b) => a.rank - b.rank));
    }
  }, [loading, error, data]);

  useEffect(() => {
    if (attachmentsUploaded) {
      if (whenState) {
        setIsForceSave(true);
      }
      setAttachmentUploaded(false);
    }
  }, [attachmentsUploaded]);

  const checkIsOutSide = (value) => {
    const tmp = value.split('/').length;
    if (tmp > 2) {
      setIsOutSide(true);
    } else {
      setIsOutSide(false);
    }
  };

  const getParentItem = (value) => {
    let item = loadedData?.find((e) => e._id === value?.parentId);
    if (!item) item = classLoadedData?.find((e) => e._id === value?.parentId);
    return item;
  };

  const handleMainChange = (type, value) => {
    if (type === 'elSingleClick') {
      if (value) {
        if (value?.schemaType === 'class') setSelectedClassItem(value);
        setNextSelected(value);
        if (selectedTreeItem && selectedTreeItem['_id'] === value['_id']) {
          return;
        }
        setEditTmpData(value);
        setOpenLessonSearch(false);
        history.push({
          pathname: `/materials/dashboard/${value['_id']}`
        });
        if (!whenState) {
          setShowEdit(true);
          setEditPanelData(value);
          setSelectedDocId(value['_id']);
          setSelectedTreeItem(value);
          setSelected(value?._id);
          setEditTmpData();
        }
        setParentTreeItem(getParentItem(value));
      }
    }

    if (type === 'elCardClick') {
      if (value) {
        setNextSelected(value);
        if (selectedTreeItem && selectedTreeItem['_id'] === value['_id']) {
          return;
        }
        setEditTmpData(value);
        history.push({
          pathname: `/materials/dashboard/${value['_id']}`
        });
        if (!whenState) {
          // setShowEdit(true);
          // setEditPanelData(value);
          setSelectedDocId(value['_id']);
          setSelectedTreeItem(value);
          setSelected(value?._id);
          setEditTmpData();
        }
        setParentTreeItem(getParentItem(value));
      }
    }

    if (type === 'cardViewList') {
      if (value) {
        setSelectedTreeItem(value);
        setCardViewList(true);
      }
    }

    if (type === 'delete') {
      setShowEdit(false);
    }

    if (type === 'refresh') {
      setRefresh(true);
    }

    if (type === 'back') {
      if (viewMethod === 'card') {
        setShowEdit(false);
      }
      setCardViewList(false);
      setPageNumber(1);
    }
  };

  const handleEditChange = (type, value) => {
    if (type === 'update') {
      setWhenState(value);
    }
    if (type === 'delete') {
      setShowEdit(false);
    }
    if (type === 'forceSave') {
      setIsForceSave(value);
    }

    if (type === 'attachment') {
      setAttStatus(value);
    }

    if (type === 'publish') {
      setRefresh(true);
    }

    if (type === 'created') {
      setWhenState(false);
    }

    if (type === 'moveResource') {
      history.push({ pathname: '/resources' });
    }
  };

  const handForceChange = (type, value) => {
    if (type === 'altText') {
      let tmp = {
        avatar: {
          altText: value
        }
      };
      setForceChangeItem({ ...forceChangeItem, tmp });
    } else if (type === 'avatar') {
      let baseUrl;
      let fileDir;
      let fileName;
      if (value) {
        const paths = value.split('/');
        fileDir = `${paths[paths.length - 2]}/`;
        baseUrl = value.split(`${fileDir}`)[0];
        fileName = paths[paths.length - 1];
      }
      let tmp = {
        avatar: {
          mimeType: 'image/png',
          baseUrl,
          fileDir,
          fileName,
          status: 'ready'
        }
      };
      setForceChangeItem({ ...forceChangeItem, tmp });
    } else {
      setForceChangeItem({ ...forceChangeItem, [type]: value });
    }
  };

  const handleGuardChange = async (value) => {
    setWhenState(false);
    setShowEdit(true);
    setAttStatus(true);

    if (value) {
      setIsForceSave(true);
    } else {
      setSelectedTreeItem(nextSelected);
    }

    if (isCreate) {
      setCreateShow(true);
      setIsCreate(false);
    }
  };

  const handleChangePage = (newPage) => {
    setOffset(newPage * limit);
  };

  const handleChangeRowsPerPage = (newRowsPerPage) => {
    setLimit(newRowsPerPage);
    setOffset(0);
  };

  return (
    <Box>
      <Typography className={classes.topologyTitle}>
        {currentUser.schemaType !== 'educator' ? topologyTitle : ''}
      </Typography>

      <Box className={classes.root}>
        <RouteLeavingGuard
          when={attStatus && whenState}
          navigate={(path) => {
            history.push(path);
          }}
          shouldBlockNavigation={(location) => {
            checkIsOutSide(location.pathname);
            return attStatus && whenState;
          }}
          onChange={handleGuardChange}
          show={modalShow}
          updateShow={setModalShow}
        >
          <Typography variant="subtitle1" className={classes.warning}>
            {en['There are unsaved changes on the panel.']}
            <br />
            {en['Will you discard yor current changes?']}
          </Typography>
        </RouteLeavingGuard>

        {(viewMethod === 'list' ||
          (viewMethod === 'card' && !showEdit) ||
          cardViewList) && (
          <MaterialMain
            userInfo={userInfo}
            setSelectedDocId={setSelectedDocId}
            setEditPanelData={setEditPanelData}
            selectedDocId={selectedDocId}
            variables={variables}
            resources={loadedData}
            selected={selected}
            setSelected={setSelected}
            setResources={setLoadedData}
            onChange={handleMainChange}
            selectedTreeItem={selectedTreeItem}
            setSelectedTreeItem={setSelectedTreeItem}
            createGrouping={createGrouping}
            updateGrouping={updateGrouping}
            deleteDocument={deleteDocument}
            classLoadedData={classLoadedData}
            schoolLoadedData={schoolLoadedData}
            isFirst={isFirst}
            setIsFirst={setIsFirst}
            updateShow={setModalShow}
            when={attStatus && whenState}
            stationLoadedData={stationLoadedData}
            setIsCreate={setIsCreate}
            createShow={createShow}
            setCreateShow={setCreateShow}
            editPanelData={editPanelData}
            onChangePage={handleChangePage}
            onChangeRowsPerPage={handleChangeRowsPerPage}
            setVariables={setVariables}
            viewMethod={viewMethod}
            history={history}
            cardViewList={cardViewList}
            setTopologyTitle={setTopologyTitle}
          />
        )}
        {showEdit &&
          (selectedTreeItem?.schemaType === 'class' ? (
            <TopologyEdit
              forceSaveDoc={forceSaveDoc}
              forceSaveDocId={forceSaveDocId}
              parentPage={'Lessons'}
              forceSave={isForceSave}
              variables={variables}
              resources={editPanelData}
              setWhenState={setWhenState}
              whenState={whenState}
              showEyeIcon={true}
              setEditPanelData={setEditPanelData}
              schoolLoadedData={schoolLoadedData}
              classLoadedData={classLoadedData}
              onChange={handleEditChange}
              handleMainChange={handleMainChange}
              selectedTreeItem={selectedTreeItem}
              setSelectedTreeItem={setSelectedTreeItem}
              updateGrouping={updateGrouping}
              deleteDocument={deleteDocument}
              setSelected={setSelected}
              setTopologyTitle={setTopologyTitle}
              parentTreeItem={parentTreeItem}
              onForceChange={handForceChange}
              forceChangeItem={forceChangeItem}
              createBulkUsersGrouping={createBulkUsersGrouping}
              isMaterial={true}
              setRefresh={(value) => setRefresh(value)}
              StatesList={StatesList}
              viewMethod={viewMethod}
              setShowEdit={setShowEdit}
            />
          ) : (
            <MaterialEdit
              forceSaveDocId={forceSaveDocId}
              forceSaveDoc={forceSaveDoc}
              forceSave={isForceSave}
              variables={variables}
              resources={editPanelData}
              setEditPanelData={setEditPanelData}
              setSelectedDocId={setSelectedDocId}
              setSelected={setSelected}
              loadedData={loadedData}
              setLoadedData={setLoadedData}
              whenState={whenState}
              setWhenState={setWhenState}
              setEditTmpData={setEditTmpData}
              classResources={classLoadedData}
              setTopologyTitle={setTopologyTitle}
              schoolLoadedData={schoolLoadedData}
              onChange={handleEditChange}
              onMainChange={(value) => handleMainChange('elSingleClick', value)}
              selectedTreeItem={selectedTreeItem}
              setSelectedTreeItem={setSelectedTreeItem}
              updateGrouping={updateGrouping}
              upsertMMAGrouping={upsertMMAGrouping}
              deleteMMAGrouping={deleteMMAGrouping}
              deleteDocument={deleteDocument}
              handleMainChange={handleMainChange}
              parentTreeItem={parentTreeItem}
              onForceChange={handForceChange}
              forceChangeItem={forceChangeItem}
              viewMethod={viewMethod}
              setShowEdit={setShowEdit}
              cardViewList={cardViewList}
            />
          ))}
      </Box>
    </Box>
  );
};

export default withRouter(MaterialContainer);
